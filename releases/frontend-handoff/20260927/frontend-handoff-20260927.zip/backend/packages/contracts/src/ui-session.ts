import { z } from 'zod'

import { episodeStatusSchema } from './activity.js'
import { discoveryContextSchema } from './agent-contracts.js'
import {
  builderTaskSchema,
  decisionApplicationSchema,
  decisionRequestSchema,
  decisionResolutionSchema,
  liveProjectContextSchema,
  taskCompletionReportSchema,
} from './build.js'
import {
  discoverySessionSchema,
  projectCandidateRevisionSchema,
  projectSchema,
} from './discovery.js'
import { learningSpecRevisionSchema } from './learning-spec.js'
import {
  conversationIdSchema,
  correlationIdSchema,
  decisionIdSchema,
  episodeIdSchema,
  nonEmptyTextSchema,
  schemaVersionSchema,
  taskIdSchema,
  utcTimestampSchema,
} from './primitives.js'

export const crewAppSurfaceSchema = z.enum(['DISCOVERY', 'SPEC', 'BUILD'])

export const helperConversationSummarySchema = z.strictObject({
  conversationId: conversationIdSchema,
  episodeId: episodeIdSchema,
  /** Helper turn correlation; matches the PersonalizationTrace written for that turn. */
  correlationId: correlationIdSchema.optional(),
  taskId: taskIdSchema,
  decisionId: decisionIdSchema.optional(),
  status: episodeStatusSchema,
  startedAt: utcTimestampSchema,
  endedAt: utcTimestampSchema.optional(),
  redactedUserExcerpts: z.array(nonEmptyTextSchema).max(5),
  helperResponseSummaries: z.array(nonEmptyTextSchema).max(5),
})

export const decisionSessionItemSchema = z.strictObject({
  request: decisionRequestSchema,
  resolution: decisionResolutionSchema.nullable(),
  application: decisionApplicationSchema.nullable(),
})

export const projectHistoryItemSchema = z.strictObject({
  project: projectSchema,
  suggestedSurface: crewAppSurfaceSchema,
  activeTask: builderTaskSchema.nullable(),
  pendingDecisionCount: z.int().nonnegative().max(100),
  currentContextVersion: z.int().positive().nullable(),
  helperConversationCount: z.int().nonnegative(),
})

export const projectHistorySchema = z.strictObject({
  schemaVersion: schemaVersionSchema,
  correlationId: correlationIdSchema,
  projects: z.array(projectHistoryItemSchema).max(100),
})

export const projectSessionSnapshotSchema = z.strictObject({
  schemaVersion: schemaVersionSchema,
  correlationId: correlationIdSchema,
  project: projectSchema,
  suggestedSurface: crewAppSurfaceSchema,
  discoverySession: discoverySessionSchema.nullable(),
  discoveryContext: discoveryContextSchema.nullable(),
  selectedCandidate: projectCandidateRevisionSchema.nullable(),
  learningSpec: learningSpecRevisionSchema.nullable(),
  activeTask: builderTaskSchema.nullable(),
  currentTask: builderTaskSchema.nullable(),
  liveContext: liveProjectContextSchema.nullable(),
  pendingDecisions: z.array(decisionRequestSchema).max(100),
  decisions: z.array(decisionSessionItemSchema).max(100).default([]),
  completionReport: taskCompletionReportSchema.nullable().default(null),
  helperConversations: z.array(helperConversationSummarySchema).max(20),
})

export type CrewAppSurface = z.infer<typeof crewAppSurfaceSchema>
export type HelperConversationSummary = z.infer<typeof helperConversationSummarySchema>
export type DecisionSessionItem = z.infer<typeof decisionSessionItemSchema>
export type ProjectHistoryItem = z.infer<typeof projectHistoryItemSchema>
export type ProjectHistory = z.infer<typeof projectHistorySchema>
export type ProjectSessionSnapshot = z.infer<typeof projectSessionSnapshotSchema>
