import { randomUUID } from 'node:crypto'
import { mkdir, mkdtemp, stat, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import {
  type ApplicationError,
  ApplicationService,
  WorkspacePathPolicy,
} from '@vibe-helper/application'
import {
  activityEventSchema,
  analysisJobSchema,
  builderTaskSchema,
  candidateRoundSchema,
  canonicalConceptSchema,
  decisionRequestSchema,
  discoveryFeedbackSchema,
  discoverySessionSchema,
  episodeSchema,
  learningSpecRevisionSchema,
  personalizationTraceSchema,
  preparedBuilderTaskDescriptorSchema,
  projectCandidateRevisionSchema,
  projectSchema,
  projectEvidenceTraceSchema,
} from '@vibe-helper/contracts'
import { describe, expect, it } from 'vitest'

import {
  activityEventFixture,
  analysisJobFixture,
  analysisJobPendingFixture,
  builderTaskFixture,
  candidateFixture,
  candidateRoundFixture,
  canonicalConceptFixture,
  completionReportFixture,
  confirmedLearningSpecFixture,
  decisionRequestFixture,
  decisionResolutionFixture,
  discoveryFeedbackFixture,
  discoveryInputFixture,
  discoverySessionFixture,
  draftLearningSpecFixture,
  episodeFixture,
  evidenceProposalBatchFixture,
  helperPersonalizationFixture,
  ids,
  learningSpecDraftContentFixture,
  liveContextFixture,
  projectFixture,
  timestamp,
} from '../../contracts/test/fixtures.js'
import { openInMemorySqliteStorage } from '../../storage-sqlite/src/index.js'

const fixedIdGenerator = (() => {
  let sequence = 40
  return (prefix: string): string => {
    sequence += 1
    return `${prefix}_00000000-0000-4000-8000-${String(sequence).padStart(12, '0')}`
  }
})()

const createHarness = async (
  options: { readonly generateId?: (prefix: string) => string; readonly now?: () => Date } = {},
) => {
  const workspaceRoot = await mkdtemp(join(tmpdir(), 'vibe-helper-application-workspaces-'))
  const storage = await openInMemorySqliteStorage()
  const workspacePolicy = await WorkspacePathPolicy.create(workspaceRoot)
  const service = new ApplicationService({
    storage,
    workspacePolicy,
    now: options.now ?? (() => new Date(timestamp)),
    generateId: options.generateId ?? fixedIdGenerator,
  })
  return { service, storage, workspaceRoot, workspacePolicy }
}

const previewRoundId = 'candidate_preview_round_00000000-0000-4000-8000-000000000501'
const previewFinalRoundId = 'candidate_round_00000000-0000-4000-8000-000000000502'
const previewCandidateId = (position: number): string =>
  `candidate_00000000-0000-4000-8000-${String(510 + position).padStart(12, '0')}`
const reasonedDecisionEvent = {
  ...activityEventFixture,
  id: 'event_00000000-0000-4000-8000-000000000760',
  sequence: 2,
  conversationId: undefined,
  decisionId: ids.decision,
  payload: {
    type: 'DECISION_RESOLVED' as const,
    decisionId: ids.decision,
    resolutionId: ids.resolution,
    rationaleProvided: true,
  },
  sourceReferences: [],
} as const
const reasonedEvidenceBatch = {
  ...evidenceProposalBatchFixture,
  proposals: evidenceProposalBatchFixture.proposals.map((proposal) => ({
    ...proposal,
    concept: { ...proposal.concept, originalExpression: 'unexpected shapes' },
    userEvidenceSources: [{ kind: 'USER_DECISION' as const, decisionId: ids.decision }],
    redactedEvidenceExcerpt: decisionResolutionFixture.rationale,
  })),
} as const
const previewFor = (position: number) => ({
  candidateId: previewCandidateId(position),
  position,
  title: `Preview ${String(position)}`,
  summary: `Distinct project direction ${String(position)} for the learning goal.`,
  coreInteraction: `Complete interaction ${String(position)} and inspect its typed result.`,
  appeal: `Direction ${String(position)} makes an invisible concept tangible.`,
  technologyNecessity: `The target technology controls interaction ${String(position)}.`,
  generationTags: ['DIRECT'] as const,
})

describe('Helper direct Task user Evidence retrieval', () => {
  it('prioritizes only already-referenced code files named in the question within the three-excerpt cap', async () => {
    const { service, storage, workspaceRoot } = await createHarness()
    seedBuilderGraph(storage)
    const sourceDirectory = join(
      workspaceRoot,
      ...projectFixture.generatedWorkspacePath.split('/'),
      'src',
    )
    await mkdir(sourceDirectory, { recursive: true })
    for (const name of [
      'renderer-a.ts',
      'renderer-b.ts',
      'renderer-c.ts',
      'cache.ts',
      'workbench.ts',
      'secret.ts',
    ]) {
      await writeFile(join(sourceDirectory, name), `export const file = '${name}';\n`, 'utf8')
    }
    storage.repository.appendLiveContext({
      ...liveContextFixture,
      relatedFiles: [
        'src/renderer-a.ts',
        'src/renderer-b.ts',
        'src/renderer-c.ts',
        'src/cache.ts',
        'src/workbench.ts',
      ].map((path) => ({ kind: 'CODE' as const, path })),
    })
    const response = await service.executeAgent('HELPER', {
      schemaVersion: 1,
      kind: 'HELPER_GET_CONTEXT',
      correlationId: 'corr_00000000-0000-4000-8000-000000000723',
      actor: { kind: 'AGENT', role: 'HELPER' },
      projectId: ids.project,
      taskId: ids.task,
      question:
        'cache.ts와 workbench.ts에서 값을 만드는 경로는 무엇인가요? secret.ts도 궁금합니다.',
      relatedConceptNames: [],
      observedContextVersion: 1,
    })
    expect(response).toMatchObject({ success: true })
    if (!response.success) throw new Error('Helper context failed')
    const excerptPaths = response.data.sourceExcerpts.map((excerpt) => excerpt.reference.path)
    expect(excerptPaths).toEqual(['src/cache.ts', 'src/workbench.ts', 'src/renderer-a.ts'])
    expect(response.data.contextReferences).toHaveLength(5)
    expect(response.data.referenceDetails).toHaveLength(5)
    expect(response.data.sourceExcerpts).toHaveLength(3)
    expect(JSON.stringify(response.data)).not.toContain('src/secret.ts')
  })

  it('uses accepted current and predecessor Task Evidence for a paraphrased question, but excludes an unrelated Task', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)
    const nextTaskId = 'task_00000000-0000-4000-8000-000000000701'
    const unrelatedTaskId = 'task_00000000-0000-4000-8000-000000000702'
    storage.transaction((repository) => {
      repository.appendTask(
        builderTaskSchema.parse({ ...builderTaskFixture, revision: 2, status: 'COMPLETED' }),
      )
      repository.appendTask(
        builderTaskSchema.parse({
          ...builderTaskFixture,
          id: nextTaskId,
          sequence: 2,
          prerequisiteTaskIds: [ids.task],
          finalUpgrade: {
            sourceTaskId: ids.task,
            personalizationTraceId: ids.personalization,
            userGoal: 'Make cache behavior visible.',
          },
        }),
      )
      repository.appendTask(
        builderTaskSchema.parse({
          ...builderTaskFixture,
          id: unrelatedTaskId,
          sequence: 3,
          status: 'COMPLETED',
          prerequisiteTaskIds: [],
        }),
      )
    })

    const acceptUserStatement = async (input: {
      readonly number: number
      readonly taskId: string
      readonly conceptName: string
      readonly statement: string
      readonly expression: string
    }) => {
      const stableId = (prefix: string): string =>
        `${prefix}_00000000-0000-4000-8000-${String(input.number).padStart(12, '0')}`
      const eventId = stableId('event')
      const episodeId = stableId('episode')
      const jobId = stableId('analysis_job')
      const conceptId = stableId('concept')
      const conversationId = stableId('conversation')
      const messageId = stableId('message')
      const source = { kind: 'USER_MESSAGE', conversationId, messageId } as const
      storage.transaction((repository) => {
        repository.appendActivityEvent(
          activityEventSchema.parse({
            ...activityEventFixture,
            id: eventId,
            taskId: input.taskId,
            conversationId,
            sequence: input.number - 710,
            payload: {
              type: 'USER_MESSAGE',
              conversationId,
              messageId,
              redactedExcerpt: input.statement,
            },
            sourceReferences: [source],
          }),
        )
        repository.appendEpisode(
          episodeSchema.parse({
            ...episodeFixture,
            id: episodeId,
            taskId: input.taskId,
            decisionId: undefined,
            conversationId,
            type: 'HELPER_CONVERSATION',
            eventIds: [eventId],
            conceptCandidates: [{ conceptId, originalExpression: input.expression }],
            contextReferences: [],
          }),
        )
        repository.appendAnalysisJob(
          analysisJobSchema.parse({ ...analysisJobPendingFixture, id: jobId, episodeId }),
        )
        repository.appendAnalysisJob(
          analysisJobSchema.parse({ ...analysisJobFixture, id: jobId, episodeId }),
        )
        repository.appendCanonicalConcept(
          canonicalConceptSchema.parse({
            ...canonicalConceptFixture,
            id: conceptId,
            canonicalName: input.conceptName,
          }),
        )
      })
      const response = await service.executeAgent('EVIDENCE_ANALYST', {
        schemaVersion: 1,
        kind: 'ANALYST_SUBMIT_EVIDENCE_PROPOSALS',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'EVIDENCE_ANALYST' },
        idempotencyKey: stableId('idem'),
        analysisJobId: jobId,
        expectedJobRevision: 2,
        attempt: 1,
        batch: {
          ...evidenceProposalBatchFixture,
          episodeId,
          proposals: [
            {
              ...evidenceProposalBatchFixture.proposals[0],
              id: stableId('evidence_proposal'),
              taskId: input.taskId,
              episodeId,
              concept: {
                canonicalConceptId: conceptId,
                proposedCanonicalName: input.conceptName,
                originalExpression: input.expression,
              },
              signal: 'REPHRASE',
              strength: 'MEDIUM',
              userEvidenceSources: [source],
              contextSources: [],
              redactedEvidenceExcerpt: input.statement,
              rationale: 'The user explained a consequence in their own words.',
              maximumSupportedState: 'EXPLAINED',
            },
          ],
        },
      })
      expect(response).toMatchObject({
        success: true,
        data: {
          outcomes: [
            {
              decision: { outcome: 'ACCEPTED', reasonCode: 'VALID_USER_EVIDENCE' },
              conceptId,
            },
          ],
        },
      })
      const trace = storage.repository.readEvidenceTrace(conceptId)
      expect(trace?.acceptedEvidence).toMatchObject([{ kind: 'USER_UNDERSTANDING' }])
      return { conceptId, evidenceId: trace?.acceptedEvidence[0]?.id }
    }

    const predecessor = await acceptUserStatement({
      number: 711,
      taskId: ids.task,
      conceptName: 'Cache key derivation from serialized options',
      statement:
        '옵션 객체를 문자열로 만들 때 속성 순서가 달라지면 같은 설정도 다른 캐시 키가 됩니다.',
      expression: '속성 순서가 달라지면 같은 설정도 다른 캐시 키가 됩니다',
    })
    const current = await acceptUserStatement({
      number: 712,
      taskId: nextTaskId,
      conceptName: 'Stable configuration identity',
      statement: '설정의 의미가 같다면 입력 순서가 달라도 같은 정체성으로 처리해야 합니다.',
      expression: '입력 순서가 달라도 같은 정체성으로 처리해야 합니다',
    })
    const unrelated = await acceptUserStatement({
      number: 713,
      taskId: unrelatedTaskId,
      conceptName: 'Unrelated event shape',
      statement: '이벤트 표시에서는 태그로 각 변형을 분기하는 편이 안전합니다.',
      expression: '태그로 각 변형을 분기하는 편이 안전합니다',
    })

    const helper = await service.executeAgent('HELPER', {
      schemaVersion: 1,
      kind: 'HELPER_GET_CONTEXT',
      correlationId: 'corr_00000000-0000-4000-8000-000000000714',
      actor: { kind: 'AGENT', role: 'HELPER' },
      projectId: ids.project,
      taskId: nextTaskId,
      question: '설정값의 순서가 바뀌면 왜 이전 저장 결과를 재사용하지 못하나요?',
      relatedConceptNames: [],
    })
    expect(helper).toMatchObject({
      success: true,
      data: { personalization: { mode: 'EVIDENCE_AWARE' } },
    })
    if (!helper.success) throw new Error('Helper context failed')
    const basis = helper.data.personalization.basis
    expect(basis).toHaveLength(2)
    expect(basis.map((item) => item.conceptId)).toEqual(
      expect.arrayContaining([predecessor.conceptId, current.conceptId]),
    )
    expect(basis.map((item) => item.conceptId)).not.toContain(unrelated.conceptId)
    expect(basis.every((item) => item.purpose === 'HELPER_TASK_USER_EVIDENCE_CONNECTION')).toBe(
      true,
    )
    expect(basis.find((item) => item.conceptId === predecessor.conceptId)?.evidenceIds).toEqual([
      predecessor.evidenceId,
    ])
    expect(basis.find((item) => item.conceptId === current.conceptId)?.evidenceIds).toEqual([
      current.evidenceId,
    ])
    expect(helper.data.relevantLedgerEntries.map((item) => item.concept.id)).toEqual(
      expect.arrayContaining([predecessor.conceptId, current.conceptId]),
    )

    const unrelatedContext = await service.executeAgent('HELPER', {
      schemaVersion: 1,
      kind: 'HELPER_GET_CONTEXT',
      correlationId: 'corr_00000000-0000-4000-8000-000000000715',
      actor: { kind: 'AGENT', role: 'HELPER' },
      projectId: ids.project,
      taskId: unrelatedTaskId,
      question: '이 작업에서 어떤 판단을 다시 확인해야 하나요?',
      relatedConceptNames: [],
    })
    expect(unrelatedContext).toMatchObject({
      success: true,
      data: {
        personalization: {
          mode: 'EVIDENCE_AWARE',
          basis: [
            { conceptId: unrelated.conceptId, purpose: 'HELPER_TASK_USER_EVIDENCE_CONNECTION' },
          ],
        },
      },
    })

    for (const number of [716, 717, 718, 719]) {
      await acceptUserStatement({
        number,
        taskId: nextTaskId,
        conceptName: `Current Task concept ${String(number)}`,
        statement: `현재 작업의 판단 ${String(number)}은 입력값을 먼저 확인해야 한다는 뜻입니다.`,
        expression: `입력값을 먼저 확인해야 한다는 뜻입니다`,
      })
    }
    const lexical = await service.executeAgent('HELPER', {
      schemaVersion: 1,
      kind: 'HELPER_GET_CONTEXT',
      correlationId: 'corr_00000000-0000-4000-8000-000000000720',
      actor: { kind: 'AGENT', role: 'HELPER' },
      projectId: ids.project,
      taskId: nextTaskId,
      question: 'How does Unrelated event shape affect this design?',
      relatedConceptNames: [],
    })
    expect(lexical).toMatchObject({ success: true })
    if (!lexical.success) throw new Error('Lexical Helper context failed')
    expect(lexical.data.personalization.basis).toHaveLength(5)
    expect(lexical.data.personalization.basis.slice(0, 2).map((item) => item.conceptId)).toEqual(
      expect.arrayContaining([predecessor.conceptId, current.conceptId]),
    )
    expect(
      lexical.data.personalization.basis
        .filter((item) => item.conceptId === unrelated.conceptId)
        .every((item) => item.purpose === 'HELPER_EXPLANATION_START'),
    ).toBe(true)

    const oldLexicalNames: string[] = []
    const oldLexicalConceptIds: string[] = []
    for (const number of [721, 722, 723, 724, 725]) {
      const conceptName = `Older unrelated lexical concept ${String(number)}`
      const older = await acceptUserStatement({
        number,
        taskId: unrelatedTaskId,
        conceptName,
        statement: `다른 작업의 판단 ${String(number)}은 독립된 입력에 관한 설명입니다.`,
        expression: '독립된 입력에 관한 설명입니다',
      })
      oldLexicalNames.push(conceptName)
      oldLexicalConceptIds.push(older.conceptId)
    }
    const saturated = await service.executeAgent('HELPER', {
      schemaVersion: 1,
      kind: 'HELPER_GET_CONTEXT',
      correlationId: 'corr_00000000-0000-4000-8000-000000000726',
      actor: { kind: 'AGENT', role: 'HELPER' },
      projectId: ids.project,
      taskId: nextTaskId,
      question: '현재 작업에서 이전 설명과 직접 연결되는 판단은 무엇인가요?',
      relatedConceptNames: [
        'Cache key derivation from serialized options',
        ...oldLexicalNames.slice(0, 4),
      ],
    })
    if (!saturated.success)
      throw new Error(`Saturated Helper context failed: ${saturated.error.code}`)
    const saturatedBasis = saturated.data.personalization.basis
    expect(saturatedBasis).toHaveLength(5)
    expect(new Set(saturatedBasis.map((item) => item.conceptId)).size).toBe(5)
    expect(saturatedBasis.slice(0, 2)).toEqual([
      expect.objectContaining({
        conceptId: predecessor.conceptId,
        purpose: 'HELPER_TASK_USER_EVIDENCE_CONNECTION',
      }),
      expect.objectContaining({
        conceptId: current.conceptId,
        purpose: 'HELPER_TASK_USER_EVIDENCE_CONNECTION',
      }),
    ])
    expect(
      saturatedBasis.filter((item) => oldLexicalConceptIds.includes(item.conceptId)),
    ).toHaveLength(3)
    expect(saturated.data.relevantLedgerEntries.map((item) => item.concept.id)).toEqual(
      expect.arrayContaining([predecessor.conceptId, current.conceptId]),
    )
  })
})

const enrichmentFor = (position: number) => {
  const preview = previewFor(position)
  return {
    schemaVersion: 1 as const,
    previewRoundId,
    discoverySessionId: ids.discoverySession,
    correlationId: ids.correlation,
    candidate: {
      schemaVersion: 1 as const,
      id: preview.candidateId,
      discoverySessionId: ids.discoverySession,
      correlationId: ids.correlation,
      revision: 1,
      parentRevisions: [],
      title: preview.title,
      summary: preview.summary,
      targetUsers: [`Learner ${String(position)}`],
      coreInteraction: preview.coreInteraction,
      usageMoment: `While practicing direction ${String(position)}.`,
      appeal: preview.appeal,
      technologyNecessity: preview.technologyNecessity,
      coreConcepts: ['runtime validation', `concept ${String(position)}`],
      mvpFeatures: ['Enter one example', 'Inspect one result'],
      suggestedScope: {
        learnerFocus: ['Model the core state'],
        agentSupport: ['Prepare the local shell'],
        excluded: ['Cloud sync'],
      },
      generationTags: preview.generationTags,
      createdAt: timestamp,
      source: { kind: 'AGENT' as const, role: 'DISCOVERY' as const },
      redactionStatus: 'NOT_REQUIRED' as const,
    },
    createdAt: timestamp,
    source: { kind: 'AGENT' as const, role: 'DISCOVERY' as const },
    redactionStatus: 'NOT_REQUIRED' as const,
  }
}

const previewCommand = {
  schemaVersion: 1 as const,
  kind: 'DISCOVERY_SUBMIT_CANDIDATE_PREVIEWS' as const,
  correlationId: ids.correlation,
  actor: { kind: 'AGENT' as const, role: 'DISCOVERY' as const },
  idempotencyKey: 'idem_00000000-0000-4000-8000-000000000501',
  expectedSessionRevision: 1,
  previewRound: {
    schemaVersion: 1 as const,
    id: previewRoundId,
    finalRoundId: previewFinalRoundId,
    discoverySessionId: ids.discoverySession,
    correlationId: ids.correlation,
    inputSnapshot: discoveryInputFixture,
    previews: Array.from({ length: 10 }, (_, index) => previewFor(index + 1)),
    generationRationale: 'Ten distinct interaction directions were selected before enrichment.',
    createdAt: timestamp,
    source: { kind: 'AGENT' as const, role: 'DISCOVERY' as const },
    redactionStatus: 'NOT_REQUIRED' as const,
  },
}

const seedSpecReview = (
  storage: Awaited<ReturnType<typeof openInMemorySqliteStorage>>,
  includeDraft = false,
  expectedDecisions: typeof draftLearningSpecFixture.expectedDecisions = draftLearningSpecFixture.expectedDecisions,
): void => {
  storage.transaction((repository) => {
    repository.appendProject(
      projectSchema.parse({
        ...projectFixture,
        status: 'DISCOVERY',
        generatedWorkspacePath: undefined,
      }),
    )
    repository.appendDiscoverySession(discoverySessionSchema.parse(discoverySessionFixture))
    repository.appendCandidate(projectCandidateRevisionSchema.parse(candidateFixture))
    repository.appendCandidateRound(candidateRoundSchema.parse(candidateRoundFixture))
    repository.appendDiscoveryFeedback(discoveryFeedbackSchema.parse(discoveryFeedbackFixture))
    repository.appendDiscoverySession(
      discoverySessionSchema.parse({
        ...discoverySessionFixture,
        revision: 2,
        status: 'SELECTED',
        closedAt: timestamp,
      }),
    )
    repository.appendProject(
      projectSchema.parse({
        ...projectFixture,
        revision: 2,
        status: 'SPEC_REVIEW',
        generatedWorkspacePath: undefined,
      }),
    )
    if (includeDraft) {
      repository.appendLearningSpec(
        learningSpecRevisionSchema.parse({ ...draftLearningSpecFixture, expectedDecisions }),
      )
    }
  })
}

const seedBuilderGraph = (
  storage: Awaited<ReturnType<typeof openInMemorySqliteStorage>>,
  emptyDecisionForecast = false,
): void => {
  storage.transaction((repository) => {
    repository.appendProject(projectSchema.parse(projectFixture))
    repository.appendDiscoverySession(discoverySessionSchema.parse(discoverySessionFixture))
    repository.appendCandidate(projectCandidateRevisionSchema.parse(candidateFixture))
    repository.appendCandidateRound(candidateRoundSchema.parse(candidateRoundFixture))
    repository.appendDiscoveryFeedback(discoveryFeedbackSchema.parse(discoveryFeedbackFixture))
    repository.appendLearningSpec(
      learningSpecRevisionSchema.parse({
        ...draftLearningSpecFixture,
        ...(emptyDecisionForecast ? { expectedDecisions: [] } : {}),
      }),
    )
    repository.appendLearningSpec(
      learningSpecRevisionSchema.parse({
        ...confirmedLearningSpecFixture,
        ...(emptyDecisionForecast ? { expectedDecisions: [] } : {}),
      }),
    )
    repository.appendTask(
      builderTaskSchema.parse({
        ...builderTaskFixture,
        ...(emptyDecisionForecast ? { expectedDecisionCategories: [] } : {}),
      }),
    )
  })
}

describe('ApplicationService boundary', () => {
  it('keeps preview identity durable and materializes the full Candidate Round only after both enrichment batches', async () => {
    const { service, storage } = await createHarness()
    storage.transaction((repository) => {
      repository.appendProject(
        projectSchema.parse({
          ...projectFixture,
          status: 'DISCOVERY',
          generatedWorkspacePath: undefined,
        }),
      )
      repository.appendDiscoverySession(discoverySessionSchema.parse(discoverySessionFixture))
    })

    await expect(service.executeAgent('DISCOVERY', previewCommand)).resolves.toMatchObject({
      success: true,
      data: { resourceRevision: 1 },
    })
    expect(storage.repository.readDiscoveryAggregate(ids.project)).toMatchObject({
      session: { revision: 1 },
      previewRound: {
        id: previewRoundId,
        previews: expect.arrayContaining([expect.objectContaining({ position: 10 })]),
      },
      candidateEnrichments: [],
      candidates: [],
      rounds: [],
    })

    const submitBatch = (batch: 'FIRST' | 'SECOND', start: number, idempotencyKey: string) =>
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_SUBMIT_CANDIDATE_ENRICHMENTS',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        idempotencyKey,
        expectedSessionRevision: 1,
        previewRoundId,
        batch,
        enrichments: Array.from({ length: 5 }, (_, index) => enrichmentFor(start + index)),
      })

    await expect(
      submitBatch('FIRST', 1, 'idem_00000000-0000-4000-8000-000000000502'),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 1 } })
    expect(storage.repository.readDiscoveryAggregate(ids.project)).toMatchObject({
      session: { revision: 1 },
      candidateEnrichments: expect.arrayContaining([
        expect.objectContaining({
          candidate: expect.objectContaining({ id: previewCandidateId(1) }),
        }),
      ]),
      candidates: [],
      rounds: [],
    })

    await expect(
      submitBatch('SECOND', 6, 'idem_00000000-0000-4000-8000-000000000503'),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 2 } })
    const completed = storage.repository.readDiscoveryAggregate(ids.project)
    expect(completed).toMatchObject({
      session: { revision: 2 },
      previewRound: { id: previewRoundId },
      candidateEnrichments: expect.arrayContaining([
        expect.objectContaining({
          candidate: expect.objectContaining({ id: previewCandidateId(10) }),
        }),
      ]),
      rounds: [
        {
          id: previewFinalRoundId,
          roundIndex: 1,
          candidates: expect.arrayContaining([
            expect.objectContaining({ candidateId: previewCandidateId(1), revision: 1 }),
            expect.objectContaining({ candidateId: previewCandidateId(10), revision: 1 }),
          ]),
        },
      ],
    })
    expect(completed?.candidateEnrichments).toHaveLength(10)
    expect(completed?.candidates).toHaveLength(10)
    expect(completed?.rounds[0]?.candidates).toHaveLength(10)

    // Core returns the stored receipt before checking the now-advanced Session.
    await expect(
      submitBatch('SECOND', 6, 'idem_00000000-0000-4000-8000-000000000503'),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 2 } })
    await expect(
      submitBatch('FIRST', 1, 'idem_00000000-0000-4000-8000-000000000503'),
    ).resolves.toMatchObject({
      success: false,
      error: { code: 'IDEMPOTENCY_KEY_REUSE' },
    })
    await expect(
      submitBatch('SECOND', 6, 'idem_00000000-0000-4000-8000-000000000508'),
    ).resolves.toMatchObject({
      success: false,
      error: { code: 'DISCOVERY_SESSION_STALE' },
    })
  })

  it('keeps the atomic Candidate Round fallback available after previews and rejects late enrichment', async () => {
    const { service, storage } = await createHarness()
    storage.transaction((repository) => {
      repository.appendProject(
        projectSchema.parse({
          ...projectFixture,
          status: 'DISCOVERY',
          generatedWorkspacePath: undefined,
        }),
      )
      repository.appendDiscoverySession(discoverySessionSchema.parse(discoverySessionFixture))
    })
    await service.executeAgent('DISCOVERY', previewCommand)

    await expect(
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_SUBMIT_CANDIDATE_ROUND',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000504',
        expectedSessionRevision: 1,
        round: candidateRoundFixture,
        candidates: [candidateFixture],
      }),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 2 } })

    await expect(
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_SUBMIT_CANDIDATE_ENRICHMENTS',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000505',
        expectedSessionRevision: 1,
        previewRoundId,
        batch: 'FIRST',
        enrichments: Array.from({ length: 5 }, (_, index) => enrichmentFor(index + 1)),
      }),
    ).resolves.toMatchObject({
      success: false,
      error: { code: 'DISCOVERY_SESSION_STALE', category: 'STALE_CONTEXT' },
    })
    expect(storage.repository.readDiscoveryAggregate(ids.project)).toMatchObject({
      session: { revision: 2 },
      previewRound: { id: previewRoundId },
      candidateEnrichments: [],
      rounds: [{ id: candidateRoundFixture.id }],
      candidates: [{ id: candidateFixture.id }],
    })
  })

  it('materializes only selected previews and applies feedback without waiting for background enrichment', async () => {
    const { service, storage } = await createHarness()
    storage.transaction((repository) => {
      repository.appendProject(
        projectSchema.parse({
          ...projectFixture,
          status: 'DISCOVERY',
          generatedWorkspacePath: undefined,
        }),
      )
      repository.appendDiscoverySession(discoverySessionSchema.parse(discoverySessionFixture))
    })
    await service.executeAgent('DISCOVERY', previewCommand)

    await expect(
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_SUBMIT_CANDIDATE_ENRICHMENTS',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000506',
        expectedSessionRevision: 1,
        previewRoundId,
        batch: 'SELECTED',
        enrichments: [enrichmentFor(3)],
      }),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 1 } })

    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RECORD_DISCOVERY_FEEDBACK',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000507',
        expectedSessionRevision: 1,
        feedback: {
          schemaVersion: 1,
          id: 'feedback_00000000-0000-4000-8000-000000000507',
          discoverySessionId: ids.discoverySession,
          roundId: previewFinalRoundId,
          correlationId: ids.correlation,
          intent: 'SELECT',
          targets: [{ candidateId: previewCandidateId(3), revision: 1 }],
          createdAt: timestamp,
          source: { kind: 'USER' },
          redactionStatus: 'NOT_REQUIRED',
        },
      }),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 2 } })

    const selected = storage.repository.readDiscoveryAggregate(ids.project)
    expect(selected).toMatchObject({
      project: { status: 'SPEC_REVIEW' },
      session: { status: 'SELECTED', revision: 2 },
      rounds: [
        {
          id: previewFinalRoundId,
          candidates: [{ candidateId: previewCandidateId(3), revision: 1 }],
        },
      ],
      candidates: [{ id: previewCandidateId(3), revision: 1 }],
    })
    expect(selected?.candidateEnrichments).toHaveLength(1)

    await expect(
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_SUBMIT_CANDIDATE_ENRICHMENTS',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000508',
        expectedSessionRevision: 1,
        previewRoundId,
        batch: 'FIRST',
        enrichments: Array.from({ length: 5 }, (_, index) => enrichmentFor(index + 1)),
      }),
    ).resolves.toMatchObject({
      success: false,
      error: { code: 'DISCOVERY_SESSION_STALE', category: 'STALE_CONTEXT' },
    })
  })

  it('lists durable Project History and restores the current session read model', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)
    storage.transaction((repository) => {
      repository.appendLiveContext(liveContextFixture)
      repository.appendDecisionRequest(decisionRequestFixture)
    })

    const exchange = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RECORD_HELPER_EXCHANGE',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000401',
      projectId: ids.project,
      taskId: ids.task,
      decisionId: ids.decision,
      conversationId: ids.conversation,
      userMessage: 'token=synthetic-secret should be redacted before recovery.',
      helperResponseSummary: 'Compared strict and permissive runtime validation.',
      closeConversation: false,
    })
    expect(exchange).toMatchObject({ success: true, data: { status: 'OPEN' } })

    const history = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_LIST_PROJECTS',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      limit: 25,
    })
    expect(history).toMatchObject({
      success: true,
      data: {
        projects: [
          {
            project: { id: ids.project, status: 'BUILDING' },
            suggestedSurface: 'BUILD',
            activeTask: { id: ids.task, status: 'ACTIVE' },
            pendingDecisionCount: 1,
            currentContextVersion: 1,
            helperConversationCount: 1,
          },
        ],
      },
    })

    const restored = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RESTORE_PROJECT_SESSION',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      projectId: ids.project,
      helperConversationLimit: 10,
    })
    expect(restored).toMatchObject({
      success: true,
      data: {
        project: { id: ids.project },
        suggestedSurface: 'BUILD',
        activeTask: { id: ids.task },
        currentTask: { id: ids.task },
        liveContext: { id: ids.context, contextVersion: 1 },
        pendingDecisions: [{ id: ids.decision }],
        helperConversations: [
          {
            conversationId: ids.conversation,
            status: 'OPEN',
            redactedUserExcerpts: ['token=[REDACTED] should be redacted before recovery.'],
            helperResponseSummaries: ['Compared strict and permissive runtime validation.'],
          },
        ],
      },
    })
    expect(JSON.stringify(restored)).not.toContain('synthetic-secret')
  })

  it('returns the canonical Builder workspace only for an available matching Task', async () => {
    const { service, storage, workspacePolicy } = await createHarness()
    seedBuilderGraph(storage)

    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_PREPARE_BUILDER_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        taskId: ids.task,
      }),
    ).resolves.toEqual({
      success: true,
      data: {
        schemaVersion: 1,
        correlationId: ids.correlation,
        projectId: ids.project,
        taskId: ids.task,
        workspaceDirectory: join(workspacePolicy.generatedWorkspaceRoot, 'generated/webhook-lens'),
        status: 'READY',
      },
    })

    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_PREPARE_BUILDER_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        taskId: 'task_00000000-0000-4000-8000-999999999999',
      }),
    ).resolves.toMatchObject({
      success: false,
      error: { code: 'BUILDER_TASK_NOT_FOUND' },
    })

    storage.repository.appendTask(
      builderTaskSchema.parse({
        ...builderTaskFixture,
        revision: 2,
        status: 'COMPLETED',
      }),
    )
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_PREPARE_BUILDER_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        taskId: ids.task,
      }),
    ).resolves.toMatchObject({
      success: false,
      error: { code: 'BUILDER_SESSION_NOT_AVAILABLE' },
    })
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_PREPARE_BUILDER_SESSION',
        purpose: 'WORKSPACE_VIEW',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        taskId: ids.task,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        status: 'READY',
        workspaceDirectory: join(workspacePolicy.generatedWorkspaceRoot, 'generated/webhook-lens'),
      },
    })
    expect(storage.repository.readBuilderTaskAggregate(ids.project, ids.task)?.task).toMatchObject({
      revision: 2,
      status: 'COMPLETED',
    })
  })

  it('persists and replays an idempotent UI command, but rejects key reuse', async () => {
    const { service, storage } = await createHarness()
    const request = {
      schemaVersion: 1,
      kind: 'UI_START_DISCOVERY',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: ids.idempotency,
      projectId: ids.project,
      input: discoveryInputFixture,
    } as const

    const first = await service.executeUi(request)
    const replay = await service.executeUi(request)

    expect(first).toEqual(replay)
    expect(first).toMatchObject({
      success: true,
      data: { accepted: true, resourceRevision: 1 },
    })
    expect(storage.repository.readDiscoveryAggregate(ids.project)?.session.revision).toBe(1)

    const conflict = await service.executeUi({
      ...request,
      input: { ...request.input, learningGoal: 'A different goal' },
    })
    expect(conflict).toMatchObject({
      success: false,
      error: { kind: 'OPERATION_ERROR', code: 'IDEMPOTENCY_KEY_REUSE' },
    })
  })

  it('rejects role escalation before dispatching any use case', async () => {
    const { service } = await createHarness()
    const result = await service.executeAgent('HELPER', {
      schemaVersion: 1,
      kind: 'BUILDER_START_TASK',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'BUILDER' },
      idempotencyKey: ids.idempotency,
      projectId: ids.project,
      taskId: ids.task,
      expectedTaskRevision: 1,
    })

    expect(result).toMatchObject({
      success: false,
      error: {
        kind: 'CONTRACT_ERROR',
        category: 'PERMISSION',
        code: 'AGENT_PERMISSION_MISMATCH',
      },
    })
  })

  it('returns a retryable stale-context error without mutating the task', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)

    const result = await service.executeAgent('BUILDER', {
      schemaVersion: 1,
      kind: 'BUILDER_START_TASK',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'BUILDER' },
      idempotencyKey: ids.idempotency,
      projectId: ids.project,
      taskId: ids.task,
      expectedTaskRevision: 0,
    })

    expect(result).toMatchObject({
      success: false,
      error: {
        kind: 'OPERATION_ERROR',
        category: 'STALE_CONTEXT',
        code: 'BUILDER_TASK_STALE',
        disposition: 'RETRYABLE',
      },
    })
    expect(storage.repository.recoverProject(ids.project)?.activeTask?.revision).toBe(1)
  })

  it('rejects canonical paths that escape through a workspace symlink', async () => {
    const { workspacePolicy, workspaceRoot } = await createHarness()
    const project = projectSchema.parse(projectFixture)
    const projectWorkspace = join(workspaceRoot, 'generated', 'webhook-lens')
    const outside = await mkdtemp(join(tmpdir(), 'vibe-helper-outside-workspace-'))
    await mkdir(projectWorkspace, { recursive: true })
    await symlink(outside, join(projectWorkspace, 'escape'), 'junction')

    await expect(
      workspacePolicy.validateReferences(
        project,
        { kind: 'CODE', path: 'escape/secret.ts' },
        ids.correlation,
      ),
    ).rejects.toMatchObject<ApplicationError>({
      operationError: {
        kind: 'OPERATION_ERROR',
        category: 'PERMISSION',
        code: 'WORKSPACE_PATH_ESCAPE',
      },
    })
  })

  it('rejects a Builder context update that references a path outside its workspace', async () => {
    const { service, storage, workspaceRoot } = await createHarness()
    seedBuilderGraph(storage)
    const projectWorkspace = join(workspaceRoot, 'generated', 'webhook-lens')
    const outside = await mkdtemp(join(tmpdir(), 'vibe-helper-builder-escape-'))
    await mkdir(projectWorkspace, { recursive: true })
    await symlink(outside, join(projectWorkspace, 'escape'), 'junction')

    const result = await service.executeAgent('BUILDER', {
      schemaVersion: 1,
      kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'BUILDER' },
      idempotencyKey: ids.idempotency,
      context: {
        ...liveContextFixture,
        relatedFiles: [
          {
            ...liveContextFixture.relatedFiles[0],
            path: 'escape/secret.ts',
          },
        ],
      },
    })

    expect(result).toMatchObject({
      success: false,
      error: {
        kind: 'OPERATION_ERROR',
        category: 'PERMISSION',
        code: 'WORKSPACE_PATH_ESCAPE',
      },
    })
    expect(storage.repository.recoverProject(ids.project)?.liveContext).toBeNull()
  })

  it('enforces the application payload cap before contract dispatch', async () => {
    const { service } = await createHarness()
    const result = await service.executeAgent('HELPER', {
      schemaVersion: 1,
      kind: 'HELPER_GET_CONTEXT',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'HELPER' },
      projectId: ids.project,
      question: 'x'.repeat(2 * 1024 * 1024),
      relatedConceptNames: [],
    })

    expect(result).toMatchObject({
      success: false,
      error: { kind: 'OPERATION_ERROR', code: 'PAYLOAD_TOO_LARGE' },
    })
  })

  it('persists a missing Context refresh request and fulfills it on the next Builder Context', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)

    await expect(
      service.executeAgent('HELPER', {
        schemaVersion: 1,
        kind: 'HELPER_GET_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'HELPER' },
        projectId: ids.project,
        taskId: ids.task,
        question: 'What is happening now?',
        relatedConceptNames: [],
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        relevantLedgerEntries: [],
        freshness: {
          currentContextVersion: null,
          status: 'MISSING',
          stale: true,
          refreshRequired: true,
        },
      },
    })

    const refreshCommand = {
      schemaVersion: 1,
      kind: 'HELPER_REQUEST_CONTEXT_REFRESH',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'HELPER' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000201',
      projectId: ids.project,
      taskId: ids.task,
      reason: 'Context is missing; apiKey=do-not-store from /Users/example/private.',
    } as const
    const firstRefresh = await service.executeAgent('HELPER', refreshCommand)
    expect(await service.executeAgent('HELPER', refreshCommand)).toEqual(firstRefresh)
    expect(firstRefresh).toMatchObject({ success: true, data: { resourceRevision: 1 } })

    const pending = storage.repository.readBuilderTaskAggregate(ids.project, ids.task)
      ?.contextRefreshRequests[0]
    expect(pending).toMatchObject({ status: 'PENDING', revision: 1 })
    expect(pending?.reason).toContain('[REDACTED]')
    expect(pending?.reason).not.toContain('do-not-store')
    expect(pending?.reason).not.toContain('/Users/example')
    await expect(
      service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_GET_TASK',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        projectId: ids.project,
        taskId: ids.task,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: { pendingContextRefreshRequests: [{ status: 'PENDING' }] },
    })

    const firstContext = {
      ...liveContextFixture,
      checkpoint: 'TASK_STARTED' as const,
      activeDecisionIds: [],
      blockingReason: undefined,
    }
    await expect(
      service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000202',
        context: firstContext,
      }),
    ).resolves.toMatchObject({ success: true })

    expect(
      storage.repository.readBuilderTaskAggregate(ids.project, ids.task)?.contextRefreshRequests,
    ).toEqual([
      expect.objectContaining({
        id: pending?.id,
        revision: 2,
        status: 'FULFILLED',
        fulfilledByContextVersion: 1,
      }),
    ])
  })

  it('assembles focused, redacted Helper context and remains available after Task completion', async () => {
    const { service, storage, workspaceRoot } = await createHarness()
    seedBuilderGraph(storage)
    const sourceDirectory = join(
      workspaceRoot,
      ...projectFixture.generatedWorkspacePath.split('/'),
      'src',
    )
    await mkdir(sourceDirectory, { recursive: true })
    await writeFile(
      join(sourceDirectory, 'events.ts'),
      'const apiKey = "do-not-expose";\nexport const config = { "clientSecret": "do-not-expose-json" };\nexport const rejectUnknown = true;\n',
      'utf8',
    )
    storage.transaction((repository) => {
      repository.appendLiveContext(liveContextFixture)
      repository.appendDecisionRequest(decisionRequestSchema.parse(decisionRequestFixture))
      repository.appendDecisionResolution(decisionResolutionFixture)
      repository.appendActivityEvent(activityEventSchema.parse(activityEventFixture))
      repository.appendActivityEvent(activityEventSchema.parse(reasonedDecisionEvent))
      repository.appendEpisode(
        episodeSchema.parse({
          ...episodeFixture,
          eventIds: [ids.eventUser, reasonedDecisionEvent.id],
        }),
      )
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobPendingFixture))
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobFixture))
      repository.appendCanonicalConcept(canonicalConceptSchema.parse(canonicalConceptFixture))
    })
    await expect(
      service.executeAgent('EVIDENCE_ANALYST', {
        schemaVersion: 1,
        kind: 'ANALYST_SUBMIT_EVIDENCE_PROPOSALS',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'EVIDENCE_ANALYST' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000203',
        analysisJobId: ids.analysisJob,
        expectedJobRevision: 2,
        attempt: 1,
        batch: reasonedEvidenceBatch,
      }),
    ).resolves.toMatchObject({ success: true })

    await expect(
      service.executeAgent('HELPER', {
        schemaVersion: 1,
        kind: 'HELPER_GET_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'HELPER' },
        projectId: ids.project,
        taskId: ids.task,
        decisionId: ids.decision,
        question: 'How does runtime validation affect this Decision?',
        relatedConceptNames: ['runtime validation'],
        observedContextVersion: 1,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        focusedDecision: { id: ids.decision },
        relevantLedgerEntries: [{ state: { state: 'DEMONSTRATED' } }],
        personalization: {
          mode: 'EVIDENCE_AWARE',
          basis: [
            {
              conceptName: 'runtime validation',
              state: 'DEMONSTRATED',
              purpose: 'HELPER_TASK_USER_EVIDENCE_CONNECTION',
              sourceProjectIds: [ids.project],
            },
          ],
        },
        recentEpisodes: [
          {
            episodeId: ids.episode,
            redactedUserExcerpts: ['Rejecting unknown fields should catch typos at the boundary.'],
          },
        ],
        sourceExcerpts: [
          {
            reference: { kind: 'CODE', path: 'src/events.ts' },
            redactionStatus: 'VERIFIED_REDACTED',
          },
        ],
        referenceDetails: [{ availability: 'EXCERPT_INCLUDED' }],
        freshness: { status: 'CURRENT', refreshRequired: false },
      },
    })
    const helper = await service.executeAgent('HELPER', {
      schemaVersion: 1,
      kind: 'HELPER_GET_CONTEXT',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'HELPER' },
      projectId: ids.project,
      taskId: ids.task,
      question: 'Show the current code.',
      relatedConceptNames: [],
    })
    expect(helper.success && helper.data).toMatchObject({
      sourceExcerpts: [
        expect.objectContaining({ redactedExcerpt: expect.stringContaining('[REDACTED]') }),
      ],
    })
    expect(JSON.stringify(helper)).not.toContain('do-not-expose')
    expect(JSON.stringify(helper)).not.toContain('do-not-expose-json')

    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_READ_EVIDENCE_TRACE',
        correlationId: 'corr_00000000-0000-4000-8000-000000000240',
        actor: { kind: 'UI' },
        projectId: ids.project,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        projectId: ids.project,
        concepts: [
          {
            conceptName: 'runtime validation',
            state: 'DEMONSTRATED',
            evidence: [
              {
                projectId: ids.project,
                redactedEvidenceExcerpt: decisionResolutionFixture.rationale,
              },
            ],
          },
        ],
        personalization: [expect.objectContaining({ mode: 'EVIDENCE_AWARE' })],
      },
    })

    const nextProjectId = 'project_00000000-0000-4000-8000-000000000241'
    const nextCorrelationId = 'corr_00000000-0000-4000-8000-000000000242'
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_START_DISCOVERY',
        correlationId: nextCorrelationId,
        actor: { kind: 'UI' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000243',
        projectId: nextProjectId,
        input: {
          learningGoal: 'Use runtime validation in another local tool',
          interestAreas: ['developer tools'],
          currentLevel: 'BEGINNER',
        },
      }),
    ).resolves.toMatchObject({ success: true })
    const nextSession = storage.repository.recoverProject(nextProjectId)?.discoverySession
    expect(nextSession).not.toBeNull()
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESTORE_PROJECT_SESSION',
        correlationId: 'corr_00000000-0000-4000-8000-000000000244',
        actor: { kind: 'UI' },
        projectId: nextProjectId,
        helperConversationLimit: 20,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: { discoveryContext: { personalization: { mode: 'EVIDENCE_AWARE' } } },
    })
    expect(storage.repository.readPersonalizationTracesForProject(nextProjectId, 10)).toEqual([])
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_PREPARE_DISCOVERY_AGENT_CONTEXT',
        correlationId: 'corr_00000000-0000-4000-8000-000000000245',
        actor: { kind: 'UI' },
        projectId: nextProjectId,
        helperConversationLimit: 20,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        discoveryContext: {
          personalization: {
            mode: 'EVIDENCE_AWARE',
            correlationId: nextCorrelationId,
          },
        },
      },
    })
    expect(storage.repository.readPersonalizationTracesForProject(nextProjectId, 10)).toHaveLength(
      1,
    )
    await expect(
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_GET_CONTEXT',
        correlationId: nextCorrelationId,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        projectId: nextProjectId,
        discoverySessionId: nextSession?.id,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        relevantLedgerEntries: [{ state: { state: 'DEMONSTRATED' } }],
        personalization: {
          mode: 'EVIDENCE_AWARE',
          basis: [
            {
              conceptName: 'runtime validation',
              purpose: 'DISCOVERY_TIE_BREAK',
              sourceProjectIds: [ids.project],
            },
          ],
        },
      },
    })

    storage.transaction((repository) => {
      repository.appendTask(
        builderTaskSchema.parse({
          ...builderTaskFixture,
          revision: 2,
          status: 'COMPLETED',
        }),
      )
    })
    await expect(
      service.executeAgent('HELPER', {
        schemaVersion: 1,
        kind: 'HELPER_GET_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'HELPER' },
        projectId: ids.project,
        question: 'Can I still ask about the completed Task?',
        relatedConceptNames: ['runtime validation'],
      }),
    ).resolves.toMatchObject({ success: true, data: { task: { status: 'COMPLETED' } } })
  })

  it('applies Analyst proposals through deterministic Evidence reducers and replays the result', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)
    storage.transaction((repository) => {
      repository.appendDecisionRequest(decisionRequestSchema.parse(decisionRequestFixture))
      repository.appendDecisionResolution(decisionResolutionFixture)
      repository.appendActivityEvent(activityEventSchema.parse(activityEventFixture))
      repository.appendActivityEvent(activityEventSchema.parse(reasonedDecisionEvent))
      repository.appendEpisode(
        episodeSchema.parse({
          ...episodeFixture,
          eventIds: [ids.eventUser, reasonedDecisionEvent.id],
        }),
      )
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobPendingFixture))
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobFixture))
      repository.appendCanonicalConcept(canonicalConceptSchema.parse(canonicalConceptFixture))
    })
    const request = {
      schemaVersion: 1,
      kind: 'ANALYST_SUBMIT_EVIDENCE_PROPOSALS',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'EVIDENCE_ANALYST' },
      idempotencyKey: ids.idempotency,
      analysisJobId: ids.analysisJob,
      expectedJobRevision: 2,
      attempt: 1,
      batch: reasonedEvidenceBatch,
    } as const

    const applied = await service.executeAgent('EVIDENCE_ANALYST', request)
    const replay = await service.executeAgent('EVIDENCE_ANALYST', request)

    expect(applied).toEqual(replay)
    expect(applied).toMatchObject({
      success: true,
      data: {
        episodeId: ids.episode,
        outcomes: [
          {
            proposalId: ids.evidenceProposal,
            decision: { outcome: 'ACCEPTED', reasonCode: 'VALID_USER_EVIDENCE' },
            conceptId: ids.concept,
            ledgerRevision: 1,
          },
        ],
      },
    })
    expect(storage.repository.readEvidenceTrace(ids.concept)).toMatchObject({
      ledger: { state: { state: 'DEMONSTRATED' } },
      acceptedEvidence: [{ evidenceProposalId: ids.evidenceProposal }],
    })
  })

  it('accepts the exact clean independent explanation used by the personalization eval plan', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)
    const statement =
      '가구의 오른쪽 좌표는 x와 너비의 합이므로 그 값이 방 너비보다 크면 가구가 방 밖으로 나간 상태예요.'
    const expression = '가구의 오른쪽 좌표는 x와 너비의 합'
    storage.transaction((repository) => {
      repository.appendActivityEvent(
        activityEventSchema.parse({
          ...activityEventFixture,
          payload: { ...activityEventFixture.payload, redactedExcerpt: statement },
        }),
      )
      repository.appendEpisode(
        episodeSchema.parse({
          ...episodeFixture,
          decisionId: undefined,
          type: 'HELPER_CONVERSATION',
          conceptCandidates: [{ conceptId: ids.concept, originalExpression: expression }],
          contextReferences: [],
        }),
      )
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobPendingFixture))
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobFixture))
      repository.appendCanonicalConcept(canonicalConceptSchema.parse(canonicalConceptFixture))
    })
    const sourceProposal = evidenceProposalBatchFixture.proposals[0]
    if (sourceProposal === undefined) throw new Error('Evidence fixture Proposal is missing')

    const result = await service.executeAgent('EVIDENCE_ANALYST', {
      schemaVersion: 1,
      kind: 'ANALYST_SUBMIT_EVIDENCE_PROPOSALS',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'EVIDENCE_ANALYST' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000761',
      analysisJobId: ids.analysisJob,
      expectedJobRevision: 2,
      attempt: 1,
      batch: {
        ...evidenceProposalBatchFixture,
        proposals: [
          {
            ...sourceProposal,
            concept: { ...sourceProposal.concept, originalExpression: expression },
            signal: 'REPHRASE',
            strength: 'STRONG',
            promptDependence: 'INDEPENDENT',
            redactedEvidenceExcerpt: statement,
            rationale: 'The user independently explained the boundary invariant.',
            maximumSupportedState: 'EXPLAINED',
          },
        ],
      },
    })

    expect(result).toMatchObject({
      success: true,
      data: {
        outcomes: [
          {
            proposalId: ids.evidenceProposal,
            decision: { outcome: 'ACCEPTED', reasonCode: 'VALID_USER_EVIDENCE' },
            conceptId: ids.concept,
            ledgerRevision: 1,
          },
        ],
      },
    })
    expect(storage.repository.readEvidenceTrace(ids.concept)).toMatchObject({
      ledger: { state: { state: 'EXPLAINED' } },
      acceptedEvidence: [
        {
          signal: 'REPHRASE',
          promptDependence: 'INDEPENDENT',
          supportsState: 'EXPLAINED',
        },
      ],
    })
  })

  it('preserves an unverified user-message quote as a rejected Proposal without raising Concept State', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)
    storage.transaction((repository) => {
      repository.appendDecisionRequest(decisionRequestSchema.parse(decisionRequestFixture))
      repository.appendActivityEvent(activityEventSchema.parse(activityEventFixture))
      repository.appendEpisode(episodeSchema.parse(episodeFixture))
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobPendingFixture))
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobFixture))
      repository.appendCanonicalConcept(canonicalConceptSchema.parse(canonicalConceptFixture))
    })
    const sourceProposal = evidenceProposalBatchFixture.proposals[0]
    if (sourceProposal === undefined) throw new Error('Evidence fixture Proposal is missing')
    const batch = {
      ...evidenceProposalBatchFixture,
      proposals: [
        {
          ...sourceProposal,
          concept: {
            ...sourceProposal.concept,
            originalExpression: 'prevent input mistakes',
          },
          redactedEvidenceExcerpt: 'Strict validation should prevent input mistakes.',
        },
      ],
    }

    const result = await service.executeAgent('EVIDENCE_ANALYST', {
      schemaVersion: 1,
      kind: 'ANALYST_SUBMIT_EVIDENCE_PROPOSALS',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'EVIDENCE_ANALYST' },
      idempotencyKey: ids.idempotency,
      analysisJobId: ids.analysisJob,
      expectedJobRevision: 2,
      attempt: 1,
      batch,
    })

    expect(result).toMatchObject({
      success: true,
      data: {
        outcomes: [
          {
            proposalId: ids.evidenceProposal,
            decision: { outcome: 'REJECTED', reasonCode: 'INVALID_REFERENCE' },
          },
        ],
      },
    })
    expect(storage.repository.readEvidenceTrace(ids.concept)).toMatchObject({
      proposals: [{ id: ids.evidenceProposal }],
      decisions: [{ outcome: 'REJECTED', reasonCode: 'INVALID_REFERENCE' }],
      acceptedEvidence: [],
      ledger: null,
    })
    expect(storage.repository.readAnalysisJob(ids.project, ids.analysisJob)).toMatchObject({
      status: 'SUCCEEDED',
      resultSummary: { proposalCount: 1, acceptedCount: 0, rejectedCount: 1 },
    })
  })

  it('applies pinned, rejected, and regenerated Candidate feedback before explicit selection', async () => {
    const { service, storage } = await createHarness()
    const secondCandidateId = 'candidate_00000000-0000-4000-8000-000000000051'
    const thirdCandidateId = 'candidate_00000000-0000-4000-8000-000000000052'
    const regeneratedCandidateId = 'candidate_00000000-0000-4000-8000-000000000053'
    const secondRoundId = 'candidate_round_00000000-0000-4000-8000-000000000054'
    const pinFeedbackId = 'feedback_00000000-0000-4000-8000-000000000055'
    const rejectFeedbackId = 'feedback_00000000-0000-4000-8000-000000000056'
    const regenerateFeedbackId = 'feedback_00000000-0000-4000-8000-000000000057'
    const selectionFeedbackId = 'feedback_00000000-0000-4000-8000-000000000058'
    const secondCandidate = {
      ...candidateFixture,
      id: secondCandidateId,
      title: 'Typed Form State Lab',
      coreInteraction: 'Move a form through explicit state variants.',
    }
    const thirdCandidate = {
      ...candidateFixture,
      id: thirdCandidateId,
      title: 'API Change Radar',
      coreInteraction: 'Compare response variants and inspect typed compatibility changes.',
    }
    const discoveryProject = {
      ...projectFixture,
      status: 'DISCOVERY' as const,
      generatedWorkspacePath: undefined,
    }
    storage.transaction((repository) => {
      repository.appendProject(projectSchema.parse(discoveryProject))
      repository.appendDiscoverySession(discoverySessionSchema.parse(discoverySessionFixture))
    })

    const firstRound = {
      ...candidateRoundFixture,
      candidates: [
        { candidateId: ids.candidate, revision: 1 },
        { candidateId: secondCandidateId, revision: 1 },
        { candidateId: thirdCandidateId, revision: 1 },
      ],
    }
    const initial = await service.executeAgent('DISCOVERY', {
      schemaVersion: 1,
      kind: 'DISCOVERY_SUBMIT_CANDIDATE_ROUND',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'DISCOVERY' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000060',
      expectedSessionRevision: 1,
      round: firstRound,
      candidates: [candidateFixture, secondCandidate, thirdCandidate],
    })
    expect(initial).toMatchObject({ success: true, data: { resourceRevision: 2 } })

    const feedbackBase = {
      schemaVersion: 1 as const,
      discoverySessionId: ids.discoverySession,
      roundId: ids.candidateRound,
      correlationId: ids.correlation,
      createdAt: timestamp,
      source: { kind: 'USER' as const },
      redactionStatus: 'NOT_REQUIRED' as const,
    }
    const feedbackCommands = [
      {
        id: pinFeedbackId,
        intent: 'PIN' as const,
        targets: [{ candidateId: ids.candidate, revision: 1 }],
        message: 'Keep this candidate visible.',
      },
      {
        id: rejectFeedbackId,
        intent: 'REJECT' as const,
        targets: [{ candidateId: secondCandidateId, revision: 1 }],
        message: 'Remove this direction.',
      },
      {
        id: regenerateFeedbackId,
        intent: 'REGENERATE' as const,
        targets: [{ candidateId: thirdCandidateId, revision: 1 }],
        message: 'Replace this with a more practical direction.',
      },
    ]
    for (const [index, feedback] of feedbackCommands.entries()) {
      const result = await service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RECORD_DISCOVERY_FEEDBACK',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        idempotencyKey: `idem_00000000-0000-4000-8000-${String(61 + index).padStart(12, '0')}`,
        expectedSessionRevision: 2 + index,
        feedback: { ...feedbackBase, ...feedback },
      })
      expect(result).toMatchObject({ success: true, data: { resourceRevision: 3 + index } })
    }

    const regeneratedCandidate = {
      ...candidateFixture,
      id: regeneratedCandidateId,
      title: 'Runtime Contract Playground',
      coreInteraction: 'Try unknown payloads and inspect safe typed parsing branches.',
    }
    const secondRound = {
      ...candidateRoundFixture,
      id: secondRoundId,
      roundIndex: 2,
      appliedFeedbackIds: [pinFeedbackId, rejectFeedbackId, regenerateFeedbackId],
      candidates: [
        { candidateId: ids.candidate, revision: 1 },
        { candidateId: regeneratedCandidateId, revision: 1 },
      ],
      generationRationale:
        'The pinned option remains while rejected and regenerated options change.',
    }
    const refined = await service.executeAgent('DISCOVERY', {
      schemaVersion: 1,
      kind: 'DISCOVERY_SUBMIT_CANDIDATE_ROUND',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'DISCOVERY' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000064',
      expectedSessionRevision: 5,
      round: secondRound,
      candidates: [regeneratedCandidate],
    })
    expect(refined).toMatchObject({ success: true, data: { resourceRevision: 6 } })
    expect(storage.repository.readDiscoveryAggregate(ids.project)).toMatchObject({
      session: { status: 'ACTIVE', revision: 6 },
      rounds: [
        { roundIndex: 1, appliedFeedbackIds: [] },
        {
          roundIndex: 2,
          appliedFeedbackIds: [pinFeedbackId, rejectFeedbackId, regenerateFeedbackId],
          candidates: [
            { candidateId: ids.candidate, revision: 1 },
            { candidateId: regeneratedCandidateId, revision: 1 },
          ],
        },
      ],
      candidates: expect.arrayContaining([
        expect.objectContaining({ id: regeneratedCandidateId, revision: 1, parentRevisions: [] }),
      ]),
    })

    const staleSelection = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RECORD_DISCOVERY_FEEDBACK',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000065',
      expectedSessionRevision: 6,
      feedback: {
        ...feedbackBase,
        id: selectionFeedbackId,
        intent: 'SELECT',
        targets: [{ candidateId: ids.candidate, revision: 1 }],
      },
    })
    expect(staleSelection).toMatchObject({
      success: false,
      error: { code: 'DISCOVERY_ROUND_NOT_CURRENT' },
    })

    const selected = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RECORD_DISCOVERY_FEEDBACK',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000066',
      expectedSessionRevision: 6,
      feedback: {
        ...feedbackBase,
        id: selectionFeedbackId,
        roundId: secondRoundId,
        intent: 'SELECT',
        targets: [{ candidateId: regeneratedCandidateId, revision: 1 }],
      },
    })
    expect(selected).toMatchObject({ success: true, data: { resourceRevision: 7 } })
    expect(storage.repository.recoverProject(ids.project)).toMatchObject({
      project: { status: 'SPEC_REVIEW' },
      discoverySession: { status: 'SELECTED' },
      selectedCandidate: { id: regeneratedCandidateId, revision: 1 },
    })

    const postSelectionRound = await service.executeAgent('DISCOVERY', {
      schemaVersion: 1,
      kind: 'DISCOVERY_SUBMIT_CANDIDATE_ROUND',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'DISCOVERY' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000067',
      expectedSessionRevision: 7,
      round: { ...secondRound, id: ids.candidateRound, roundIndex: 3 },
      candidates: [],
    })
    expect(postSelectionRound).toMatchObject({
      success: false,
      error: { code: 'DISCOVERY_SESSION_NOT_ACTIVE' },
    })
  })

  it('adds MORE Candidates while preserving every current Candidate reference', async () => {
    const { service, storage } = await createHarness()
    const addedCandidateId = 'candidate_00000000-0000-4000-8000-000000000073'
    const moreFeedbackId = 'feedback_00000000-0000-4000-8000-000000000074'
    const nextRoundId = 'candidate_round_00000000-0000-4000-8000-000000000075'
    storage.transaction((repository) => {
      repository.appendProject(
        projectSchema.parse({
          ...projectFixture,
          status: 'DISCOVERY',
          generatedWorkspacePath: undefined,
        }),
      )
      repository.appendDiscoverySession(discoverySessionSchema.parse(discoverySessionFixture))
    })

    await expect(
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_SUBMIT_CANDIDATE_ROUND',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000073',
        expectedSessionRevision: 1,
        round: candidateRoundFixture,
        candidates: [candidateFixture],
      }),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 2 } })

    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RECORD_DISCOVERY_FEEDBACK',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000074',
        expectedSessionRevision: 2,
        feedback: {
          ...discoveryFeedbackFixture,
          id: moreFeedbackId,
          intent: 'MORE',
          targets: [],
          message: 'Keep this Candidate and add distinct directions.',
        },
      }),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 3 } })

    const addedCandidate = {
      ...candidateFixture,
      id: addedCandidateId,
      title: 'Typed Event Route Map',
      coreInteraction: 'Route variant-shaped events and inspect the safe branch selected for each.',
    }
    const added = await service.executeAgent('DISCOVERY', {
      schemaVersion: 1,
      kind: 'DISCOVERY_SUBMIT_CANDIDATE_ROUND',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'DISCOVERY' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000075',
      expectedSessionRevision: 3,
      round: {
        ...candidateRoundFixture,
        id: nextRoundId,
        roundIndex: 2,
        appliedFeedbackIds: [moreFeedbackId],
        candidates: [
          { candidateId: ids.candidate, revision: 1 },
          { candidateId: addedCandidateId, revision: 1 },
        ],
      },
      candidates: [addedCandidate],
    })

    expect(added).toMatchObject({ success: true, data: { resourceRevision: 4 } })
    expect(storage.repository.readDiscoveryAggregate(ids.project)).toMatchObject({
      rounds: [
        { roundIndex: 1 },
        {
          roundIndex: 2,
          appliedFeedbackIds: [moreFeedbackId],
          candidates: [
            { candidateId: ids.candidate, revision: 1 },
            { candidateId: addedCandidateId, revision: 1 },
          ],
        },
      ],
    })
  })

  it('narrows a MERGE Round to the merged result while preserving prior Candidates in history', async () => {
    const { service, storage } = await createHarness()
    const secondCandidateId = 'candidate_00000000-0000-4000-8000-000000000076'
    const thirdCandidateId = 'candidate_00000000-0000-4000-8000-000000000077'
    const fourthCandidateId = 'candidate_00000000-0000-4000-8000-000000000078'
    const mergeFeedbackId = 'feedback_00000000-0000-4000-8000-000000000079'
    const narrowRoundId = 'candidate_round_00000000-0000-4000-8000-000000000080'
    const secondCandidate = {
      ...candidateFixture,
      id: secondCandidateId,
      title: 'Scheduled Digest Worker',
    }
    const thirdCandidate = {
      ...candidateFixture,
      id: thirdCandidateId,
      title: 'Shared Resource Booking',
    }
    const fourthCandidate = {
      ...candidateFixture,
      id: fourthCandidateId,
      title: 'Monthly Spending Report',
    }
    storage.transaction((repository) => {
      repository.appendProject(
        projectSchema.parse({
          ...projectFixture,
          status: 'DISCOVERY',
          generatedWorkspacePath: undefined,
        }),
      )
      repository.appendDiscoverySession(discoverySessionSchema.parse(discoverySessionFixture))
    })

    await expect(
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_SUBMIT_CANDIDATE_ROUND',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000076',
        expectedSessionRevision: 1,
        round: {
          ...candidateRoundFixture,
          candidates: [candidateFixture, secondCandidate, thirdCandidate, fourthCandidate].map(
            (candidate) => ({ candidateId: candidate.id, revision: 1 }),
          ),
        },
        candidates: [candidateFixture, secondCandidate, thirdCandidate, fourthCandidate],
      }),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 2 } })

    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RECORD_DISCOVERY_FEEDBACK',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000077',
        expectedSessionRevision: 2,
        feedback: {
          ...discoveryFeedbackFixture,
          id: mergeFeedbackId,
          intent: 'MERGE',
          targets: [
            { candidateId: secondCandidateId, revision: 1 },
            { candidateId: thirdCandidateId, revision: 1 },
          ],
          message: 'Combine the autonomous schedule with the practical booking flow.',
        },
      }),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 3 } })

    const mergedCandidate = {
      ...secondCandidate,
      revision: 2,
      parentRevisions: [
        { candidateId: secondCandidateId, revision: 1 },
        { candidateId: thirdCandidateId, revision: 1 },
      ],
      title: 'Scheduled Resource Booking Keeper',
    }
    const carriedRound = {
      ...candidateRoundFixture,
      id: narrowRoundId,
      roundIndex: 2,
      appliedFeedbackIds: [mergeFeedbackId],
      candidates: [
        { candidateId: ids.candidate, revision: 1 },
        { candidateId: fourthCandidateId, revision: 1 },
        { candidateId: secondCandidateId, revision: 2 },
      ],
    }
    await expect(
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_SUBMIT_CANDIDATE_ROUND',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000078',
        expectedSessionRevision: 3,
        round: carriedRound,
        candidates: [mergedCandidate],
      }),
    ).resolves.toMatchObject({
      success: false,
      error: { code: 'CANDIDATE_ROUND_CONTENT_INVALID' },
    })

    await expect(
      service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_SUBMIT_CANDIDATE_ROUND',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000079',
        expectedSessionRevision: 3,
        round: {
          ...carriedRound,
          candidates: [{ candidateId: secondCandidateId, revision: 2 }],
        },
        candidates: [mergedCandidate],
      }),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 4 } })

    expect(storage.repository.readDiscoveryAggregate(ids.project)).toMatchObject({
      rounds: [
        { roundIndex: 1 },
        {
          roundIndex: 2,
          candidates: [{ candidateId: secondCandidateId, revision: 2 }],
        },
      ],
      candidates: expect.arrayContaining([
        expect.objectContaining({ id: ids.candidate, revision: 1 }),
        expect.objectContaining({ id: fourthCandidateId, revision: 1 }),
        expect.objectContaining({
          id: secondCandidateId,
          revision: 2,
          parentRevisions: [
            { candidateId: secondCandidateId, revision: 1 },
            { candidateId: thirdCandidateId, revision: 1 },
          ],
        }),
      ]),
    })
  })
})

describe('T09 Learning Spec application flow', () => {
  it('creates, directly revises, and confirms a draft without creating a Builder Task', async () => {
    const { service, storage } = await createHarness()
    seedSpecReview(storage)

    const submitRequest = {
      schemaVersion: 1,
      kind: 'DISCOVERY_SUBMIT_LEARNING_SPEC',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'DISCOVERY' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000081',
      expectedSessionRevision: 2,
      expectedSpecRevision: 0,
      learningSpec: draftLearningSpecFixture,
    } as const
    const submitted = await service.executeAgent('DISCOVERY', submitRequest)
    const replayed = await service.executeAgent('DISCOVERY', submitRequest)
    expect(submitted).toMatchObject({ success: true, data: { resourceRevision: 1 } })
    expect(replayed).toEqual(submitted)
    expect(storage.repository.recoverProject(ids.project)?.activeTask).toBeNull()
    expect(
      await service.executeAgent('DISCOVERY', {
        schemaVersion: 1,
        kind: 'DISCOVERY_GET_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'DISCOVERY' },
        projectId: ids.project,
        discoverySessionId: ids.discoverySession,
      }),
    ).toMatchObject({
      success: true,
      data: { session: { revision: 3 }, learningSpec: { id: ids.learningSpec, revision: 1 } },
    })

    const revisedDraft = {
      ...learningSpecDraftContentFixture,
      productPurpose: 'Compare redacted webhook variants locally before implementation.',
    }
    const revised = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_UPDATE_LEARNING_SPEC',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000082',
      projectId: ids.project,
      learningSpecId: ids.learningSpec,
      expectedSessionRevision: 3,
      expectedSpecRevision: 1,
      draft: revisedDraft,
    })
    expect(revised).toMatchObject({ success: true, data: { resourceRevision: 2 } })

    const stale = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_UPDATE_LEARNING_SPEC',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000083',
      projectId: ids.project,
      learningSpecId: ids.learningSpec,
      expectedSessionRevision: 3,
      expectedSpecRevision: 1,
      draft: revisedDraft,
    })
    expect(stale).toMatchObject({ success: false, error: { code: 'DISCOVERY_SESSION_STALE' } })

    const confirmed = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_CONFIRM_LEARNING_SPEC',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000084',
      projectId: ids.project,
      learningSpecId: ids.learningSpec,
      expectedSpecRevision: 2,
    })
    expect(confirmed).toMatchObject({ success: true, data: { resourceRevision: 3 } })
    expect(storage.repository.recoverProject(ids.project)).toMatchObject({
      learningSpec: {
        revision: 3,
        status: 'CONFIRMED',
        productPurpose: revisedDraft.productPurpose,
        source: { kind: 'USER' },
      },
      activeTask: null,
    })
  })

  it('supersedes the draft and returns through a new Discovery session', async () => {
    const newSessionId = 'discovery_session_00000000-0000-4000-8000-000000000085'
    let generatedSequence = 90
    const { service, storage } = await createHarness({
      generateId: (prefix) => {
        if (prefix === 'discovery_session') return newSessionId
        generatedSequence += 1
        return `${prefix}_00000000-0000-4000-8000-${String(generatedSequence).padStart(12, '0')}`
      },
    })
    seedSpecReview(storage, true)

    const returned = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RETURN_TO_DISCOVERY',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000086',
      projectId: ids.project,
      discoverySessionId: ids.discoverySession,
      expectedSessionRevision: 2,
      expectedSpecRevision: 1,
      input: {
        ...discoveryInputFixture,
        learningGoal: 'Learn runtime validation through a smaller local tool',
      },
    })
    expect(returned).toMatchObject({ success: true, data: { resourceRevision: 1 } })

    expect(storage.repository.readDiscoveryAggregateBySession(ids.discoverySession)).toMatchObject({
      session: { revision: 2, status: 'SELECTED' },
      learningSpecs: [
        { revision: 1, status: 'DRAFT' },
        { revision: 2, status: 'SUPERSEDED' },
      ],
    })
    expect(storage.repository.readDiscoveryAggregateBySession(newSessionId)).toMatchObject({
      project: {
        status: 'DISCOVERY',
        learningGoal: 'Learn runtime validation through a smaller local tool',
      },
      session: {
        revision: 1,
        status: 'ACTIVE',
        input: {
          ...discoveryInputFixture,
          learningGoal: 'Learn runtime validation through a smaller local tool',
        },
      },
    })
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESTORE_PROJECT_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        helperConversationLimit: 10,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: { selectedCandidate: null, learningSpec: null },
    })
  })
})

describe('T10 Builder Task and Live Context application flow', () => {
  it('prepares only a confirmed Spec, recovers pending work, and completes through current Context', async () => {
    let generatedSequence = 100
    const { service, storage, workspaceRoot } = await createHarness({
      generateId: (prefix) => {
        if (prefix === 'task') return ids.task
        generatedSequence += 1
        return `${prefix}_00000000-0000-4000-8000-${String(generatedSequence).padStart(12, '0')}`
      },
    })
    seedSpecReview(storage, true, [])

    const unconfirmed = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_PREPARE_BUILDER_TASK',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000101',
      projectId: ids.project,
      learningSpecId: ids.learningSpec,
      expectedSpecRevision: 1,
    })
    expect(unconfirmed).toMatchObject({
      success: false,
      error: { code: 'BUILDER_TASK_CONFIRMED_SPEC_REQUIRED' },
    })

    const confirmed = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_CONFIRM_LEARNING_SPEC',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000102',
      projectId: ids.project,
      learningSpecId: ids.learningSpec,
      expectedSpecRevision: 1,
    })
    expect(confirmed).toMatchObject({ success: true, data: { resourceRevision: 2 } })

    const prepareRequest = {
      schemaVersion: 1,
      kind: 'UI_PREPARE_BUILDER_TASK',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000103',
      projectId: ids.project,
      learningSpecId: ids.learningSpec,
      expectedSpecRevision: 2,
    } as const
    const prepared = await service.executeUi(prepareRequest)
    const replayed = await service.executeUi(prepareRequest)
    expect(replayed).toEqual(prepared)
    expect(prepared.success).toBe(true)
    if (!prepared.success) return
    const descriptor = preparedBuilderTaskDescriptorSchema.parse(prepared.data)
    expect(descriptor.workspacePath).toBe(`projects/${ids.project}`)
    expect(descriptor.task).toMatchObject({
      id: ids.task,
      status: 'PENDING',
      expectedConcepts: ['discriminated union'],
      excludedWork: ['Hosted sample storage'],
      expectedDecisionCategories: [],
    })
    expect(descriptor.task.requirements).toContain(
      'Agent-supported implementation scope: Local application shell',
    )
    expect(descriptor.task.acceptanceCriteria.map((criterion) => criterion.key)).toEqual([
      'feature_01',
      'feature_02',
      'local_result',
      'tests_pass',
    ])
    expect((await stat(join(workspaceRoot, descriptor.workspacePath))).isDirectory()).toBe(true)
    expect(storage.repository.recoverProject(ids.project)).toMatchObject({
      activeTask: null,
      currentTask: { id: ids.task, status: 'PENDING' },
    })

    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_LIST_PROJECTS',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        limit: 25,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        projects: [
          {
            project: { id: ids.project, status: 'SPEC_REVIEW' },
            suggestedSurface: 'BUILD',
            activeTask: null,
          },
        ],
      },
    })
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESTORE_PROJECT_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        helperConversationLimit: 10,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        project: { id: ids.project, status: 'SPEC_REVIEW' },
        suggestedSurface: 'BUILD',
        activeTask: null,
        currentTask: { id: ids.task, status: 'PENDING' },
      },
    })

    const duplicate = await service.executeUi({
      ...prepareRequest,
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000104',
    })
    expect(duplicate).toMatchObject({
      success: false,
      error: { code: 'BUILDER_TASK_ALREADY_PREPARED' },
    })

    const started = await service.executeAgent('BUILDER', {
      schemaVersion: 1,
      kind: 'BUILDER_START_TASK',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'BUILDER' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000105',
      projectId: ids.project,
      taskId: ids.task,
      expectedTaskRevision: 1,
    })
    expect(started).toMatchObject({ success: true, data: { resourceRevision: 2 } })

    const contextBase = {
      ...liveContextFixture,
      activeDecisionIds: [],
      relatedFiles: [],
      nextActions: ['Implement the validated MVP features.'],
    }
    const wrongFirst = await service.executeAgent('BUILDER', {
      schemaVersion: 1,
      kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'BUILDER' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000106',
      context: { ...contextBase, checkpoint: 'VALIDATION_STARTED' },
    })
    expect(wrongFirst).toMatchObject({
      success: false,
      error: { code: 'LIVE_CONTEXT_INITIAL_INVALID' },
    })

    const firstContext = { ...contextBase, checkpoint: 'TASK_STARTED' as const }
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000107',
        context: firstContext,
      }),
    ).toMatchObject({ success: true, data: { resourceRevision: 1 } })

    const stale = await service.executeAgent('BUILDER', {
      schemaVersion: 1,
      kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'BUILDER' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000108',
      context: { ...firstContext, stage: 'Stale overwrite' },
    })
    expect(stale).toMatchObject({
      success: false,
      error: { category: 'STALE_CONTEXT', code: 'LIVE_CONTEXT_STALE' },
    })

    const validationContext = {
      ...firstContext,
      contextVersion: 2,
      expectedPreviousVersion: 1,
      checkpoint: 'VALIDATION_STARTED' as const,
      stage: 'Running tests',
    }
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000109',
        context: validationContext,
      }),
    ).toMatchObject({ success: true, data: { resourceRevision: 2 } })
    expect(
      await service.executeAgent('HELPER', {
        schemaVersion: 1,
        kind: 'HELPER_GET_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'HELPER' },
        projectId: ids.project,
        taskId: ids.task,
        question: 'What is happening now?',
        relatedConceptNames: [],
        observedContextVersion: 1,
      }),
    ).toMatchObject({
      success: true,
      data: {
        liveContext: { contextVersion: 2, stage: 'Running tests' },
        freshness: { currentContextVersion: 2, stale: true },
      },
    })

    const report = {
      schemaVersion: 1 as const,
      id: ids.completionReport,
      projectId: ids.project,
      taskId: ids.task,
      correlationId: ids.correlation,
      expectedTaskRevision: 2,
      implementedFeatures: ['Validated and rendered event variants.'],
      acceptanceResults: descriptor.task.acceptanceCriteria.map((criterion) => ({
        criterionKey: criterion.key,
        status: 'PASSED' as const,
        evidence: [],
      })),
      validationResults: [
        {
          name: 'generated project tests',
          status: 'PASSED' as const,
          summary: 'All tests passed.',
        },
      ],
      conceptUsage: [
        {
          conceptName: 'discriminated union',
          scope: 'LEARNER_FOCUS' as const,
          importance: 'CORE' as const,
          usageReason: 'The implementation narrows variants by a discriminant.',
          codeReferences: [],
        },
      ],
      appliedDecisionIds: [],
      codeReferences: [],
      diffReferences: [],
      specDeviations: [],
      remainingIssues: [],
      limitations: [],
      completedAt: timestamp,
      source: { kind: 'AGENT' as const, role: 'BUILDER' as const },
      redactionStatus: 'VERIFIED_REDACTED' as const,
    }
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_COMPLETE_TASK',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000110',
        report,
      }),
    ).toMatchObject({ success: false, error: { code: 'TASK_COMPLETED_CONTEXT_REQUIRED' } })

    const completedContext = {
      ...validationContext,
      contextVersion: 3,
      expectedPreviousVersion: 2,
      checkpoint: 'TASK_COMPLETED' as const,
      stage: 'Completed',
      nextActions: ['Open the generated result.'],
    }
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000111',
        context: completedContext,
      }),
    ).toMatchObject({ success: true, data: { resourceRevision: 3 } })
    for (const validationResults of [
      [],
      [{ name: 'build', status: 'NOT_RUN', summary: 'Blocked by the native permission guard' }],
    ]) {
      expect(
        await service.executeAgent('BUILDER', {
          schemaVersion: 1,
          kind: 'BUILDER_COMPLETE_TASK',
          correlationId: ids.correlation,
          actor: { kind: 'AGENT', role: 'BUILDER' },
          idempotencyKey: `idem_${randomUUID()}`,
          report: { ...report, validationResults },
        }),
      ).toMatchObject({ success: false, error: { code: 'TASK_VALIDATION_NOT_RUN' } })
      expect(storage.repository.readBuilderTaskAggregate(ids.project, ids.task)).toMatchObject({
        task: { status: 'ACTIVE' },
        completionReport: null,
      })
    }
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_COMPLETE_TASK',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000112',
        report,
      }),
    ).toMatchObject({ success: true, data: { resourceRevision: 3 } })
    expect(storage.repository.recoverProject(ids.project)).toMatchObject({
      project: {
        status: 'BUILDING',
        generatedWorkspacePath: `projects/${ids.project}`,
      },
      activeTask: null,
      currentTask: null,
      liveContext: null,
    })
    expect(storage.repository.readLatestTaskForProject(ids.project)).toMatchObject({
      id: ids.task,
      status: 'COMPLETED',
    })
    expect(storage.repository.readBuilderTaskAggregate(ids.project, ids.task)).toMatchObject({
      completionReport: { id: ids.completionReport },
    })
    const launch = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_LAUNCH_RESULT',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000113',
      projectId: ids.project,
    })
    expect(launch, JSON.stringify(launch)).toMatchObject({
      success: true,
      data: {
        projectId: ids.project,
        workspacePath: `projects/${ids.project}`,
        status: 'READY',
      },
    })
  })
})

describe('T18 evidence-aware Final Upgrade application flow', () => {
  it('requires completed analysis and opens sequence two as a FINAL_UPGRADE Episode', async () => {
    const finalTaskId = 'task_00000000-0000-4000-8000-000000000401'
    let generatedSequence = 401
    const { service, storage, workspaceRoot } = await createHarness({
      generateId: (prefix) => {
        if (prefix === 'task') return finalTaskId
        generatedSequence += 1
        return `${prefix}_00000000-0000-4000-8000-${String(generatedSequence).padStart(12, '0')}`
      },
    })
    seedBuilderGraph(storage)
    await mkdir(join(workspaceRoot, ...projectFixture.generatedWorkspacePath.split('/')), {
      recursive: true,
    })
    const completedTask = builderTaskSchema.parse({
      ...builderTaskFixture,
      revision: 2,
      status: 'COMPLETED',
    })
    const analyzedEpisode = episodeSchema.parse({
      ...episodeFixture,
      decisionId: undefined,
      conversationId: undefined,
      type: 'BUILD_TASK',
      status: 'ANALYZED',
      closeReason: 'Initial Builder Task completed and analysis succeeded.',
    })
    const succeededAnalysis = analysisJobSchema.parse({
      ...analysisJobFixture,
      revision: 3,
      status: 'SUCCEEDED',
      runtimeHandle: undefined,
      deadlineAt: undefined,
      completedAt: timestamp,
      resultSummary: {
        proposalCount: 0,
        acceptedCount: 0,
        rejectedCount: 0,
        noEvidenceReason: 'Builder observation was recorded separately.',
      },
    })
    const evidenceAwareTrace = personalizationTraceSchema.parse({
      ...helperPersonalizationFixture,
      mode: 'EVIDENCE_AWARE',
      basis: [
        {
          conceptId: ids.concept,
          conceptName: 'runtime validation',
          ledgerRevision: 1,
          state: 'DEMONSTRATED',
          evidenceIds: [ids.evidence],
          episodeIds: [ids.episode],
          sourceProjectIds: [ids.project],
          sourceProjectTitles: ['Webhook Lens'],
          openIssueIds: [],
          purpose: 'HELPER_EXPLANATION_START',
        },
      ],
      fallbackReason: undefined,
    })
    storage.transaction((repository) => {
      repository.appendTask(completedTask)
      repository.appendCompletionReport(completionReportFixture)
      repository.appendActivityEvent(activityEventSchema.parse(activityEventFixture))
      repository.appendEpisode(analyzedEpisode)
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobPendingFixture))
      repository.appendAnalysisJob(analysisJobSchema.parse(analysisJobFixture))
      repository.appendAnalysisJob(succeededAnalysis)
      repository.appendPersonalizationTrace(evidenceAwareTrace)
    })
    const prepareRequest = {
      schemaVersion: 1,
      kind: 'UI_PREPARE_FINAL_UPGRADE_TASK',
      correlationId: 'corr_00000000-0000-4000-8000-000000000402',
      actor: { kind: 'UI' },
      projectId: ids.project,
      sourceTaskId: ids.task,
      expectedSourceTaskRevision: 2,
      personalizationTraceId: ids.personalization,
      userGoal: 'Show expired and consumed links as different states.',
    } as const

    // Helper read its context (trace exists) but its answer was never recorded, e.g. cancelled.
    const unrecorded = await service.executeUi({
      ...prepareRequest,
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000409',
    })
    expect(unrecorded).toMatchObject({
      success: false,
      error: { code: 'FINAL_UPGRADE_HELPER_TURN_NOT_RECORDED' },
    })
    expect(storage.repository.readLatestTaskForProject(ids.project)?.id).toBe(ids.task)

    storage.transaction((repository) =>
      repository.appendActivityEvent(
        activityEventSchema.parse({
          ...activityEventFixture,
          id: 'event_00000000-0000-4000-8000-000000000410',
          sequence: repository.nextActivitySequence(ids.project),
          correlationId: evidenceAwareTrace.correlationId,
          actor: { kind: 'AGENT', role: 'HELPER' },
          payload: {
            type: 'HELPER_RESPONSE',
            conversationId: ids.conversation,
            messageId: ids.helperMessage,
            summary: 'Separate expired and consumed states before rendering.',
          },
          sourceReferences: [
            {
              kind: 'AGENT_MESSAGE',
              conversationId: ids.conversation,
              messageId: ids.helperMessage,
            },
          ],
        }),
      ),
    )

    const prepared = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_PREPARE_FINAL_UPGRADE_TASK',
      correlationId: 'corr_00000000-0000-4000-8000-000000000402',
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000403',
      projectId: ids.project,
      sourceTaskId: ids.task,
      expectedSourceTaskRevision: 2,
      personalizationTraceId: ids.personalization,
      userGoal: 'Show expired and consumed links as different states.',
    })
    expect(prepared).toMatchObject({
      success: true,
      data: {
        task: {
          id: finalTaskId,
          sequence: 2,
          prerequisiteTaskIds: [ids.task],
          finalUpgrade: {
            sourceTaskId: ids.task,
            personalizationTraceId: ids.personalization,
            userGoal: 'Show expired and consumed links as different states.',
          },
        },
      },
    })

    await expect(
      service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_START_TASK',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000404',
        projectId: ids.project,
        taskId: finalTaskId,
        expectedTaskRevision: 1,
      }),
    ).resolves.toMatchObject({ success: true, data: { resourceRevision: 2 } })
    expect(
      storage.repository.readOpenEpisode(ids.project, 'FINAL_UPGRADE', {
        taskId: finalTaskId,
      }),
    ).toMatchObject({ type: 'FINAL_UPGRADE', taskId: finalTaskId, status: 'OPEN' })
    expect(
      storage.repository.readOpenEpisode(ids.project, 'BUILD_TASK', { taskId: finalTaskId }),
    ).toBe(null)
  })
})

describe('T11 Decision gate and Builder resume application flow', () => {
  const initialContext = {
    ...liveContextFixture,
    checkpoint: 'TASK_STARTED' as const,
    stage: 'Starting implementation',
    currentGoal: 'Implement the validated event parser.',
    recentChanges: [],
    activeDecisionIds: [],
    nextActions: ['Choose the unknown-field behavior when the parser reaches that boundary.'],
  }

  it('atomically blocks, hands off, resolves, resumes, applies, and completes a real Decision', async () => {
    let optionSequence = 0
    let generatedSequence = 200
    const { service, storage } = await createHarness({
      generateId: (prefix) => {
        if (prefix === 'decision') return ids.decision
        if (prefix === 'decision_option') {
          optionSequence += 1
          return optionSequence === 1 ? ids.optionA : ids.optionB
        }
        if (prefix === 'decision_application') return ids.decisionApplication
        generatedSequence += 1
        return `${prefix}_00000000-0000-4000-8000-${String(generatedSequence).padStart(12, '0')}`
      },
    })
    seedBuilderGraph(storage, true)
    expect(storage.repository.readBuilderTaskAggregate(ids.project, ids.task)).toMatchObject({
      learningSpec: { expectedDecisions: [] },
      task: { expectedDecisionCategories: [] },
    })
    storage.repository.appendLiveContext(initialContext)

    const requestDecision = {
      schemaVersion: 1,
      kind: 'BUILDER_REQUEST_DECISION',
      correlationId: ids.correlation,
      actor: { kind: 'AGENT', role: 'BUILDER' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000201',
      projectId: ids.project,
      taskId: ids.task,
      expectedTaskRevision: 1,
      expectedContextVersion: 1,
      decision: {
        category: 'DATA_MODEL',
        question: 'Should unknown fields be rejected or retained for inspection?',
        reasonRequiredNow: 'The parser result and UI behavior depend on this choice.',
        options: [
          {
            key: 'reject',
            label: 'Reject unknown fields',
            description: 'Keep the parser strict.',
            impacts: ['Typos fail at the input boundary.'],
            tradeoffs: ['Provider additions require a schema update.'],
          },
          {
            key: 'retain',
            label: 'Retain unknown fields',
            description: 'Expose unmodeled fields for inspection.',
            impacts: ['New provider fields remain visible.'],
            tradeoffs: ['Typos can be less obvious.'],
          },
        ],
        recommendedOptionKey: 'reject',
        recommendationRationale: 'Strict parsing catches invalid payloads at the boundary.',
        relatedConceptNames: ['runtime validation'],
        sourceReferences: [liveContextFixture.relatedFiles[0]],
        independentWorkCanContinue: false,
      },
      context: {
        stage: 'Waiting on parser behavior',
        currentGoal: 'Choose unknown-field behavior before implementing the parser branch.',
        recentChanges: ['Defined the known event variants.'],
        activeConceptNames: ['runtime validation'],
        relatedFiles: [liveContextFixture.relatedFiles[0]],
        nextActions: ['Apply the selected parser behavior.', 'Run parser tests.'],
        blockingReason: 'The parser branch depends on the user choice.',
      },
    } as const

    const requested = await service.executeAgent('BUILDER', requestDecision)
    const replayed = await service.executeAgent('BUILDER', requestDecision)
    expect(requested).toEqual(replayed)
    expect(requested).toMatchObject({
      success: true,
      data: { decisionId: ids.decision, resourceRevision: 2 },
    })
    expect(storage.repository.readBuilderTaskAggregate(ids.project, ids.task)).toMatchObject({
      task: { status: 'BLOCKED', revision: 2 },
      liveContext: {
        checkpoint: 'DECISION_REQUIRED',
        contextVersion: 2,
        activeDecisionIds: [ids.decision],
      },
      decisionRequests: [
        {
          id: ids.decision,
          recommendedOptionId: ids.optionA,
          source: { kind: 'AGENT', role: 'BUILDER' },
        },
      ],
    })
    for (const activeDecisionIds of [[], [ids.decision, ids.decision]]) {
      expect(
        await service.executeAgent('BUILDER', {
          schemaVersion: 1,
          kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
          correlationId: ids.correlation,
          actor: { kind: 'AGENT', role: 'BUILDER' },
          idempotencyKey: `idem_00000000-0000-4000-8000-000000000${
            activeDecisionIds.length === 0 ? '211' : '212'
          }`,
          context: {
            ...initialContext,
            contextVersion: 3,
            expectedPreviousVersion: 2,
            checkpoint: 'VALIDATION_STARTED',
            activeDecisionIds,
          },
        }),
      ).toMatchObject({
        success: false,
        error: { code: 'LIVE_CONTEXT_ACTIVE_DECISIONS_MISMATCH' },
      })
    }
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESTORE_PROJECT_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        helperConversationLimit: 10,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        decisions: [{ request: { id: ids.decision }, resolution: null, application: null }],
        completionReport: null,
      },
    })

    expect(
      await service.executeUi({
        schemaVersion: 1,
        kind: 'UI_OPEN_HELPER',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        taskId: ids.task,
        question: 'Compare the parser options.',
      }),
    ).toMatchObject({
      success: true,
      data: { activeDecisions: [{ id: ids.decision }] },
    })

    const resolution = {
      ...decisionResolutionFixture,
      expectedContextVersion: 2,
    }
    expect(
      await service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESOLVE_DECISION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000202',
        resolution,
      }),
    ).toMatchObject({ success: true, data: { resourceRevision: 3 } })
    const decisionEpisodeBefore = storage.repository
      .readRecentEpisodeAggregatesForProject(ids.project, 50)
      .find((aggregate) => aggregate.episode.decisionId === ids.decision)
    expect(decisionEpisodeBefore).toBeDefined()
    const jobBefore = storage.repository.readAnalysisJobForEpisode(
      ids.project,
      decisionEpisodeBefore?.episode.id ?? ids.episode,
    )
    expect(
      await service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESOLVE_DECISION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000299',
        resolution,
      }),
    ).toMatchObject({ success: true, data: { resourceRevision: 3 } })
    const decisionEpisodeAfter = storage.repository
      .readRecentEpisodeAggregatesForProject(ids.project, 50)
      .find((aggregate) => aggregate.episode.decisionId === ids.decision)
    expect(decisionEpisodeAfter).toEqual(decisionEpisodeBefore)
    expect(
      storage.repository.readAnalysisJobForEpisode(
        ids.project,
        decisionEpisodeBefore?.episode.id ?? ids.episode,
      ),
    ).toEqual(jobBefore)
    expect(storage.repository.recoverProject(ids.project)).toMatchObject({
      activeTask: { status: 'ACTIVE', revision: 3 },
      pendingDecisions: [],
    })
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESTORE_PROJECT_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        helperConversationLimit: 10,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        decisions: [
          {
            request: { id: ids.decision },
            resolution: { id: ids.resolution },
            application: null,
          },
        ],
      },
    })
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_GET_DECISION_RESULT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        projectId: ids.project,
        taskId: ids.task,
        decisionId: ids.decision,
      }),
    ).toMatchObject({
      success: true,
      data: { resolution: { id: ids.resolution, helperUsed: true }, application: null },
    })

    const report = {
      schemaVersion: 1 as const,
      id: ids.completionReport,
      projectId: ids.project,
      taskId: ids.task,
      correlationId: ids.correlation,
      expectedTaskRevision: 3,
      implementedFeatures: ['Validated webhook variants with the selected strict behavior.'],
      acceptanceResults: [{ criterionKey: 'valid_event', status: 'PASSED' as const, evidence: [] }],
      validationResults: [
        { name: 'parser tests', status: 'PASSED' as const, summary: 'All tests passed.' },
      ],
      conceptUsage: [
        {
          conceptName: 'discriminated union',
          scope: 'LEARNER_FOCUS' as const,
          importance: 'CORE' as const,
          usageReason: 'The parser narrows each validated event variant.',
          codeReferences: [],
        },
      ],
      appliedDecisionIds: [ids.decision],
      codeReferences: [],
      diffReferences: [],
      specDeviations: [],
      remainingIssues: [],
      limitations: [],
      completedAt: timestamp,
      source: { kind: 'AGENT' as const, role: 'BUILDER' as const },
      redactionStatus: 'VERIFIED_REDACTED' as const,
    }
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_COMPLETE_TASK',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000203',
        report,
      }),
    ).toMatchObject({ success: false, error: { code: 'TASK_DECISION_NOT_APPLIED' } })

    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_APPLY_DECISION',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000204',
        projectId: ids.project,
        taskId: ids.task,
        decisionId: ids.decision,
        expectedTaskRevision: 3,
        expectedContextVersion: 2,
        appliedResult: 'Rejected unknown fields at the parser boundary and added a failing case.',
        sourceReferences: [liveContextFixture.relatedFiles[0]],
        context: {
          stage: 'Applied strict parser behavior',
          currentGoal: 'Validate the selected behavior.',
          recentChanges: ['Implemented strict unknown-field rejection.'],
          activeConceptNames: ['runtime validation'],
          relatedFiles: [liveContextFixture.relatedFiles[0]],
          nextActions: ['Run parser tests.'],
        },
      }),
    ).toMatchObject({
      success: true,
      data: { decisionId: ids.decision, resourceRevision: 3 },
    })
    expect(storage.repository.readBuilderTaskAggregate(ids.project, ids.task)).toMatchObject({
      decisionApplications: [{ id: ids.decisionApplication, decisionId: ids.decision }],
      liveContext: { contextVersion: 3, activeDecisionIds: [] },
    })
    for (const activeDecisionIds of [
      [ids.decision],
      ['decision_00000000-0000-4000-8000-000000000999'],
    ]) {
      expect(
        await service.executeAgent('BUILDER', {
          schemaVersion: 1,
          kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
          correlationId: ids.correlation,
          actor: { kind: 'AGENT', role: 'BUILDER' },
          idempotencyKey: `idem_00000000-0000-4000-8000-000000000${
            activeDecisionIds[0] === ids.decision ? '213' : '214'
          }`,
          context: {
            ...initialContext,
            contextVersion: 4,
            expectedPreviousVersion: 3,
            checkpoint: 'VALIDATION_STARTED',
            activeDecisionIds,
          },
        }),
      ).toMatchObject({
        success: false,
        error: { code: 'LIVE_CONTEXT_ACTIVE_DECISIONS_MISMATCH' },
      })
    }
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000215',
        context: {
          ...initialContext,
          contextVersion: 3,
          expectedPreviousVersion: 2,
          checkpoint: 'VALIDATION_STARTED',
          activeDecisionIds: [],
        },
      }),
    ).toMatchObject({ success: false, error: { code: 'LIVE_CONTEXT_STALE' } })
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESTORE_PROJECT_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        helperConversationLimit: 10,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        decisions: [
          {
            request: { id: ids.decision },
            resolution: { id: ids.resolution },
            application: { id: ids.decisionApplication },
          },
        ],
      },
    })

    const completedContext = {
      ...initialContext,
      contextVersion: 4,
      expectedPreviousVersion: 3,
      checkpoint: 'TASK_COMPLETED' as const,
      stage: 'Completed',
      activeDecisionIds: [],
      recentChanges: ['Implemented and validated strict unknown-field rejection.'],
      nextActions: ['Open the generated result.'],
    }
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000205',
        context: completedContext,
      }),
    ).toMatchObject({ success: true })
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_COMPLETE_TASK',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000207',
        report: { ...report, appliedDecisionIds: [ids.decision, ids.decision] },
      }),
    ).toMatchObject({ success: false, error: { code: 'TASK_DECISION_NOT_APPLIED' } })
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_COMPLETE_TASK',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000206',
        report,
      }),
    ).toMatchObject({ success: true, data: { resourceRevision: 4 } })
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESTORE_PROJECT_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        helperConversationLimit: 10,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        currentTask: { id: ids.task, status: 'COMPLETED' },
        completionReport: { id: ids.completionReport },
      },
    })
    const observationTrace = storage.repository
      .readEvidenceTracesForProject(ids.project)
      .find((trace) => trace.concept.canonicalName === 'discriminated union')
    expect(observationTrace).toMatchObject({
      ledger: { state: { state: 'OBSERVED' } },
      proposals: [],
      acceptedEvidence: [
        {
          kind: 'CONCEPT_OBSERVATION',
          projectId: ids.project,
          taskId: ids.task,
          supportsState: 'OBSERVED',
          source: { kind: 'CORE' },
        },
      ],
    })
    const followupTaskId = 'task_00000000-0000-4000-8000-000000000721'
    storage.repository.appendTask(
      builderTaskSchema.parse({
        ...builderTaskFixture,
        id: followupTaskId,
        sequence: 2,
        prerequisiteTaskIds: [ids.task],
      }),
    )
    const helperAfterObservation = await service.executeAgent('HELPER', {
      schemaVersion: 1,
      kind: 'HELPER_GET_CONTEXT',
      correlationId: 'corr_00000000-0000-4000-8000-000000000722',
      actor: { kind: 'AGENT', role: 'HELPER' },
      projectId: ids.project,
      taskId: followupTaskId,
      question: '새 작업에서는 어떤 선택을 살펴봐야 하나요?',
      relatedConceptNames: [],
    })
    expect(helperAfterObservation).toMatchObject({
      success: true,
      data: {
        personalization: { mode: 'NO_RELEVANT_EVIDENCE', basis: [] },
      },
    })
  })

  it('keeps the Task active when independent work can continue', async () => {
    let optionSequence = 0
    let generatedSequence = 220
    const { service, storage } = await createHarness({
      generateId: (prefix) => {
        if (prefix === 'decision') return ids.decision
        if (prefix === 'decision_option') {
          optionSequence += 1
          return optionSequence === 1 ? ids.optionA : ids.optionB
        }
        generatedSequence += 1
        return `${prefix}_00000000-0000-4000-8000-${String(generatedSequence).padStart(12, '0')}`
      },
    })
    seedBuilderGraph(storage)
    storage.repository.appendLiveContext(initialContext)

    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_REQUEST_DECISION',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000221',
        projectId: ids.project,
        taskId: ids.task,
        expectedTaskRevision: 1,
        expectedContextVersion: 1,
        decision: {
          category: 'PRODUCT_BEHAVIOR',
          question: 'Should invalid examples remain visible after a successful parse?',
          reasonRequiredNow: 'The result presentation depends on this behavior.',
          options: [
            {
              key: 'hide',
              label: 'Hide invalid examples',
              description: 'Show only the latest valid result.',
              impacts: ['The result stays concise.'],
              tradeoffs: ['Debugging history is unavailable.'],
            },
            {
              key: 'retain',
              label: 'Retain invalid examples',
              description: 'Keep a local debugging history.',
              impacts: ['Users can compare failures.'],
              tradeoffs: ['The result view is denser.'],
            },
          ],
          recommendedOptionKey: 'retain',
          recommendationRationale: 'Visible failures support the local debugging goal.',
          relatedConceptNames: ['result state'],
          sourceReferences: [],
          independentWorkCanContinue: true,
        },
        context: {
          stage: 'Continuing independent parser work',
          currentGoal: 'Finish parser validation while result behavior is pending.',
          recentChanges: ['Identified a presentation Decision.'],
          activeConceptNames: ['result state'],
          relatedFiles: [],
          nextActions: ['Finish parser tests independently.'],
        },
      }),
    ).toMatchObject({ success: true, data: { resourceRevision: 1 } })
    expect(storage.repository.recoverProject(ids.project)).toMatchObject({
      activeTask: { status: 'ACTIVE', revision: 1 },
      pendingDecisions: [{ id: ids.decision, independentWorkCanContinue: true }],
    })
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        kind: 'BUILDER_UPDATE_LIVE_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000222',
        context: {
          ...initialContext,
          contextVersion: 3,
          expectedPreviousVersion: 2,
          checkpoint: 'CONCEPT_INTRODUCED',
          stage: 'Testing independent parser work',
          activeDecisionIds: [ids.decision],
          nextActions: ['Run parser tests while result behavior remains pending.'],
        },
      }),
    ).toMatchObject({ success: true, data: { resourceRevision: 3 } })
  })

  it.each([
    ['short', 'The user asked a question but did not explain or apply the concept.'],
    ['long', 'No independent explanation was given. '.repeat(12).trim()],
    ['maximum', 'x'.repeat(4000)],
    ['surrogate boundary', 'a'.repeat(238) + '🚦' + ' No user explanation.'.repeat(15)],
  ])(
    'normalizes a Helper exchange and safely displays empty analysis: %s',
    async (_label, reason) => {
      const { service, storage } = await createHarness()
      seedBuilderGraph(storage)

      const recorded = await service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RECORD_HELPER_EXCHANGE',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000301',
        projectId: ids.project,
        taskId: ids.task,
        userMessage: 'Why is runtime validation needed here?',
        helperResponseSummary: 'It checks unknown input before typed code uses it.',
        closeConversation: true,
      })
      expect(recorded).toMatchObject({
        success: true,
        data: { episodeRevision: 3, status: 'PENDING_ANALYSIS' },
      })
      if (!recorded.success || !('episodeId' in recorded.data)) throw new Error('missing episode')

      const pendingResult = await service.executeAnalysis({
        schemaVersion: 1,
        kind: 'ANALYSIS_LIST_PENDING',
        correlationId: ids.correlation,
        actor: { kind: 'KIRO_ADAPTER' },
        limit: 10,
      })
      if (!pendingResult.success) throw new Error('pending job query failed')
      const pending = analysisJobSchema.array().parse(pendingResult.data)
      expect(pending).toHaveLength(1)
      const pendingJob = pending[0]
      if (pendingJob === undefined) throw new Error('pending job missing')
      expect(pendingJob).toMatchObject({
        episodeId: recorded.data.episodeId,
        episodeRevision: 3,
        status: 'PENDING',
        attempt: 0,
      })

      const claimedResult = await service.executeAnalysis({
        schemaVersion: 1,
        kind: 'ANALYSIS_CLAIM_JOB',
        correlationId: ids.correlation,
        actor: { kind: 'KIRO_ADAPTER' },
        projectId: ids.project,
        analysisJobId: pendingJob.id,
        expectedJobRevision: pendingJob.revision,
        runtimeHandle: 'kiro-session-helper-empty',
      })
      if (!claimedResult.success) throw new Error('job claim failed')
      const claimed = analysisJobSchema.parse(claimedResult.data)
      expect(claimed).toMatchObject({ status: 'RUNNING', attempt: 1, revision: 2 })

      const context = await service.executeAgent('EVIDENCE_ANALYST', {
        schemaVersion: 1,
        kind: 'ANALYST_GET_EPISODE_CONTEXT',
        correlationId: ids.correlation,
        actor: { kind: 'AGENT', role: 'EVIDENCE_ANALYST' },
        projectId: ids.project,
        episodeId: claimed.episodeId,
        expectedEpisodeRevision: claimed.episodeRevision,
      })
      expect(context).toMatchObject({
        success: true,
        data: {
          episode: { type: 'HELPER_CONVERSATION', status: 'PENDING_ANALYSIS' },
          events: [
            { actor: { kind: 'USER' }, payload: { type: 'USER_MESSAGE' } },
            { actor: { kind: 'AGENT', role: 'HELPER' }, payload: { type: 'HELPER_RESPONSE' } },
          ],
          analysisJob: { id: claimed.id, status: 'RUNNING', attempt: 1 },
        },
      })

      const emptyResult = {
        schemaVersion: 1,
        episodeId: claimed.episodeId,
        episodeRevision: claimed.episodeRevision,
        correlationId: claimed.correlationId,
        proposals: [],
        noEvidenceReason: reason,
      } as const
      const submitted = await service.executeAnalysis({
        schemaVersion: 1,
        kind: 'ANALYSIS_SUBMIT_RESULT',
        correlationId: ids.correlation,
        actor: { kind: 'KIRO_ADAPTER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000302',
        projectId: ids.project,
        analysisJobId: claimed.id,
        expectedJobRevision: claimed.revision,
        attempt: claimed.attempt,
        result: emptyResult,
      })
      expect(submitted).toMatchObject({ success: true, data: { outcomes: [] } })
      expect(storage.repository.readAnalysisJob(ids.project, claimed.id)).toMatchObject({
        status: 'SUCCEEDED',
        revision: 3,
        resultSummary: {
          proposalCount: 0,
          acceptedCount: 0,
          rejectedCount: 0,
          noEvidenceReason: emptyResult.noEvidenceReason,
        },
      })
      expect(
        storage.repository.readEpisodeAggregate(ids.project, claimed.episodeId)?.episode,
      ).toMatchObject({ status: 'ANALYZED', revision: 4 })

      const viewResult = await service.executeUi({
        schemaVersion: 1,
        kind: 'UI_READ_EVIDENCE_TRACE',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
      })
      expect(viewResult.success).toBe(true)
      if (!viewResult.success) throw new Error('evidence trace failed')
      const view = projectEvidenceTraceSchema.parse(viewResult.data)
      expect(view.concepts).toEqual([])
      expect(view.emptyReason?.length).toBeLessThanOrEqual(240)
      expect(Buffer.from(view.emptyReason ?? '').toString('utf8')).toBe(view.emptyReason)
      expect(view.emptyReason).toBe(
        reason.length <= 240
          ? reason
          : reason.startsWith('a'.repeat(238))
            ? 'a'.repeat(238) + '…'
            : reason.slice(0, 239) + '…',
      )
      expect(view.analysis[0]?.resultSummary?.noEvidenceReason).toBe(reason)

      const late = await service.executeAnalysis({
        schemaVersion: 1,
        kind: 'ANALYSIS_SUBMIT_RESULT',
        correlationId: ids.correlation,
        actor: { kind: 'KIRO_ADAPTER' },
        idempotencyKey: 'idem_00000000-0000-4000-8000-000000000303',
        projectId: ids.project,
        analysisJobId: claimed.id,
        expectedJobRevision: claimed.revision,
        attempt: claimed.attempt,
        result: emptyResult,
      })
      expect(late).toMatchObject({ success: false, error: { code: 'ANALYSIS_JOB_STALE' } })
    },
  )

  it('keeps one Helper conversation Episode across request correlation boundaries', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)

    const first = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RECORD_HELPER_EXCHANGE',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000305',
      projectId: ids.project,
      taskId: ids.task,
      conversationId: ids.conversation,
      userMessage: 'How does the first state transition work?',
      helperResponseSummary: 'The first transition moves the task into progress.',
      origin: 'FREE_TEXT',
      closeConversation: false,
    })
    expect(first).toMatchObject({ success: true, data: { episodeRevision: 2, status: 'OPEN' } })

    const secondCorrelationId = 'corr_00000000-0000-4000-8000-000000000032'
    const second = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RECORD_HELPER_EXCHANGE',
      correlationId: secondCorrelationId,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000306',
      projectId: ids.project,
      taskId: ids.task,
      conversationId: ids.conversation,
      userMessage: 'How does the next state transition differ?',
      helperResponseSummary: 'The next transition preserves the completed validation result.',
      origin: 'FREE_TEXT',
      closeConversation: false,
    })
    if (!second.success) throw new Error(JSON.stringify(second.error))
    expect(second).toMatchObject({
      success: true,
      data: { correlationId: secondCorrelationId, episodeRevision: 4, status: 'OPEN' },
    })
    if (!('episodeId' in second.data)) throw new Error('missing episode')

    const aggregate = storage.repository.readEpisodeAggregate(ids.project, second.data.episodeId)
    expect(aggregate).toMatchObject({
      episode: { correlationId: ids.correlation, revision: 4 },
      events: [
        { correlationId: ids.correlation, payload: { type: 'USER_MESSAGE' } },
        { correlationId: ids.correlation, payload: { type: 'HELPER_RESPONSE' } },
        { correlationId: ids.correlation, payload: { type: 'USER_MESSAGE' } },
        { correlationId: ids.correlation, payload: { type: 'HELPER_RESPONSE' } },
      ],
    })
  })

  it('keeps a Helper quick action out of user-authored evidence', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)

    const recorded = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RECORD_HELPER_EXCHANGE',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000304',
      projectId: ids.project,
      taskId: ids.task,
      conversationId: ids.conversation,
      userMessage: '추천 이유 설명해줘',
      helperResponseSummary: 'Strict parsing exposes invalid input at the boundary.',
      origin: 'QUICK_ACTION',
      closeConversation: true,
    })
    expect(recorded).toMatchObject({
      success: true,
      data: { episodeRevision: 2, status: 'PENDING_ANALYSIS' },
    })
    if (!recorded.success || !('episodeId' in recorded.data)) throw new Error('missing episode')

    expect(
      storage.repository.readEpisodeAggregate(ids.project, recorded.data.episodeId),
    ).toMatchObject({
      events: [
        {
          actor: { kind: 'AGENT', role: 'HELPER' },
          payload: { type: 'HELPER_RESPONSE' },
        },
      ],
    })
    await expect(
      service.executeUi({
        schemaVersion: 1,
        kind: 'UI_RESTORE_PROJECT_SESSION',
        correlationId: ids.correlation,
        actor: { kind: 'UI' },
        projectId: ids.project,
        helperConversationLimit: 10,
      }),
    ).resolves.toMatchObject({
      success: true,
      data: {
        helperConversations: [
          {
            conversationId: ids.conversation,
            redactedUserExcerpts: [],
            helperResponseSummaries: ['Strict parsing exposes invalid input at the boundary.'],
          },
        ],
      },
    })
  })

  it('retries one failed Analyst attempt, dead-letters the second and supports manual retry', async () => {
    const { service, storage } = await createHarness()
    seedBuilderGraph(storage)

    const recorded = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RECORD_HELPER_EXCHANGE',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000311',
      projectId: ids.project,
      taskId: ids.task,
      userMessage: 'Can you explain this validation branch?',
      helperResponseSummary: 'The branch rejects malformed external input.',
      closeConversation: true,
    })
    if (!recorded.success || !('episodeId' in recorded.data)) throw new Error('missing episode')
    const initial = storage.repository.readAnalysisJobForEpisode(
      ids.project,
      recorded.data.episodeId,
    )
    if (initial === null) throw new Error('missing analysis job')

    const claim = async (job: typeof initial, handle: string) => {
      const result = await service.executeAnalysis({
        schemaVersion: 1,
        kind: 'ANALYSIS_CLAIM_JOB',
        correlationId: ids.correlation,
        actor: { kind: 'KIRO_ADAPTER' },
        projectId: ids.project,
        analysisJobId: job.id,
        expectedJobRevision: job.revision,
        runtimeHandle: handle,
      })
      if (!result.success) throw new Error('job claim failed')
      return analysisJobSchema.parse(result.data)
    }
    const fail = async (job: typeof initial) => {
      const result = await service.executeAnalysis({
        schemaVersion: 1,
        kind: 'ANALYSIS_FAIL_ATTEMPT',
        correlationId: ids.correlation,
        actor: { kind: 'KIRO_ADAPTER' },
        projectId: ids.project,
        analysisJobId: job.id,
        expectedJobRevision: job.revision,
        attempt: job.attempt,
        failure: {
          code: 'ANALYST_TIMEOUT',
          message: 'The 30 second deadline elapsed.',
          retryable: true,
        },
      })
      if (!result.success) throw new Error('job failure transition failed')
      return analysisJobSchema.parse(result.data)
    }

    const firstRunning = await claim(initial, 'kiro-session-first')
    const firstFailed = await fail(firstRunning)
    expect(firstFailed).toMatchObject({ status: 'PENDING', attempt: 1, revision: 3 })
    const secondRunning = await claim(firstFailed, 'kiro-session-second')
    const deadLetter = await fail(secondRunning)
    expect(deadLetter).toMatchObject({
      status: 'FAILED',
      attempt: 2,
      revision: 5,
      lastFailure: { code: 'ANALYST_TIMEOUT', retryable: true },
    })
    expect(
      storage.repository.readEpisodeAggregate(ids.project, initial.episodeId)?.episode,
    ).toMatchObject({ status: 'ANALYSIS_FAILED', revision: 4 })

    const visibleFailure = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_READ_ANALYSIS_JOBS',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      projectId: ids.project,
      status: 'FAILED',
      limit: 10,
    })
    expect(visibleFailure).toMatchObject({
      success: true,
      data: [
        {
          id: deadLetter.id,
          status: 'FAILED',
          attempt: 2,
          lastFailure: { code: 'ANALYST_TIMEOUT', retryable: true },
        },
      ],
    })

    const retried = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RETRY_ANALYSIS',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000312',
      projectId: ids.project,
      analysisJobId: deadLetter.id,
      expectedJobRevision: deadLetter.revision,
    })
    expect(retried).toMatchObject({
      success: true,
      data: { status: 'PENDING', attempt: 0, revision: 6, episodeRevision: 5 },
    })
    expect(
      storage.repository.readEpisodeAggregate(ids.project, initial.episodeId)?.episode,
    ).toMatchObject({ status: 'PENDING_ANALYSIS', revision: 5 })
  })

  it('recovers expired running attempts after an Analyst runtime restart', async () => {
    let currentTime = new Date(timestamp)
    const { service, storage } = await createHarness({ now: () => currentTime })
    seedBuilderGraph(storage)

    const recorded = await service.executeUi({
      schemaVersion: 1,
      kind: 'UI_RECORD_HELPER_EXCHANGE',
      correlationId: ids.correlation,
      actor: { kind: 'UI' },
      idempotencyKey: 'idem_00000000-0000-4000-8000-000000000321',
      projectId: ids.project,
      taskId: ids.task,
      userMessage: 'Why validate this external payload?',
      helperResponseSummary: 'Validation protects the runtime input boundary.',
      closeConversation: true,
    })
    if (!recorded.success || !('episodeId' in recorded.data)) throw new Error('missing episode')
    const initial = storage.repository.readAnalysisJobForEpisode(
      ids.project,
      recorded.data.episodeId,
    )
    if (initial === null) throw new Error('missing analysis job')

    const claim = async (job: typeof initial, runtimeHandle: string) => {
      const response = await service.executeAnalysis({
        schemaVersion: 1,
        kind: 'ANALYSIS_CLAIM_JOB',
        correlationId: ids.correlation,
        actor: { kind: 'KIRO_ADAPTER' },
        projectId: ids.project,
        analysisJobId: job.id,
        expectedJobRevision: job.revision,
        runtimeHandle,
      })
      if (!response.success) throw new Error('claim failed')
      return analysisJobSchema.parse(response.data)
    }
    const firstRunning = await claim(initial, 'abandoned-runtime-1')
    expect(firstRunning.deadlineAt).toBe('2026-08-25T03:00:30.000Z')

    currentTime = new Date('2026-08-25T03:00:31.000Z')
    const firstRecovery = await service.executeAnalysis({
      schemaVersion: 1,
      kind: 'ANALYSIS_RECOVER_EXPIRED',
      correlationId: ids.correlation,
      actor: { kind: 'KIRO_ADAPTER' },
      limit: 10,
    })
    if (!firstRecovery.success) throw new Error('first recovery failed')
    const retryPending = analysisJobSchema.array().parse(firstRecovery.data)
    expect(retryPending).toMatchObject([
      { id: initial.id, status: 'PENDING', attempt: 1, revision: 3 },
    ])

    const recoveredJob = retryPending[0]
    if (recoveredJob === undefined) throw new Error('recovered job missing')
    const secondRunning = await claim(recoveredJob, 'abandoned-runtime-2')
    expect(secondRunning.deadlineAt).toBe('2026-08-25T03:01:01.000Z')
    currentTime = new Date('2026-08-25T03:01:02.000Z')
    const secondRecovery = await service.executeAnalysis({
      schemaVersion: 1,
      kind: 'ANALYSIS_RECOVER_EXPIRED',
      correlationId: ids.correlation,
      actor: { kind: 'KIRO_ADAPTER' },
      limit: 10,
    })
    if (!secondRecovery.success) throw new Error('second recovery failed')
    expect(analysisJobSchema.array().parse(secondRecovery.data)).toMatchObject([
      { id: initial.id, status: 'FAILED', attempt: 2, revision: 5 },
    ])
    expect(
      storage.repository.readEpisodeAggregate(ids.project, initial.episodeId)?.episode,
    ).toMatchObject({ status: 'ANALYSIS_FAILED', revision: 4 })
  })
})

describe('continuous Builder follow-up preparation', () => {
  async function completedHarness() {
    const harness = await createHarness()
    seedBuilderGraph(harness.storage)
    const workspace = join(
      harness.workspaceRoot,
      ...projectFixture.generatedWorkspacePath.split('/'),
    )
    await mkdir(workspace, { recursive: true })
    await writeFile(join(workspace, 'user-source.ts'), 'preserved user source')
    harness.storage.transaction((repository) => {
      repository.appendTask(
        builderTaskSchema.parse({ ...builderTaskFixture, revision: 2, status: 'COMPLETED' }),
      )
      repository.appendCompletionReport(completionReportFixture)
    })
    return { ...harness, workspace }
  }
  const request = () => ({
    schemaVersion: 1 as const,
    actor: { kind: 'UI' as const },
    kind: 'UI_PREPARE_FOLLOW_UP_TASK' as const,
    correlationId: ids.correlation,
    idempotencyKey: 'idem_' + randomUUID(),
    projectId: ids.project,
    sourceTaskId: ids.task,
    expectedSourceTaskRevision: 2,
    userGoal: 'Explain how the existing implementation handles retries.',
  })

  it('creates one following Task, keeps its source report/workspace, and restores without creating another', async () => {
    const { service, storage } = await completedHarness()
    const before = storage.repository.readBuilderTaskAggregate(ids.project, ids.task)
    const command = request()
    const [first, retry] = await Promise.all([
      service.executeUi(command),
      service.executeUi(command),
    ])
    expect(first.success).toBe(true)
    expect(retry).toEqual(first)
    if (!first.success) throw new Error(first.error.code)
    const next = preparedBuilderTaskDescriptorSchema.parse(first.data)
    expect(next.task).toMatchObject({
      sequence: 2,
      status: 'PENDING',
      prerequisiteTaskIds: [ids.task],
    })
    expect(next.workspacePath).toBe(projectFixture.generatedWorkspacePath)
    expect(storage.repository.readBuilderTaskAggregate(ids.project, ids.task)).toEqual(before)
    const context = await service.executeAgent('BUILDER', {
      schemaVersion: 1,
      actor: { kind: 'AGENT', role: 'BUILDER' },
      kind: 'BUILDER_GET_TASK',
      correlationId: ids.correlation,
      projectId: ids.project,
      taskId: next.task.id,
    })
    expect(context, JSON.stringify(context)).toMatchObject({
      success: true,
      data: { previousCompletionReport: completionReportFixture },
    })
    for (let n = 0; n < 2; n++) {
      expect(
        await service.executeUi({
          schemaVersion: 1,
          actor: { kind: 'UI' },
          kind: 'UI_RESTORE_PROJECT_SESSION',
          correlationId: ids.correlation,
          projectId: ids.project,
          helperConversationLimit: 20,
        }),
      ).toMatchObject({ success: true, data: { currentTask: { id: next.task.id } } })
    }
    expect(await service.executeUi(request())).toMatchObject({
      success: false,
      error: { code: 'FOLLOW_UP_SOURCE_NOT_CURRENT' },
    })
    expect(
      await service.executeAgent('BUILDER', {
        schemaVersion: 1,
        actor: { kind: 'AGENT', role: 'BUILDER' },
        kind: 'BUILDER_START_TASK',
        correlationId: ids.correlation,
        idempotencyKey: 'idem_' + randomUUID(),
        projectId: ids.project,
        taskId: next.task.id,
        expectedTaskRevision: 1,
      }),
    ).toMatchObject({ success: true })
    expect(
      storage.repository.readBuilderTaskAggregate(ids.project, ids.task)?.completionReport,
    ).toEqual(completionReportFixture)
    storage.close()
  })

  it('allows Helper questions on the completed Task before another Builder request', async () => {
    const { service, storage } = await completedHarness()
    expect(
      await service.executeUi({
        schemaVersion: 1,
        actor: { kind: 'UI' },
        kind: 'UI_OPEN_HELPER',
        correlationId: ids.correlation,
        projectId: ids.project,
        taskId: ids.task,
        question: 'Why does this implementation use a map?',
      }),
    ).toMatchObject({ success: true })
    expect(storage.repository.readLatestTaskForProject(ids.project)?.id).toBe(ids.task)
    storage.close()
  })

  it('rejects stale, empty and cross-project requests without changing completed work', async () => {
    const { service, storage } = await completedHarness()
    for (const change of [
      { expectedSourceTaskRevision: 1 },
      { userGoal: ' ' },
      { projectId: 'project_00000000-0000-4000-8000-000000000905' },
    ]) {
      expect(await service.executeUi({ ...request(), ...change })).toMatchObject({ success: false })
      expect(storage.repository.readLatestTaskForProject(ids.project)?.id).toBe(ids.task)
    }
    storage.close()
  })
})
