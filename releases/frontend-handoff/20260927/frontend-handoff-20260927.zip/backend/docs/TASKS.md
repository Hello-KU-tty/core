# 작업 계획

## 1. 상태 표기와 실행 규칙

- `[ ]`: 아직 시작하지 않음
- `[-]`: 선행 결정이나 외부 조건 때문에 대기
- `[>]`: 다음에 실행할 작업. 문서 전체에서 반드시 하나만 둔다.
- `[~]`: 진행 중
- `[x]`: 완료하고 완료 조건을 검증함

작업은 위에서 아래로만 진행해야 한다는 뜻이 아니다. 다만 선행 조건을 만족하지 않은 작업은 시작하지 않는다. 각 작업을 끝낼 때 산출물과 완료 조건을 실제로 확인한 뒤 상태를 갱신한다. 제품 범위가 바뀌면 먼저 `PROJECT_BRIEF.md`, `docs/SPEC.md`, `docs/ARCHITECTURE.md`, `docs/DECISIONS.md`를 정합하게 고친 뒤 이 문서를 조정한다.

MVP는 단순 화면 시제품이 아니라 `Discovery → Learning Spec → Builder → 실제 Decision → Helper → Evidence → 다음 개인화`가 한 번 이어지는 검증 가능한 수직 흐름이다. 공통 계약과 상태 처리부터 만들고, Agent와 UI는 그 위에 연결한다.

2026-09-23 사용자 승인으로 Windows 주 사용 환경과 확장 설치 후 Core 자동 실행을 MVP 필수로 둔다. [Windows 인계](WINDOWS_EXTENSION_HANDOFF_20260923.md)의 T19-W 작업은 native recovery에서 분기해 수행한다. T19/T19-N의 기존 검증·미완료 기록은 보존하며 T28까지 제품 설치 작업을 미루지 않는다.

## 2. MVP 이전: 핵심 수직 흐름 완성

### [x] T19-M1. Mac 배포용 VSIX

- **승인/선행:** 2026-09-29 Mac 배포용 사용자 요청, 기존 Mac source attestation 및 실제 frontend.
- **산출물:** darwin-arm64 VSIX, source 독립 Core 자동 기동·도구 준비, 설치 안내와 hash receipt.
- **완료 조건:** 패키지 inventory/누출 검사, 실제 SQLite/Core lifecycle·생성 앱 도구와 설치 parser 검증. 유료 Agent 완주·Intel Mac·Windows 지원은 별도 기록한다.
- **검증:** 0.1.0 darwin-arm64 VSIX 72항목/41,564,663 bytes, Kiro 격리 설치 PASS. 설치된 자산을 한국어·공백 경로로 옮겨 실제 Core 공유·reload·최종 lease 종료/재시작과 durable Project, bundled Node/managed pnpm 실행·launcher 변조 거절 5개 PASS(모델0). unit177+3SKIP, integration384+8SKIP, eval42, Campus3, smoke6, E2E12, 패널169+2SKIP 및 Mac terminal scope1 PASS. 전체 check의 기존 중첩 Biome 설정 충돌과 최초 E2E 포트 충돌은 [Mac 안내](MAC_VSIX.md)에 보존한다.

### [x] T19-M3. 최신 원격 소스·Mac 설치물·개발자 ZIP·README 게시

- **승인/선행:** 2026-09-30 사용자 요청, 원격 최신 core/program 통합과 기존 Mac 변경 보존.
- **산출물:** frontend a61d408(0.0.18) 기준 Mac 0.1.1, 동일 URL의 최신 개발자 소스 ZIP, 실제 사용 인터뷰와 검증 한계를 구분한 README, 출처·무결성·설치 안내, commit/push.
- **완료 조건:** 양쪽 소스 검사, ZIP 추출 재현, VSIX 격리 설치와 모델0 Core/도구 재사용 검사, 다운로드 주소 및 게시 hash 확인. 0.0.18 동기화로 이전 frontend 미공개 조건을 해소한다. 영상은 수정하지 않는다.
- **검증/게시:** frontend 0.0.18의 807 tests·typecheck·build, 최종 ZIP 추출본의 frozen install→`pnpm check`(unit177/integration404/eval43/Campus3/smoke6/E2E12, 11 SKIP), 패널·개발 host·source 회귀220+2 SKIP, 실제 frontend HTTP/SSE/SQLite consumer와 완료 뒤 Builder3/Helper3 PASS. 격리 Kiro 설치와 설치 자산 lifecycle/도구6개 PASS, 최종 ZIP 재빌드 VSIX72항목 hash 일치. Mac41,582,063 bytes 및 ZIP4,837,102 bytes를 기존 주소에 게시하고 두 URL에서 다시 받은 SHA-256 일치를 확인했다. Core `b7beeb3`·`a0ce3a8`, program `e65cd7f`를 기존 main에 push했다. [Mac receipt](../releases/macos/0.1.0/macos-vsix-receipt.json)·[ZIP receipt](../releases/frontend-handoff/20260927/frontend-handoff-receipt.json). 모델0이며 새 설치본 native 완주는 T19-M2로 남긴다. 사용자 원본·영상·기존 실험과 보존 stash는 유지했다.

### [~] T19-M4. 후속 감사 복구·문서·로컬 후보

- **승인/선행:** 2026-09-30 사용자 전체 보완 승인, commit까지만 수행.
- **산출물:** Mac persistent Node/업그레이드·사라진 workspace 회귀, 역사 문서 정합성, 로컬 조직 소개 초안, 같은 경로의 Mac 0.1.2/개발자 ZIP 후보.
- **완료 조건:** 관련 보안·복구 회귀, 최신 설치 자산 검사, 소스 ZIP clean 전체 check와 출처/hash 기록. 실제 모델 검증은 T19-M2에서 별도 판정하며 push하지 않는다.
- **소스 검증:** 집중38PASS+1SKIP, 추출본 전체check(unit177/integration418/eval43/Campus3/smoke6/E2E12, 11SKIP), frontend807, 패널 등219+2SKIP, 실제 consumer/완료 후속 요청 PASS. 실제 패키지 자산8개·격리 설치69개 hash·추출 소스 재빌드72항목 일치. Chromium sandbox의 최초 실행 차단을 기록하고 허용된 테스트 전용 환경에서 전체 재실행했다. 최종 ZIP/receipt 로컬 묶음을 준비 중이며 공개/유료 모델 호출은 하지 않았다.

### [-] T19-M2. Mac 설치본의 실제 native 수직 흐름 검증

- **선행:** T19-M1, 설치된 Kiro 본인 계정과 사용량 확인. 현재 패키징 세션에서는 유료 호출을 하지 않았다.
- **현재 대기:** 새 격리 합성 폴더 Trust 승인 및 현재 계정 사용량 확인. 이 조건 없이 모델 호출하지 않는다.
- **산출물/완료 조건:** 새 학습 목표의 Discovery→Spec→Builder·Helper·Decision→결과 실행/History를 설치본에서 실측하고 terminal 도구 환경·별도 Helper 창·취소와 실패를 기록한다. Windows/Intel/장기 사용으로 확대하지 않는다.

### [x] T00. 문서 승인과 착수 차단 결정 해소

**승인 기록**

- 2026-08-24 사용자가 제시된 기본안을 전부 승인했다.
- 제품 범위, local-first MVP, Agent 중심 primary와 Code 중심 thin prototype, Campus Drop fixture, 개발 도구 방향, spike-first 원칙과 사용자 연구·데이터 원칙이 승인됐다.
- runtime schema·SQLite library 같은 세부 도구는 호환성 검토 후 Agent가 결정 기록에 남기도록 위임됐다.

**범위**

- `PROJECT_BRIEF.md`, `docs/SPEC.md`, `docs/ARCHITECTURE.md`, 이 작업 계획과 `docs/DECISIONS.md`를 함께 검토한다.
- MVP 정의와 대회 제출 전 강화 범위를 분리한 현재 계획을 승인하거나 수정한다.
- 구현을 시작하기 전에 필요한 기술 선택과 spike 질문을 결정 기록으로 남긴다.

**선행 조건**

- bootstrap 문서가 모두 생성되어 있어야 한다.

**산출물**

- 승인되거나 수정된 bootstrap 문서
- package manager, Node 기준, SQLite 후보, runtime schema 도구와 test 도구에 대한 결정
- Crew/Kiro capability spike의 성공·실패 기준
- MVP에서 요구할 실행·배포 수준과 Code 중심 thin prototype 경계
- 초보 사용자 검증의 동의·redaction·reviewer 원칙

**완료 조건**

- `docs/DECISIONS.md`의 구현 차단 항목이 `승인` 또는 명시적인 `spike 후 결정` 상태다.
- 서로 충돌하는 요구가 남아 있지 않고 사용자가 구현 계획을 승인했다.
- 다음 실행 작업이 T01로 지정돼 있고 `[>]` 표기가 문서 전체에 하나뿐이다.

### [x] T01. Kiro/Crew capability spike

**실행 계획**

- 상세 계획: [KIRO_CREW_CAPABILITY_SPIKE.md](spikes/KIRO_CREW_CAPABILITY_SPIKE.md)
- 상태: 2026-08-25 완료. dashboard의 두 독립 chat pane, Agent별 MCP 권한, Decision handoff, 숨은 no-tool Analyst slot과 Kiro IDE Workspace Agent fallback을 검증했다. Crew event/spawn/reinstall persistence의 한계는 Core MCP·stable ID·REST polling fallback으로 확정했다. 전역 third-party 허용은 사용하지 않았다.

**범위**

- 최소 Crew App을 열어 UI render, App event 수신, Agent chat slot, background dispatch와 MCP tool 연결 가능성을 확인한다.
- Crew App과 Kiro editor/Agent 사이에서 공유 가능한 session, project, task와 workspace 식별자를 조사한다.
- TypeScript에서 Kiro Gateway REST/WebSocket을 직접 호출해야 하는지, 공개된 다른 안전한 경로가 있는지 검증한다.
- Code 중심 surface가 같은 Core 상태를 읽고 Builder/Helper에 접근할 수 있는 최소 범위를 확인한다.

**선행 조건**

- T00의 spike 기준이 승인되어야 한다.

**산출물**

- capability matrix: `검증됨`, `부분 검증`, `불가`, `추가 확인` 상태와 재현 절차
- session/context 공유 방식의 작은 실험 결과
- Crew adapter와 Code 중심 thin prototype의 실제 구현 경계
- 불가능한 기능의 fallback과 관련 결정 기록

**완료 조건**

- 다른 개발자가 같은 환경에서 spike 결과를 재현할 수 있다.
- R2·R3 위험을 계속 수용할지 또는 fallback을 쓸지 결정돼 있다.
- 검증되지 않은 Kiro 기능을 이후 작업의 전제로 남기지 않는다.

### [x] T02. 저장소 골격과 검증 도구 구성

**검증 기록**

- 2026-08-25 Node.js 24.19.0과 pnpm 11.12.0에서 `pnpm check` 전체가 통과했다.
- clean copy에서 `pnpm install --frozen-lockfile`, typecheck, SQLite integration, build와 module-boundary/artifact smoke를 재현했다.
- Crew App이 storage/transport 세부사항을 직접 import하지 않는 dependency graph test와 source map·절대 경로·local data ignore 검증을 추가했다.

**범위**

- 승인된 package manager로 TypeScript workspace를 구성한다.
- `apps/crew-app`, `apps/mcp-server`, `packages/contracts`, `packages/domain`, `packages/application`, `packages/storage-sqlite`, `packages/kiro-adapter`, `tests/eval` 경계를 만든다.
- typecheck, unit, integration, E2E와 formatting/lint 명령을 최소 구성한다.

**선행 조건**

- T00의 개발 도구 결정과 T01의 Kiro 경계가 확정되어야 한다.

**산출물**

- 빌드 가능한 workspace skeleton
- root 및 package별 설정
- 빈 예제 대신 module boundary를 검증하는 smoke test
- 실제 명령이 반영된 README와 AGENTS 업데이트

**완료 조건**

- clean checkout 기준 설치, typecheck와 smoke test 명령이 성공한다.
- UI package가 storage 구현이나 Kiro transport 세부사항을 직접 import하지 않는다.
- source map이나 log에 secret이 들어가지 않는 기본 환경 설정이 있다.

### [x] T03. 공유 데이터 계약과 runtime validation

**검증 기록**

- 2026-08-25 Node.js 24.19.0과 pnpm 11.12.0에서 `pnpm check` 전체가 통과했다.
- contract integration 54개, workspace unit 2개, smoke 4개와 Chromium E2E 1개가 통과했다.
- strict schema v1의 정상·누락·초과·구버전 JSON fixture, JSON round trip, enum·ID·UTC timestamp·path·lineage·source provenance·Agent 권한 거절을 검증했다.
- Discovery, Learning Spec, Build/Decision, Activity/Episode, Evidence/Concept Ledger, audit, evaluation과 Agent/UI request가 public contract export에서 확인됐다.

**범위**

- Discovery, Learning Spec, Build Task, Live Context, Decision, Event, Episode, Evidence Proposal, Concept Ledger와 audit contract를 정의한다.
- 모든 외부 입력과 Agent 출력을 runtime schema로 검증한다.
- version, id, timestamp, correlation id, revision lineage와 source reference 규칙을 고정한다.

**선행 조건**

- T02 workspace가 준비되어야 한다.

**산출물**

- `packages/contracts`의 TypeScript type과 runtime schema
- 정상·누락·초과·구버전 payload fixture
- contract serialization 및 validation test

**완료 조건**

- `docs/SPEC.md` 7장의 핵심 데이터 영역을 빠짐없이 표현한다.
- 잘못된 enum, 권한, path, version과 source reference가 명확한 오류로 거절된다.
- Agent별로 읽고 쓸 수 있는 payload가 contract 수준에서 구분된다.

### [x] T04. Domain reducer와 상태 불변식

**검증 기록**

- 2026-08-25 Node.js 24.19.0과 pnpm 11.12.0에서 `pnpm check` 전체가 통과했다.
- unit 2개, package contract/domain/storage 78개, smoke 4개와 Chromium E2E 1개가 통과했다.
- Candidate merge/refinement lineage, immutable Spec 확인, Task/Decision 허용 전이, Episode event scope와 중복 replay를 검증했다.
- Evidence policy v1.0.0에서 Agent-authored source, weak/directly-led 신호, 과도한 maximum state와 stale/duplicate proposal을 이유와 함께 거절했다.
- contradiction은 `MISCONCEPTION_SIGNAL`로 open issue에 분리하고 State를 강등하지 않으며, 동일 Evidence log의 순서가 달라도 같은 State와 trace를 만드는 것을 검증했다.

**범위**

- Candidate revision, Spec 확정, Task/Decision transition, Episode close, Evidence 채택·거절과 Concept State 계산을 순수 함수로 구현한다.
- `OBSERVED → EXPLAINED → DEMONSTRATED → TRANSFERRED`의 지지 근거와 MISCONCEPTION open issue를 분리한다.
- 한 번의 contradiction이나 Agent-authored 내용이 강한 Evidence 또는 즉시 강등으로 이어지지 않도록 한다.

**선행 조건**

- T03 contract가 안정화되어야 한다.

**산출물**

- `packages/domain` reducer와 policy
- 정상, 경계, 충돌, 중복 제출 fixture
- state transition과 rejection reason unit test

**완료 조건**

- 같은 입력 log는 항상 같은 최종 state와 trace를 만든다.
- Analyst가 직접 state를 변경할 수 없고 invalid proposal은 이유와 함께 거절된다.
- Agent 설명, 단순 확인과 카드 클릭만으로 `DEMONSTRATED` 이상이 되지 않는다.

### [x] T05. SQLite schema, repository와 migration

**범위**

- Project, Candidate, Spec, Task, Context, Decision, Event, Episode, Evidence, Concept Ledger와 audit 저장소를 구현한다.
- append 중심 이력과 최신 snapshot projection을 구분한다.
- schema version, migration, transaction, backup 가능한 local path와 corruption 대응을 정한다.

**선행 조건**

- T03 contract와 T04 불변식이 있어야 한다.

**산출물**

- `packages/storage-sqlite` schema와 repository
- 빈 DB 생성 및 migration fixture
- transaction, 재시작, 중복 event와 rollback integration test

**완료 조건**

- 프로세스를 재시작해도 selected candidate, active task, pending decision, context와 evidence trace가 복원된다.
- migration 실패가 기존 DB를 부분 변경하지 않는다.
- secret redaction 이전의 raw payload가 DB에 저장되지 않는다.

### [x] T06. Application use case와 MCP 권한 경계

**승인 기록**

- 2026-08-25 사용자가 역할 고정 MCP catalog, 요청당 2 MiB payload 제한, canonical workspace containment, canonical request hash 기반 idempotency와 공식 MCP client contract test 계획을 승인했다.
- user-authored Discovery feedback은 UI application command로만 처리하고 Discovery Agent MCP catalog에는 노출하지 않는다.

**검증 기록**

- 2026-08-25 Node.js 24.19.0에서 format, lint, typecheck, Drizzle schema, unit 2개, package/app integration 100개, build, smoke 4개를 통과했다.
- macOS sandbox가 Chromium Mach port 등록을 막는 조건을 분리한 뒤 승인된 외부 실행에서 Playwright Chromium E2E 1개를 통과했다.

**범위**

- Core use case를 Agent와 UI에서 공통 호출하도록 application layer를 만든다.
- Discovery, Builder, Helper와 Analyst별 allowlist MCP tool을 구현한다.
- workspace path, payload size, source reference, stale version, idempotency와 권한을 검증한다.

**선행 조건**

- T03~T05가 완료되어야 한다.

**산출물**

- `packages/application` command/query handler
- `apps/mcp-server` tool group과 authorization policy
- 권한 matrix 및 공격성 payload contract test

**완료 조건**

- Helper와 Analyst의 write/shell/Decision 확정 시도가 코드 수준에서 거절된다.
- Builder도 생성 workspace 바깥 path에 접근할 수 없다.
- 임의 SQL, 임의 file read/write와 문서에 없는 범용 tool이 노출되지 않는다.

### [x] T07. 평가 harness와 기준 fixture 선구축

**검증 기록**

- 2026-08-26 Node.js 24.19.0과 pnpm 11.12.0에서 format, lint, typecheck, Drizzle schema, unit 2개, package/app integration 104개, eval 5개, build와 smoke 4개가 통과했다.
- macOS sandbox의 Chromium Mach port 제한을 분리한 승인된 외부 실행에서 Playwright E2E 1개가 통과했다.
- Campus Drop과 unseen goal 3개, Personal Need 유무, good/bad calibration 8개로 contract, mode collapse, scope leak, stale Context, trivial Decision, false mastery/misconception과 redaction leak을 재현했다.
- 사람 의미 review 누락은 `NEEDS_REVIEW`로 보존하고, calibration baseline 재생 결과가 committed JSON과 일치함을 검증했다.
- revisioned Evaluation Run과 immutable Baseline Result의 migration, idempotent 저장, revision conflict와 복구를 SQLite integration test로 검증했다.
- `tests/eval/TRACEABILITY.md`에 AC-MVP-001~014의 현재 test/eval 근거와 최종 검증 작업을 연결했다.

**범위**

- Agent 구현 전에 Discovery 다양성, Spec scope, Context completeness, Decision 필요성, Evidence 품질과 redaction을 평가할 fixture를 만든다.
- Campus Drop은 회귀용 고정 fixture로 두고, 서로 다른 learning goal과 선택적 personal need를 가진 unseen fixture를 추가한다.
- 자동 검증과 사람 review가 필요한 항목을 구분한다.

**선행 조건**

- T03 contract와 T04 reducer가 있어야 한다.

**산출물**

- `tests/eval` fixture corpus와 scorer interface
- baseline 결과 저장 형식
- false mastery, false misconception, stale context와 candidate mode collapse 사례

**완료 조건**

- 고정 답안을 강제하지 않고 contract 위반과 품질 차이를 재현 가능하게 측정한다.
- Campus Drop만 통과하도록 특화된 구현은 unseen fixture에서 드러난다.
- 각 MVP acceptance criterion이 어떤 test/eval로 검증되는지 추적표가 있다.

### [x] T08. Discovery Agent와 반복 Candidate loop

**검증 기록**

- 2026-08-26 Node.js 24.19.0과 pnpm 11.12.0에서 format, lint, typecheck, Drizzle schema, unit 2개, package/app integration 113개, eval 6개, build와 smoke 4개가 통과했다.
- macOS sandbox의 Chromium Mach port 제한을 분리한 승인된 외부 실행에서 Playwright E2E 1개가 통과했다.
- Candidate feedback은 결과 revision을 미리 기록하지 않고 다음 round의 `appliedFeedbackIds`로 연결했으며 PIN, REJECT, MERGE, REVISE, SHRINK, EXPAND, REGENERATE와 SELECT의 lineage/current-round invariant를 domain/application test로 검증했다.
- Discovery prompt v1.0.1을 canonical 문서에서 로드하고 role-bound MCP adapter가 Candidate/Round ID, revision, timestamp, provenance와 input snapshot을 공급하는 최소 tool input을 contract test로 검증했다. Agent catalog에는 user feedback, 범용 file/shell/SQL/network 또는 SELECT tool이 없다.
- synthetic unseen 입력에서 Kiro CLI 2.19.2 Agent Engine v2와 `claude-haiku-4.5`가 실제 MCP→Application→SQLite로 8개 Candidate Round를 약 90초에 저장하고 정상 종료했다. 해당 출력은 strict contract·구조 scorer와 기록된 사람의 의미 다양성·Concept Necessity review를 통과했다.
- 같은 CLI 2의 `auto` 모델은 생성 시간이 길어질 때 첫 submit 전에 `Transport closed`가 재현됐다. 동일 payload가 fresh 공식 stdio MCP client에서 즉시 수락되므로 Core 결함이 아닌 host lifecycle 결함으로 분류했고, T09 진행을 막지 않되 T15·T19·T21에 제품 host 재검증 gate를 남겼다.
- 현재 round의 latest revision만 선택 가능하고 user-authored SELECT 뒤 Project가 `SPEC_REVIEW`, Discovery Session이 `SELECTED`가 되며 이후 feedback/round가 거절됨을 integration test로 확인했다.

**범위**

- Learning Goal을 필수로, Personal Need·불편·관심·현재 수준을 선택으로 받는다.
- 고정 taxonomy가 아닌 다채로운 후보를 기본 약 10개 생성하고, need가 있으면 관련·독립 후보를 함께 만든다.
- pin, reject, merge, revise, shrink, expand, regenerate와 자유 대화를 같은 revision loop에 연결한다.

**선행 조건**

- T06 MCP 경계와 T07 Discovery eval이 있어야 한다.

**산출물**

- Discovery prompt 연결과 tool adapter
- Candidate revision/lineage 저장 흐름
- 다양성, 범용성, learner fit과 명시적 final 선택 test

**완료 조건**

- `availableTime` 입력 없이 AC-MVP-001과 AC-MVP-002가 통과한다.
- 고정된 10개 주제를 순환하지 않고 unseen goal에서도 의미 있게 다른 후보가 나온다.
- Agent가 사용자의 명시적 선택 전 후보를 Final로 바꾸지 못한다.

### [x] T09. Learning Spec 생성·조정·확정

**검증 기록**

- 2026-08-27 Node.js 24.19.0과 pnpm 11.12.0에서 format, lint, typecheck, Drizzle schema, unit 2개, package/app integration 119개, eval 7개, build와 smoke 4개가 통과했다.
- macOS sandbox의 Chromium Mach port 제한을 분리한 승인된 외부 실행에서 Playwright E2E 1개가 통과했다.
- selected Candidate에 대한 첫 Agent draft, Agent와 사용자의 연속 revision, stale/idempotent 경계, 내용 불변 사용자 확정과 확정 전 Builder Task 미생성을 domain/application/MCP integration test로 검증했다.
- `다른 주제로 돌아가기`는 selected Session을 다시 열지 않고 current draft를 `SUPERSEDED`로 닫은 뒤 같은 입력의 새 active Discovery Session을 만들며 이전 selection과 Spec lineage를 보존한다.
- Discovery prompt v1.1.0과 role-bound `submit_learning_spec`은 의미 내용만 Agent에게 받고 Spec ID, selected Candidate, revision, parent, timestamp, source와 redaction status를 Core 경계에서 채운다. 공식 MCP client test에서 첫 draft와 다음 revision의 SQLite 저장을 검증했다.
- `LEARNER_FOCUS` concept만 필수 Evidence target으로 도출하고 `AGENT_SUPPORT`와 `EXCLUDED`는 제외됨을 deterministic test와 prompt regression fixture의 자동·사람 review로 확인했다.
- 로그인된 Kiro CLI 2.19.2의 Agent Engine v2와 `claude-haiku-4.5`로 bounded live Spec runner를 실행했다. synthetic selected Candidate를 읽은 Agent가 prompt v1.1.0의 semantic-only 입력으로 role-bound MCP→Application→SQLite에 DRAFT Spec revision 1을 저장했고 Session revision 4와 Core-owned metadata가 검증됐다. 생성 결과는 discriminated union/runtime validation을 `LEARNER_FOCUS`, local UI shell을 `AGENT_SUPPORT`, live credential/hosted storage를 `EXCLUDED`로 유지했으며 실제 Decision 후보와 local TypeScript 제약을 포함했다.

**범위**

- 선택 Candidate를 `LEARNER_FOCUS`, `AGENT_SUPPORT`, `EXCLUDED`로 나눈 권장 Spec으로 변환한다.
- 제품 목적, 사용자, 성공 순간, MVP 기능, 실제 Decision 후보, TypeScript와 배포 제약을 포함한다.
- `이대로 시작`, `조금 바꾸기`, `다른 주제로 돌아가기` 흐름을 제공한다.

**선행 조건**

- T08 Candidate loop가 완료되어야 한다.

**산출물**

- Spec generation/refinement flow
- scope validation과 revision 저장
- 부담 없는 기본 확정 경로와 자유 수정 경로 test

**완료 조건**

- AC-MVP-003이 통과하고 사용자가 확정하기 전 Builder Task가 생기지 않는다.
- `AGENT_SUPPORT`와 `EXCLUDED` 항목이 Evidence 목표로 잘못 계산되지 않는다.
- 초기 진입은 확인 중심이되 Spec의 실질적 제어권은 사용자에게 남는다.

### [x] T10. Builder Task, workspace와 Live Context

**검증 기록**

- Node.js 24.19.0과 pnpm 11.12.0에서 format, lint, typecheck, Drizzle schema, unit 2개, package/app integration 132개, eval 8개, build와 smoke 4개가 통과했다.
- macOS sandbox에서 Chromium Mach port 등록만 거절된 뒤 승인된 외부 실행에서 기존 Playwright E2E 1개가 통과했다.
- confirmed-before-prepare, Spec scope→Task mapping, pending Task 재시작 복구, 첫 `TASK_STARTED`, stale/idempotent Context, mid-task Helper freshness, 마지막 `TASK_COMPLETED`, Completion Report scope와 false-mastery 금지를 application/MCP integration과 Builder prompt v1.0.0 regression fixture로 검증했다.
- native file/shell guard는 상대 traversal, symlink escape, `.kiro` 보호 경로와 허용되지 않은 command를 거절하며, transient stream redaction은 credential sentinel과 user-home path를 제거함을 검증했다. Crew slot은 첫 message 전에 canonical project directory를 `/api/chat/slots/{slot}/project`에 연결하지 않으면 dispatch할 수 없다.
- 로그인된 Kiro CLI 2.20.0 Agent Engine v2와 `claude-haiku-4.5`로 bounded live Builder runner를 실행했다. Agent가 role-bound MCP로 Task를 시작하고 Context version 1~3을 저장한 뒤 TypeScript discriminated union을 구현해 초기 실패 test를 통과시켰으며, Task revision 3의 durable Completion Report와 같은 version 3의 Helper Context를 복원했다.
- runtime boundary probe의 workspace 밖 sentinel은 변경되지 않았고 독립 `node --test`는 exit code 0이었다. raw stream은 저장하지 않았으며 redaction된 transient stream에서 message, tool call, file change, test result, status와 차단된 boundary probe error를 확인했다. macOS sandbox 안의 Kiro v2 ACP 초기화 실패는 같은 최소 채팅과 권한 확장 실행을 비교해 host 격리 제한으로 분리했다.

**범위**

- 확정 Spec을 acceptance criterion이 있는 Task로 바꾼다.
- 생성 workspace 안에서 TypeScript 파일 수정, 명령, test와 debug를 수행하는 Builder 흐름을 연결한다.
- 시작, 방향 변경, Concept 도입, Decision, 오류로 인한 계획 변경, test와 완료마다 Live Context를 갱신한다.

**선행 조건**

- T06 application/MCP와 T09 Spec 확정이 있어야 한다.

**산출물**

- Builder prompt/tool adapter
- Task lifecycle과 workspace boundary
- versioned Live Context 및 stale update 처리
- 사용자에게 보이는 message/tool/file/test stream

**완료 조건**

- Builder가 학습 판정을 하지 않으면서 현재 사용 Concept와 코드 참조를 보고한다.
- 작업 도중 Helper가 최신 Context로 현재 목표·변경·다음 작업을 설명할 수 있다.
- stream을 숨기지 않고 Live Progress가 현재 위치를 보조한다.

### [x] T11. 실제 Decision과 Builder 재개 흐름

**승인 기록**

- 2026-09-01 사용자가 의미 기반 Decision 요청, blocking 여부에 따른 Task gate, Helper context handoff, 사용자 해결, Builder 적용·재개와 이유 없는 추천 수락의 Evidence 차단 계획을 승인했다.
- 실제 Helper 대화 품질은 T12, Decision UI는 T16, Activity/Episode 조립은 T13 범위로 유지한다.

**검증 기록**

- 2026-09-01 Node.js 24.19.0과 pnpm 11.12.0에서 format 113 files, lint 113 files, typecheck, Drizzle schema, unit 2개, package/app integration 138개, eval 8개, build와 smoke 4개가 통과했다. macOS sandbox의 Chromium Mach port 제한을 분리한 승인된 외부 실행에서 Playwright E2E 1개도 통과했다.
- semantic-only Decision request와 apply tool, Core-owned ID·timestamp·provenance, Request/`DECISION_REQUIRED` Context atomic write, blocking Task의 `BLOCKED`→`ACTIVE` 재개, independent continuation, option·recommendation·custom Resolution 계약, apply-before-complete와 duplicate applied ID 거절을 domain/Application/공식 MCP client integration으로 검증했다.
- Builder prompt v1.1.0의 `builder-v1.1-decision-webhook`은 user-visible unknown-field 동작 Decision과 최종 application을 strict contract 및 기록된 사람의 Decision Necessity review로 통과했다. 기존 파일명 선택 음성 fixture는 계속 거절됐다.
- 로그인된 Kiro CLI 2.20.2 Agent Engine v2와 `claude-haiku-4.5`의 두 turn live runner가 blocking Decision request, Helper handoff, user recommendation Resolution, Builder resume/application, Context version 5와 Task revision 5 완료를 통과했다. workspace 밖 sentinel은 변경되지 않았고 독립 `node --test` exit code는 0이었다.
- `DECISION_RESOLVED.rationaleProvided=false`인 추천 수락을 사용자 이해 Evidence로 수용하지 않는 deterministic policy 회귀를 통과했다. 실제 Helper 대화, Decision Card와 Episode 조립은 각각 T12, T16, T13에 남겼다.

**범위**

- 제품 동작, 데이터, API, 인증, 보안, 보관, 비용, 주요 아키텍처 또는 학습 Concept에 영향을 주는 실제 선택만 Decision으로 만든다.
- 이유, 선택지, 영향, Builder 추천, Concept와 코드 참조를 제공한다.
- Helper에게 묻기, 추천대로 진행, 직접 선택과 다른 방식 제안을 지원한다.

**선행 조건**

- T10 Builder lifecycle이 있어야 한다.

**산출물**

- Decision gate와 independent task continuation
- 사용자 응답 적용 및 Builder resume
- 결정이 필요한 사례와 Builder가 자율 처리할 사례 fixture

**완료 조건**

- AC-MVP-006이 통과한다.
- 억지 교육용 질문이나 파일명·코드 스타일 같은 되돌리기 쉬운 선택이 Decision으로 노출되지 않는다.
- 이유 없는 추천 수락이 이해 Evidence로 기록되지 않는다.

### [x] T12. Helper의 최소 맥락 조회와 대화

**승인 기록**

- 2026-09-01 사용자가 T12의 bounded context, durable refresh, read-only Helper prompt/adapter, 의미 회귀와 실제 Kiro 검증 계획을 승인했다.
- Helper conversation Event/Episode 생성은 T13, 실제 quick action과 자유 입력 UI는 T16 범위로 유지한다.

**검증 기록**

- 2026-09-01 Node.js 24.19.0과 pnpm 11.12.0에서 format 118 files, lint 118 files, typecheck, Drizzle schema, unit 2개, package/app integration 147개, eval 9개, build와 smoke 4개가 통과했다. macOS sandbox의 Chromium Mach port 제한을 분리한 승인된 외부 실행에서 Playwright E2E 1개도 통과했다.
- Helper Context는 CURRENT/STALE/MISSING을 구분하고, active Task가 없으면 가장 최근 완료 Task로 fallback한다. 질문·Live Context·focused Decision과 연결된 Ledger 최대 5개, 닫힌 Episode 최대 5개, reference 최대 30개와 workspace-contained code excerpt 최대 3개만 반환하며 무관한 Ledger fallback과 raw diff/Builder transcript 저장은 만들지 않는다.
- missing/stale refresh는 versioned `ContextRefreshRequest`로 SQLite에 저장되고 Builder의 다음 Context가 같은 transaction에서 이를 `FULFILLED`로 닫는다. Helper role에는 Core MCP 2개만 있고 file, shell, Decision 해결과 Evidence/State 변경 권한이 없다.
- Helper prompt v1.0.0의 `helper-v1.0-analogy` fixture는 현재 Decision에 연결된 짧은 첫 답변, DB/Excel 복합 비유의 claim 단위 인정·정정, `DEMONSTRATED` 상태의 지속 접근성과 강제 퀴즈 금지를 strict contract와 기록된 사람 review로 통과했다.
- 로그인된 Kiro CLI 2.20.2 Agent Engine v2와 `claude-haiku-4.5` live runner에서 Helper가 current Context tool을 정확히 1회 호출하고 refresh는 요청하지 않았다. Decision 비교, 비유 한계, 선택적 quick action을 답했으며 Context version 1과 Builder-owned state는 불변, source excerpt의 synthetic secret은 미노출이었다.

**범위**

- Helper가 Live Context, Task, Spec, Decision, 관련 Concept State, 과거 Episode, 코드·diff, 필요한 Builder 대화 일부를 순서대로 최소 조회한다.
- 자유 입력을 중심으로 `더 쉽게`, `더 자세히`, `현재 코드 예시`, `선택지 비교` 카드를 제공한다.
- 질문형 비유는 claim 단위 대응 관계로 분해해 맞는 부분과 한계를 답한다.

**선행 조건**

- T10 Context와 T11 Decision flow가 있어야 한다.

**산출물**

- Helper prompt/tool adapter
- stale/missing context refresh 요청
- 모든 Concept State에서 접근 가능한 chat flow

**완료 조건**

- AC-MVP-005가 통과하고 Helper가 모르는 현재 작업을 추측하지 않는다.
- `DEMONSTRATED` 이상에서도 Helper 진입과 질문 제안이 유지된다.
- 카드는 접근성을 높이지만 클릭 자체가 Evidence가 되지 않고 자유 입력을 가리지 않는다.

### [x] T13. Event 정규화, Episode assembler와 Evidence Analyst

**승인 기록**

- 2026-09-02 사용자가 structured Event source, Episode close policy, durable Analysis Job, hidden no-tool Analyst, deterministic Evidence 적용, retry/dead-letter와 live Kiro 회귀 계획을 승인했다.
- FINAL_UPGRADE Episode의 실제 개인화 적용 source는 T18 flow에서 연결하되, T13 contract와 assembler type 경계는 유지하기로 했다.

**검증 기록**

- 2026-09-02 Node.js 24.19.0과 pnpm 11.12.0에서 format 126 files, lint 126 files, typecheck, Drizzle schema, unit 2개, package/app integration 156개, eval 10개, build와 smoke 4개가 통과했다. macOS sandbox의 Chromium Mach port 제한을 분리한 승인된 외부 실행에서 Playwright E2E 1개도 통과했다.
- Builder·Decision·Helper의 검증된 Application 전이가 redacted Activity Event가 되고, BUILD_TASK·DECISION·HELPER_CONVERSATION Episode 종료와 initial Analysis Job 생성은 transaction 하나로 묶인다. DB unique constraint와 idempotency가 닫힌 Episode당 initial dispatch 하나를 보장한다.
- Analysis Job은 30초 soft timeout, 자동 재시도 1회, terminal `FAILED`/`ANALYSIS_FAILED`, UI failure 조회와 수동 재시도, revision·attempt가 다른 late result 거절을 versioned SQLite history로 보존하고 재시작 뒤 복구한다.
- Evidence Analyst prompt v1.0.1은 stable metadata를 만들지 않는 hidden no-tool semantic adapter다. strict empty result도 `SUCCEEDED`로 끝나며, Proposal은 Core가 user-authored source와 상태 cap을 재검증해 채택·거절한다. Builder Concept usage는 사용자 이해와 분리된 `CONCEPT_OBSERVATION`으로만 `OBSERVED`를 만든다.
- `evidence-analyst-v1.0-mixed` fixture와 기록된 사람 review가 직접 유도 반복 `NONE/DIRECTLY_LED`와 독립 적용 `STRONG/INDEPENDENT`를 분리했다. 로그인된 Kiro CLI 2.20.2 Agent Engine v2/`claude-haiku-4.5` live runner에서 tool 0회, Proposal 2개, Core 거절 1개·채택 1개, runtime validation `DEMONSTRATED`, Job `SUCCEEDED`와 Episode `ANALYZED`를 확인했다.

**범위**

- 의미 있는 Activity만 Event로 정규화하고 BUILD_TASK, DECISION, HELPER_CONVERSATION, FINAL_UPGRADE Episode로 묶는다.
- Episode 종료 시 한 번만 Analyst를 호출해 proposal을 만들고 Core reducer가 채택·거절한다.
- Agent-authored 코드·설명과 사용자 발화·선택·전이 행동의 provenance를 분리한다.

**선행 조건**

- T04 reducer, T05 storage와 T10~T12 실제 event source가 있어야 한다.

**산출물**

- Episode assembler와 close policy
- Evidence Analyst prompt/tool adapter
- proposal validator, trace와 open misconception 처리
- 분석 실패 retry/dead-letter 상태

**완료 조건**

- AC-MVP-007~009가 통과한다.
- event마다 LLM을 호출하지 않으며 분석 실패가 code와 Project History를 훼손하지 않는다.
- 어떤 원문·행동이 State 변경·보류에 사용됐는지 사용자에게 설명할 수 있다.

### [x] T14. Crew App shell과 공통 session 복원

**승인 기록**

- 2026-09-02 사용자가 Project History/session read model, Crew Node backend와 same-origin HMAC proxy, deterministic Builder/Helper slot binding, hash route와 공통 상태를 포함한 T14 구현 계획을 승인했다.

**검증 기록**

- 2026-09-02 Node.js 24.19.0과 pnpm 11.12.0에서 `pnpm check` 전체가 통과했다. format·lint 139 files, typecheck, Drizzle schema, unit 2개, package/app integration 165개, eval 10개, production build, smoke 5개와 Chromium E2E 1개를 확인했다.
- 공식 Crew 0.3.0 `AppManifest` parser로 repository root `app.json`의 field와 app-root-relative entry containment을 검증했다. production bundle은 inline style을 포함한 단일 `index.mjs`이며 test SDK, synthetic proxy secret, localStorage fallback, SQLite와 Node module이 섞이지 않음을 확인했다.
- E2E는 빈 History와 loading, 실제 Application command로 만든 Project의 History→Discovery→Build route, deterministic Builder/Helper history redaction, hash route 새로고침 복원, Crew만 끊겼을 때 durable Core 유지, permission denial, recoverable contract error와 Core disconnected 상태를 한 session에서 검증한다.
- Project History/session snapshot은 local SQLite의 project, Discovery/Spec, current·active Task, pending Decision, Live Context와 durable redacted Helper Episode summary를 반환한다. Crew raw history는 보조 source이며 실패해도 저장된 결과를 가리지 않는다.

**범위**

- Crew App에 Discovery, Spec, Build workspace와 Project History route/surface를 만든다.
- App 재진입 시 project, active task, pending decision, context와 Helper conversation을 복원한다.
- loading, empty, disconnected, recoverable error와 permission denial 상태를 공통 처리한다.

**선행 조건**

- T01 capability와 T05~T06 query/use case가 확정되어야 한다.

**산출물**

- Crew App navigation과 session binding
- 공통 stream/status/error component
- state restore integration test

**완료 조건**

- 새 project 생성과 기존 project 재진입이 같은 저장 상태를 사용한다.
- Kiro 연결이 끊겨도 이미 저장한 결과와 history는 볼 수 있고 재시도 방법이 보인다.
- 임의 mock state가 production flow에 섞이지 않는다.

### [x] T15. Discovery와 Spec 사용자 경험

**승인·검증 기록**

- 2026-09-02 사용자가 T15 검토 계획과 구현 착수를 승인했고, target Kiro Crew에 `vibe-helper` 앱 하나를 신뢰·설치·활성화하는 작업을 별도로 승인했다. 기존 `vibe-helper-probe` 신뢰는 유지하고 전역 third-party app 허용은 사용하지 않았다.
- Korean-first Discovery UI에서 Learning Goal 필수·Personal Need/현재 마찰·수준 선택 입력과 순환 placeholder, Candidate grid와 lineage, keyboard 가능한 PIN/REJECT/MERGE/REVISE/SHRINK/EXPAND/REGENERATE/SELECT, 자유 요청과 Agent 진행·timeout·host disconnect·Core-first retry를 구현했다.
- 권장 Learning Spec의 제품 목적·사용자·사용 순간·성공 순간·MVP 기능·세 scope·Decision·runtime/deployment constraint를 직접 편집하거나 Agent로 조정하고, 확정·Builder 준비 또는 새 Discovery Session으로 돌아가는 흐름을 실제 Application/Core revision에 연결했다.
- Discovery prompt v1.1.6 원문을 검증해 phase별 inline Crew Agent config로 생성한다. 최소 `dist/crew-package`는 UI/backend bundle, Agent, SQL migration과 exact native runtime dependency만 포함하며 repository source나 개발 문서를 설치물에 넣지 않는다. Crew backend의 고정 `/mcp/discovery-round`, `/mcp/discovery-merge`, `/mcp/discovery-spec`, `/mcp/discovery-spec-recovery`는 각 phase 최소 tool allowlist만 제공하고 health-gated live port로 등록된다.
- target macOS Kiro Crew 0.3.0에서 MCP initialize protocol `2025-11-25`, `get_discovery_context`와 `submit_candidate_round`를 확인했다. 실제 `auto` Agent가 약 196초에 Candidate 10개와 Round 1개를 SQLite에 atomic 저장하고 Discovery Session revision을 1→2로 올렸으며 slot error와 `Transport closed`는 없었다. 따라서 staged partial submit fallback은 추가하지 않았고 target latency에 맞춰 UI 관찰 제한을 420초로 조정했다.
- Node.js 24.19.0·pnpm 11.12.0에서 `pnpm check` 전체가 통과했다: format/lint/typecheck/Drizzle check, unit 2개, package/app integration 169개, eval 10개, build, smoke 6개와 Chromium E2E 3개. E2E는 빈 필수 입력, keyboard 시작·수정·선택, Spec 직접 편집, Discovery 복귀·재선택, Builder 준비, host disconnect와 safe retry를 real Core/SQLite 경계에서 검증한다.
- 2026-09-03 target UI에서 설치 root의 `apps/crew-app/dist/index.mjs`를 manifest entry로 사용해 Crew의 고정 `ui/` file root와 불일치하는 404 회귀를 확인했다. package를 `ui/dist/index.mjs`로 staging하고 entry를 `dist/index.mjs`로 고정했으며 smoke test가 두 경로의 일치를 검증한다. 기존 앱을 data·secret 보존 update endpoint로 갱신한 뒤 target 정적 bundle이 `200 application/javascript`, backend health와 materialized Discovery MCP가 정상임을 확인했다. 전체 check의 비브라우저 단계와 sandbox 밖 Chromium E2E 3개가 모두 통과했다.
- 2026-09-03 사용자가 Agent 주제 선정뿐 아니라 실제 사용자 흐름의 대기를 함께 줄이는 T15 보완안과 문서·구현 진행을 승인했다. target log에서 최초 10개 약 193초, 같은 project transcript를 재사용한 재생성 약 636초, Spec→Discovery 자동 재생성 약 443초를 확인했고, 후자의 첫 submit은 array가 JSON string으로 전달되어 전체 재생성을 유발했다. progressive starter round, 명시적 MORE, 상세 평가 지연, 즉시 Discovery 복귀, 수정 입력으로 명시적 재시작, Session/revision별 clean slot, bounded transport normalization과 60초 background 전환을 구현했다.
- target Kiro Crew 설치본을 data-preserving update endpoint로 prompt 1.1.2 package에 갱신했다. UI/backend 설치 파일 SHA-256이 `dist/crew-package`와 일치하고, 새 backend PID의 `/health`가 정상이며 기존 SQLite·WAL 파일이 보존됐다. 첫 target 재측정은 prompt 1.1.1에서 5개를 77.2초에 저장했고, 남은 과다 출력 범위를 제한한 1.1.2는 unseen learning goal과 Personal Need 없음 조건에서 4개를 47.4초에 저장했다. 후보 payload는 총 4,096 bytes, round rationale은 51·58자로 줄었고 Session revision 1→2와 atomic Round 저장을 확인했다. 이는 기존 193초 대비 약 75% 단축된 단일 target 관측이며 P95 확정은 T21의 반복 회귀로 남긴다.
- Node.js 24.19.0·pnpm 11.12.0에서 format/lint/typecheck/Drizzle check, unit 2개, package/app integration 174개, eval 11개, build, smoke 6개를 통과했고, sandbox 밖 Chromium E2E 6개가 통과했다. 새 E2E는 최초 4개→MORE 누적 8개, Spec→Discovery Agent 0회·동일 Spec 복귀, 수정 입력 새 Session, host disconnect/retry, 60초 background UI 해제와 terminal tool validation 조기 오류를 실제 Core/SQLite 경계에서 검증한다.
- 2026-09-03 사용자가 2열 card와 작은 checkbox, 후보별 축소·확장 button, 목록 아래 refinement 입력, 직접 편집 중심 Spec과 기존 styling을 실제 사용자 흐름의 문제로 확인했다. SEED Design을 참고한 목록·명확한 선택·모바일 touch target, Kiro purple brand, 목록 위 composer와 읽기 중심 Spec visual review를 승인 범위로 추가했다. UI 작업 중 model/config는 바꾸지 않되 사용자 상호작용 turn P95 30초와 첫 유용 반응 3~5초 지향을 T15 완료 목표로 추가했으므로 기존 47.4초 단일 관측만으로는 T15를 완료 처리하지 않는다.
- 승인된 UI를 구현해 refinement composer와 선택 basket을 Candidate 목록 위에 배치하고, Candidate를 한 열 semantic list와 26px checkbox로 바꿨다. 후보별 shrink/expand action은 제거하고 자연어 예시로 이동했다. Spec은 직접 편집 field 없이 사용자·사용 순간·성공 순간, MVP, scope와 Decision을 읽는 visual review와 큰 Agent 수정 입력으로 교체했다. 390x844 mobile에서 horizontal overflow 없음, 24px 이상 check target, keyboard 선택과 목록 읽기 순서를 Chromium E2E로 검증했다.
- Node.js 24.19.0·pnpm 11.12.0에서 `pnpm check` 전체가 다시 통과했다: format/lint/typecheck/Drizzle check, unit 2개, package/app integration 174개, eval 11개, build, smoke 6개와 Chromium E2E 6개다. target Kiro Crew 설치본도 data-preserving update endpoint로 갱신했고 app이 enabled 상태로 재등록·재기동됐다. 설치된 UI/backend SHA-256은 `dist/crew-package`와 각각 일치한다. UI 완료 조건은 충족했지만 `auto` model 단일 관측 47.4초가 새 30초 목표를 넘으므로 T15 상태는 `[~]`로 유지한다.
- target Tailscale 390x844 mobile에서 Candidate checkbox focus가 1x1px absolute input을 화면에 맞추려고 Kiro의 상위 `overflow:hidden` grid를 `scrollTop=851`로 이동시켜 앱 전체가 blank처럼 사라지는 회귀를 재현했다. checkbox input을 26px in-flow native control로 유지하고 앱 root의 `height:auto`를 명시했다. 수정 설치본에서는 Kiro 상위 grid `scrollTop=0`, checked state와 `1개 담음` 표시를 확인했다. 같은 Kiro mobile nesting을 재현하는 E2E와 `pnpm check` 전체가 통과했다.
- target에서 4개 중 2·3번의 장점을 합친 MERGE Feedback이 정확한 target과 message로 저장됐지만 기존 Core invariant 때문에 다음 Round가 1·4번도 carry한 문제를 확인했다. 선택 target refinement는 결과와 explicit pin만 current 목록에 남기고 unselected Candidate는 immutable history에만 보존하는 narrowing 계약, prompt 1.1.3과 old-round UI projection을 승인 범위로 추가했다. 4개 starter는 기존 10개 생성의 체감 대기를 낮추기 위한 progressive 정책이며 UI에서 8~10개로 확장할 수 있음을 명시한다.
- narrowing 계약을 Core에 적용해 기존 1·4번을 carry한 Round 제출은 거절하고 합친 revision 하나만 current Round로 받도록 했다. 이미 저장된 해당 Round도 UI projection에서 합친 후보만 보여주며 기존 후보와 parent lineage는 history에 보존한다. prompt v1.1.3 regression과 실제 4→8→2개 선택→1개 MERGE E2E를 추가했고, `pnpm check` 전체가 통과했다: unit 2개, package/app integration 175개, eval 12개, build, smoke 6개와 Chromium E2E 6개다. target Kiro 설치본을 data-preserving update endpoint로 갱신했으며 UI/backend SHA-256이 빌드 산출물과 각각 일치한다. 실제 Tailscale 화면에서 문제 Round가 `1개 후보`와 합친 제목만 표시되고 기존 1·4번이 current 목록에서 빠진 것을 확인했다.
- 2026-09-04 사용자가 T15 성능 개선을 아래 순서대로 기록하고 차례로 실행하는 것을 승인했다. target 실측에서 최초 Candidate 4개 저장은 47.4~50.9초, EXPAND 34.5초, MORE 58.1초, 재시도가 발생한 MERGE 60.6초, 첫 Spec은 47.5초였다. Core tool 검증·SQLite 저장은 3~12ms, UI polling 지연은 최대 0.9초여서 주 병목은 `auto` model의 추론, 매 turn의 context 조회 왕복, Candidate와 Spec을 함께 싣는 prompt/tool schema 및 큰 구조화 출력으로 판정했다.
- 동일 synthetic unseen 입력의 model screen에서 Luna는 contract field를 바꾸며 17회 재시도 후 저장에 실패했고, `auto`는 첫 Candidate 41.6초, Haiku는 첫 Candidate 22.1초·Spec 18.2초였다. 따라서 `claude-haiku-4.5`를 고정하고 compact Core snapshot을 ephemeral context로 주입했으며 context가 stale·누락된 경우에만 `get_discovery_context`를 fallback으로 유지했다. 초기 target 5회에서 first Candidate 보수적 P95는 26.4초, Spec은 20.7초였지만 일반 MERGE P95가 52.7초여서 5단계를 실제 적용했다.
- prompt v1.1.5를 ROUND·MERGE·SPEC의 세 Agent로 분리하고 각각 필요한 submit tool만 허용했다. MERGE는 Agent가 의미 Candidate 하나만 제출하면 Core가 pending user Feedback, parent revision, Candidate revision, Round lineage를 계산하는 `submit_candidate_merge`로 축소했다. Spec은 설명보다 `submit_learning_spec`을 먼저 호출하게 했고 stream이 끝났는데 durable 결과가 없으면 420초 polling 대신 즉시 복구 가능한 오류를 표시한다.
- 최종 target Kiro Crew 0.3.0에서 같은 synthetic fixture로 5회 반복한 결과 모든 15개 phase가 context injection과 durable submit에 성공했다. nearest-rank 방식의 보수적 P95는 first Candidate 26.564초, MERGE 21.044초, first Spec 22.900초이고 사용자 action부터 durable 결과까지의 P95도 각각 26.582초, 21.066초, 22.919초다. 모두 30초 gate를 통과해 preview/lazy enrichment 저장 계약 변경은 적용하지 않았다. v1.1.5의 실제 narrowed Candidate·Spec, 사람 review와 privacy-safe latency 배열을 regression fixture로 남겼다.
- Node.js 24.19.0·pnpm 11.12.0에서 최종 `pnpm check` 전체가 통과했다: format/lint 145 files, typecheck, Drizzle check, unit 2개, package/app integration 181개, eval 14개, build, smoke 6개와 Chromium E2E 7개다. 새 E2E는 Agent stream이 끝났지만 durable Core 결과가 없는 상황을 즉시 복구 오류로 표시한다. target 설치본의 UI/backend와 ROUND·MERGE·SPEC Agent SHA-256이 최종 package와 각각 일치하고 backend health가 정상이며, 설치 전 존재하던 15개 project를 포함한 기존 SQLite 데이터는 보존됐다. 이후 추가된 5개 project는 명시적인 synthetic 성능 표본이다.
- 2026-09-04 실제 사용자 재검증에서 앱 업데이트 전에 열린 UI bundle이 제거된 legacy `vibe-helper-discovery` Agent를 호출해 최초 요청이 거절됐고, 재시도는 범용 file search permission에서 멈췄다. 또한 Agent run 상태가 React memory에만 있어 화면 이탈·재진입 뒤 진행 표시가 사라지고 `첫 주제 선정하기`가 다시 노출됐다. 최신 SPEC Agent도 기존 Spec 수정 요청 두 번에 각각 7.9초·7.3초 만에 설명문만 반환하고 `submit_learning_spec`을 호출하지 않아 durable Spec은 revision 1에 머물렀다. 첫 Spec 생성만 측정한 기존 회귀로는 이 흐름을 보장하지 못하므로 T15를 다시 `[~]`로 열었다.

**재검증 후 보완 실행 순서**

1. `[x]` UI/backend protocol version을 확인해 업데이트 전에 열린 stale bundle의 Agent dispatch를 차단하고 안전한 새로고침 안내를 제공한다.
2. `[x]` current Session/revision/phase의 Crew slot 상태를 재진입 시 조회해 실행 중이면 Core polling을 복원하고, 결과 없이 끝났으면 명시적 재시도 상태를 보여 중복 실행을 막는다.
3. `[x]` 정상 SPEC 경로에는 `submit_learning_spec` 하나만 보이는 최소 Agent/prompt를 사용하고 context 주입 실패 시에만 read+submit recovery Agent로 분기한다.
4. `[x]` 첫 Spec뿐 아니라 기존 Spec 수정의 durable revision 증가, 화면 이탈·재진입, stale bundle과 no-tool 종료를 E2E와 target 반복 측정으로 검증한다.
5. `[x]` Haiku가 수정 저장 신뢰성 또는 P95 30초를 충족하지 못하면 Terra와 Auto를 같은 fixture로 비교하고 contract·품질·성공률을 통과한 모델만 고정한다.

- UI protocol v2를 Core 요청에 붙이고 backend가 불일치 요청을 Agent dispatch 전에 HTTP 409로 차단한다. app version 0.1.1은 UI entry filename에도 포함해 열린 구 bundle과 갱신 설치물을 분리하며 새 UI는 명시적인 새로고침 오류를 보여준다.
- phase slot의 `running` 상태를 재진입 시 조회해 동일 Session/revision 작업에는 Core polling만 다시 연결한다. 결과 없이 끝난 slot과 제거된 legacy Agent slot은 자동 중복 실행 대신 저장 상태 기준의 재시도 또는 수정 요청 재입력을 안내한다.
- prompt v1.1.6의 정상 SPEC Agent는 `submit_learning_spec` 하나만 노출하고 1,858자 최소 prompt를 사용한다. ephemeral context 주입이 불가능할 때만 별도 SPEC recovery Agent가 context read와 submit을 갖는다. 사용자의 수정이 이미 일부 반영된 경우도 질문으로 끝내지 않고 다음 revision 전체를 제출하며, 정상 stream이 no-tool로 끝나면 UI가 최신 Core 상태에서 한 번만 자동 재제출한다.
- Chromium E2E 9개에서 stale protocol, in-flight 재진입·중복 dispatch 0회, 첫 Spec과 정상 수정 revision 2, 첫 no-tool 뒤 자동 복구 revision 2를 검증했다. target synthetic 실행에서도 Haiku 정상 수정은 19.256~24.903초에 revision 2로 저장됐지만 final raw 2회 중 1회는 no-tool로 끝났다. UI bounded recovery가 이 편차를 처리하며 두 번째 실패는 사용자에게 숨기지 않는다.
- model 비교에서 SPEC만 Terra는 첫 Spec 43.257초·수정 14.270초, SPEC만 Auto는 39.240초·36.027초였고 모두 적어도 한 구간이 30초를 넘었다. Haiku 정상 구간은 첫 Spec 18.559~24.178초·수정 19.256~24.903초로 더 빨라 Haiku를 유지한다. 다만 final first Candidate 49.310초 outlier가 다시 관측됐으므로 T15의 장기 30초 gate는 충족됐다고 보지 않고 상태를 `[~]`로 유지한다.
- 최종 `pnpm check`가 format/lint 146 files, typecheck, Drizzle check, unit 2개, package/app integration 185개, eval 15개, build, smoke 6개와 Chromium E2E 10개를 통과했다. data-preserving Kiro update 뒤 project 30개, Discovery Session 31개, Learning Spec 22개가 그대로 유지됐고 backend health가 정상이다. 설치된 versioned UI, backend와 네 Agent SHA-256이 최종 package와 각각 일치하며 네 Agent 모두 prompt v1.1.6·`claude-haiku-4.5`를 사용한다.
- 2026-09-04 사용자가 한 열 Candidate, 상단 refinement composer, 명확한 checkbox와 읽기 중심 Spec을 포함한 T15 UI 결과를 승인했다. UI·접근성·모바일 완료 조건은 닫고 이후 T15 완료 판단에서 다시 열지 않는다.
- 2026-09-04 사용자는 실제 UI/UX 승인 테스트에서 Spec을 revision 2로 수정한 뒤 Builder 화면까지 진입한 흐름을 승인했다. 실행 중 Agent 요청을 둔 채 화면을 이탈·재진입해 progress를 재연결하는 보장은 MVP 범위에서 제외하되, 이미 구현한 exact-slot 중복 방지는 방어 기능으로 유지한다.

**남은 완료 gate**

1. 최종 prompt v1.1.6·Haiku·설치 경로의 대표 성능 실행을 한 번 더 수행해 first Candidate, 단일 refinement와 첫 Spec이 각각 30초 이내인지 확인한다. 통과하면 앞선 사용자 UI/UX·Spec revision 2→Builder 승인과 합쳐 T15를 완료한다. 장기 P95 표본은 T21로 넘긴다.

- 최종 대표 실행 결과 MERGE 13.226초, 첫 Spec 18.860초, Spec 수정 23.097초와 revision 2 저장은 통과했지만 first Candidate가 50.132초로 30초를 넘었다. 따라서 T15를 완료하지 않고, 남은 작업은 first Candidate latency 하나로 한정한다. UI/UX, Spec 수정→Builder와 in-flight 재진입 범위는 다시 열지 않는다.

**First Candidate 대안 spike 순서**

1. `[x]` 현재 Haiku 4개 상세 결과 50.132초를 baseline으로 고정하고, 필수 상세 필드를 유지한 6개 compact와 10개 compact를 같은 target 입력으로 비교한다.
2. `[x]` 설명량 자체의 영향을 보기 위해 4개 ultra-compact를 비교한다.
3. `[x]` prompt v1.1.6의 정확한 schema 지시가 있는 Luna 6개를 다시 시험해 속도와 durable contract 성공 여부를 확인한다.
4. `[x]` 10개 상세 방향의 다른 대안으로 Haiku 5개 생성 두 건을 병렬 실행해 잠재 wall-clock과 두 batch의 성공률을 측정한다. 이는 atomic 10개 Round 구현이 아니라 가능성 spike로만 사용한다.
5. `[x]` latency, 필수 필드 완전성, 후보 수·중복, payload 크기를 비교하고 안정 package를 복원한 뒤 권장안을 결정한다.
6. `[x]` 6개에서 contract와 30초를 모두 통과한 Luna가 사용자가 선호한 10개 상세 후보도 유지할 수 있는지 adaptive follow-up을 수행한다.
7. `[x]` compact 지시만으로 tool envelope가 깨진 실패를 분리하기 위해 첫 Round의 exact top-level submit field를 명시한 Haiku 6개·Luna 6개·Luna 10개를 재시험하고, 승자 후보를 반복 측정한다.
8. `[x]` Luna 10개 exact-envelope가 첫 표본 19.991초에 통과했으므로 두 표본을 추가해 durable 저장 신뢰성과 후보 제목 다양성을 확인한다. 추가 batch에서 no-durable 실패가 재현됐다.
9. `[x]` Luna 10개 추가 반복에서 no-durable 종료가 재발했으므로 각 표본을 독립 기록하고 Luna 6개를 3회 반복해 안정성을 비교했다.
10. `[x]` 현재 6,075자 ROUND prompt에서 최초 생성에 불필요한 refinement·MORE·lineage 설명을 제거한 initial-only Agent를 spike하고, 같은 상세 schema로 Haiku 10개·Luna 10개·Luna 6개의 속도와 tool 신뢰성을 비교했다.
11. `[x]` 단일 Luna 6개가 반복 3회 중 2회만 저장됐으므로 Luna와 Haiku를 동시에 dispatch하고 같은 expected revision에서 먼저 유효한 6개만 Core가 채택하는 hedged request를 1회 spike했다. 두 호출 모두 저장하지 못해 탈락시켰다.
12. `[x]` 동일 지시 Haiku 5×2 병렬은 두 batch가 각각 22.727초·24.561초였지만 주제 4개가 겹쳤다. Personal Need 직접 연결과 독립 탐색으로 나눈 partitioned 5×2도 한 batch가 저장에 실패해 탈락시켰다.

- Haiku 10개 compact는 필수 상세 필드와 10개 고유 제목·핵심 상호작용을 유지하며 33.940초에 저장돼 단일 Haiku 중 가장 가까웠지만 30초를 넘었다. Luna 6개 exact-envelope는 성공 시 14.420~16.063초였으나 4회 중 3회만 저장됐고, Luna 10개도 19.991초 성공 뒤 추가 반복에서 no-durable 실패가 재현됐다. initial-only prompt, Luna+Haiku hedge와 partitioned 병렬도 latency·저장 신뢰성을 동시에 충족하지 못했다.
- 기존 single Round contract에서 후보 수·설명량·prompt·model만 바꾸는 안은 채택하지 않는다. 다음 권장안은 10개의 가벼운 preview를 작은 초기 contract로 먼저 durable 저장하고, 고정된 preview identity를 background에서 상세화하는 방식이다. 두 독립 Agent가 새 후보를 병렬 발명하지 않으므로 중복을 피하고 사용자가 선택한 preview를 우선 상세화할 수 있다. 이는 contract·storage·UI 변경이므로 사용자 승인 전에는 적용하지 않는다.
- 2026-09-04 사용자가 10개 preview→background enrichment 구현과 실패 시 복구 가능한 설계를 승인했다. 구현 전 안정 상태를 `09edb18`로 커밋했으며 기존 Candidate/Round 저장과 atomic Round Agent는 rollback/fallback 경계로 유지한다.

**승인된 preview 구현 순서**

1. `[x]` PROJECT_BRIEF·SPEC·ARCHITECTURE·DECISIONS에 10개 durable preview, fixed identity enrichment, complete 뒤 SELECT, 누락 batch 재시도와 legacy atomic fallback 계약을 반영한다.
2. `[x]` additive SQLite migration과 Preview Round·Enrichment runtime contract/repository를 구현하고 기존 DB backup·migration·rollback 호환성을 검증한다.
3. `[x]` preview와 1~5·6~10 enrichment 전용 MCP tool/Agent를 prompt v1.1.7로 추가하고 legacy ROUND·MERGE·SPEC 경로를 유지한다.
4. `[x]` UI protocol v3에서 preview를 즉시 목록으로 보여주고 상세 loading, checkbox basket, complete 전 SELECT 차단, 누락 batch 재시도와 `기존 방식으로 생성` 복구 action을 구현한다.
5. `[x]` unit·contract·storage integration·prompt fixture/eval·mobile E2E와 전체 `pnpm check`를 통과시킨다.
6. `[x]` data-preserving target update 뒤 unseen 입력으로 preview durable ≤30초, 10개 complete Round 수렴, 실패 구간 재시도와 legacy fallback을 실측한다. v1.1.8 preview 21.635초와 v1.1.9 preview 23.241초가 gate를 통과했고, 두 실행 모두 identity 10개와 Session revision 1→2를 보존한 complete Round로 수렴했다. 기존 UI/UX·Spec revision 2→Builder 사용자 승인과 사용자의 조건부 최종 승인에 따라 T15를 완료한다.
- preview 화면은 10개 lightweight 행을 먼저 표시하고 enrichment 0~10 진행 상태를 보여준다. background 중 checkbox와 basket은 사용할 수 있지만 refinement·SELECT는 final Round 뒤에만 활성화된다. 같은 project의 background refresh는 화면 component를 unmount하지 않아 preview에서 담은 Candidate ID와 스크롤 맥락이 complete Round 전환 뒤에도 유지된다.
- Node.js 24.19.0에서 `better-sqlite3` statement finalizer와 Vitest fork worker 종료가 충돌하는 재현 가능한 cleanup-hook assertion을 확인했다. 격리는 유지하면서 child-process teardown race가 없는 thread pool로 test runner를 고정했고, 단일·병렬 integration 188개가 모두 통과했다.
- 최종 `pnpm check`가 format/lint 148 files, typecheck, Drizzle check, unit 2개, package/app integration 188개, eval 17개, build, smoke 6개와 Chromium E2E 11개를 통과했다. 390x844 E2E는 preview 10개·상세 0/10 상태, background checkbox/basket, complete 전 action 차단, 10개 final Round 전환과 선택 보존을 실제 Core/SQLite 경계에서 검증한다.
- prompt v1.1.8은 preview Agent의 prompt와 출력 길이를 줄이고 두 enrichment batch를 순차 실행해 동시 Agent 중 하나가 durable submit 없이 끝나는 편차를 제거했다. target preview는 21.635초, complete enrichment는 217.934초였고 identity 10개와 revision 1→2를 보존했다.
- prompt v1.1.9는 enrichment context에서 전체 preview 10개와 요청 batch의 중복을 제거하고 상세 배열 수를 제한했다. 최종 target의 unseen synthetic WebRTC 입력에서 preview 10개는 23.241초에 durable 저장돼 30초 gate를 통과했고, FIRST 5개는 107.273초, complete Round는 enrichment 시작 후 148.371초에 저장됐다. v1.1.8보다 background 완료가 약 31.9% 단축됐으며 complete Candidate 10개의 identity가 모두 보존됐다.
- Kiro 공식 short-lived dashboard token과 app-secret exchange로 data-preserving update를 수행했다. 설치 전후 56 project·57 Discovery Session·23 Learning Spec과 SQLite `quick_check=ok`가 유지됐고, 설치된 v1.1.9 Agent와 versioned UI hash가 source package와 일치했다. 최종 synthetic 측정은 project/session을 하나씩 추가했으며 기존 사용자 데이터는 삭제하거나 수정하지 않았다.
- T15의 대표 gate는 앞서 통과한 MERGE 13.226초·첫 Spec 18.860초·Spec 수정 23.097초와 최종 preview 23.241초를 합쳐 모두 30초 이내로 닫는다. preview 이후 checkbox/basket은 바로 사용할 수 있지만 SELECT·refinement는 complete Round까지 최대 관측 148.371초 기다리는 제한이 있으며, 이는 background 수렴 분포와 3~5초 first-useful stretch goal과 함께 T21에서 계속 측정한다.
- 최종 `pnpm check`가 format/lint 149 files, typecheck, Drizzle check, unit 2개, package/app integration 189개, eval 17개, build, smoke 6개와 Chromium E2E 11개를 통과했다.
- 2026-09-05 사용자 최종 검토에서 background enrichment 완료 시 펼쳐 둔 preview 상세가 닫히는 UI 회귀를 확인했다. 펼침 상태를 `DiscoveryWorkspace`의 Candidate ID·revision key로 옮겨 preview→complete 표현 전환 뒤에도 유지했다. 390x844 E2E와 전체 `pnpm check`가 통과했고, versioned UI 0.1.3을 Kiro에 data-preserving update한 뒤 설치 UI hash, SQLite 무결성과 실제 Core read를 확인해 T15를 최종 종료했다.
- 2026-09-05 사용자 재검토에서 background enrichment가 SELECT·refinement까지 막는 것은 제품 의도와 다름을 확인해 T15를 다시 열었다. preview만으로 판단이 끝난 사용자는 참조 후보의 just-in-time enrichment만 거쳐 즉시 진행할 수 있어야 하며, 나머지 상세 보강은 필수 조건이 아니다.
- prompt v1.2.0과 UI protocol v6은 `SELECTED` enrichment로 참조 preview만 보강하고 같은 transaction 경계에서 partial Candidate Round와 user Feedback을 적용한다. Application·MCP·prompt eval과 Chromium E2E는 background 중 선택·refinement, late batch 거절과 1개 후보 Round를 검증했다. 설치본 실제 Haiku 실행은 preview 10개 20.037초, 선택 후보 1개 10.525초, Core 선택 273ms였고 나머지 9개 없이 `SPEC_REVIEW`로 진행했다. app 0.2.2 data-preserving update 전후 기존 59 project·60 Discovery Session·26 Learning Spec·5 Task·2 Completion Report와 SQLite 무결성이 유지됐으며 synthetic 실행 뒤 project/session만 각각 1개 늘었다.
- First Candidate 대안 spike 종료 시점에는 모든 실험 package를 `/private/tmp`에 보존하고 target을 Haiku v1.1.6·Agent 4개로 복원했다. 이후 승인된 preview 구현은 이 stable 기준 위에서만 진행했다.
- 대안 spike 시점의 `pnpm check`는 format/lint 147 files, typecheck, Drizzle check, unit 2개, package/app integration 185개, eval 16개, build, smoke 6개와 Chromium E2E 10개를 통과했다.

첫 유용 반응 3~5초는 stretch goal이라 T15 종료 blocker가 아니다. 느린 Candidate submit의 연결 종료 대응도 target Crew에서 다시 재현될 때만 조건부로 수행한다.

**성능 개선 실행 순서**

1. `[x]` 사용자 원문을 남기지 않는 단계별 latency 계측과 동일 fixture 기반 측정 절차를 추가한다.
2. `[x]` target에서 `auto`, `gpt-5.6-luna`, `claude-haiku-4.5`를 먼저 선별하고 필요할 때 `gpt-5.6-terra`를 비교한다. contract·narrowing·다양성 품질을 통과한 후보만 latency와 credit으로 비교한다.
3. `[x]` 승자 model을 명시적으로 고정하고, App이 이미 복원한 compact Core snapshot을 app-owned Crew slot의 ephemeral context로 주입해 정상 경로의 선행 `get_discovery_context` Agent 왕복을 제거한다. stale·누락·복구 상황에서는 read-only context tool을 fallback으로 유지한다.
4. `[x]` 최초 Candidate, 단일 refinement와 첫 Spec을 target에서 다시 측정하고 각 P95 30초 조건을 판정한다.
5. `[x]` 30초를 넘은 MERGE에 Candidate/Spec phase별 prompt·tool allowlist 분리와 Core가 계산할 수 있는 metadata 축소를 적용한다.
6. `[x]` 당시 5단계 후 세 구간이 모두 30초 gate를 통과해 preview/lazy enrichment 저장 계약은 보류했다. 이후 사용자 재검증의 50.132초 first Candidate outlier로 판단을 다시 열었고, 위 승인된 preview 구현 순서에서 staged 계약과 최종 gate를 완료했다.

**범위**

- 필수 Learning Goal과 선택 Personal Need 입력, 한 열 Candidate list, 관심 후보 basket과 목록 위 자유 대화/refinement action을 구현한다.
- 입력 placeholder에 구체적인 활용 예시를 순환 또는 문맥에 맞게 보여준다.
- 후보별 shrink/expand button은 제거하고 범위 조정 예시를 refinement placeholder에서 안내한다. checkbox는 check mark·outline·설명과 충분한 모바일 touch target으로 상태를 구분한다.
- Final Candidate와 권장 Spec 확인은 부담을 낮추되 되돌리기와 Agent 반복 수정을 가능하게 한다. Spec은 직접 편집 form 대신 사용자 흐름, MVP, 역할 분담과 예상 Decision을 읽기 중심으로 시각화한다.
- SEED Design의 정보 위계와 control state를 참고하되 새 UI dependency는 추가하지 않고 Kiro purple을 app brand token으로 적용한다.
- Candidate 생성 중 진행 상태, 30초 이후 nonblocking background, 안전한 재시도와 host 연결 종료를 이미 저장된 상태와 구분한다. 10개 preview durable latency와 complete enrichment 수렴 시간을 각각 관측한다.

**선행 조건**

- T08~T09 flow와 T14 App shell이 있어야 한다.

**산출물**

- Discovery/Spec UI와 접근 가능한 interaction
- candidate lineage/history view
- 빈 입력, Agent 실패, 후보 부족과 수정 반복 상태
- desktop/mobile visual regression과 keyboard interaction 검증

**완료 조건**

- keyboard만으로 입력, 후보 조정, 확정과 되돌리기가 가능하다.
- desktop과 mobile에서 Candidate가 한 열 목록으로 보이고 checkbox의 checked·unchecked 상태와 선택한 후보 요약이 색상에만 의존하지 않는다.
- Discovery 자유 입력이 Candidate 목록보다 먼저 보이고, Spec은 직접 편집 textbox 없이 읽기 중심 요약과 반복 가능한 Agent 수정 입력을 제공한다.
- `이렇게 확정하기` 같은 권장 기본 action이 사용자에게 시험이나 어려운 사전 판단처럼 보이지 않는다.
- 사용자가 만족할 때까지 refine candidate와 final candidate 사이를 반복할 수 있다.
- Spec→Discovery 복귀는 1초 이내 Agent 호출 없이 이전 후보를 보여주고, 새 후보 생성은 명시적 action 뒤에만 시작한다.
- prompt v1.1.2 starter, v1.1.3 narrowing, v1.1.4 ephemeral context, v1.1.5 phase split, v1.1.6 Spec recovery, v1.1.7 preview/enrichment, v1.1.8 compact preview와 v1.1.9 compact enrichment fixture/eval, stringified transport 복구 contract, MORE carry·selection narrowing lineage, background UI와 Core revision E2E가 통과한다. in-flight 화면 재진입 복원은 MVP gate가 아니다.
- target 환경의 대표 최종 실행 한 번에서 10개 첫 preview, 단일 refinement와 Spec 초안이 각각 30초 이내이고 preview 10개가 complete Round로 수렴하며 사용자가 결과를 승인해야 한다. 첫 유용 반응 3~5초는 stretch goal로 관측하고 model/config별 품질·latency 근거를 함께 남긴다. 장기 P95는 T21에서 검증한다.
- target Crew host에서 느린 모델의 Candidate submit 연결 종료가 재현되면 T08 atomic round invariant를 보존하는 staged draft batch 또는 지원되는 persistent transport 중 하나를 결정 기록으로 승인하고 구현한다.

### [x] T16. Agent 중심 Build·Helper 동시 UI와 Decision UI

**진행 기록**

- 2026-09-05 사용자 Chrome 재검토에서 기존 완료 판정을 철회하고 conversation-first Agent Session 재작업을 승인했다. 실제 Builder/Helper transcript와 persistent composer를 primary surface로 바꾸고, Helper 240자 화면 truncation, raw `[OPTIONS]`/diff marker, completion의 transcript 교체와 stale Project selector route를 함께 수정한다. 실제 credit을 사용하는 target Builder/Helper/Decision/completion 검증도 별도 승인 없이 완료까지 진행하도록 위임받았다.
- app 0.2.1·UI protocol v5에서 desktop split/mobile tab을 실제 structured Crew slot로 전환했다. Builder와 read-only Helper는 각각 독립 session과 persistent composer를 가지며 compact progress, Decision card와 completion result만 transcript 주변에 주입한다. visible prompt에서 Core ID를 제거하고 ephemeral context로 옮겼으며 완료 뒤에도 전체 session을 유지한다.
- 모든 structured message 문자열을 host renderer 전에 redaction하고 legacy internal identifier와 raw stop event를 제거했다. host `ChatMessageList`가 Markdown, tool call, diff와 option을 렌더링하며 `[OPTIONS: ...]` 또는 fenced diff 원문을 app이 별도 paragraph로 출력하지 않는다. Helper는 전체 답변을 session에 보이고 durable event에는 trailing option을 제외한 240자 summary만 저장한다.
- 실제 target Helper가 700자 이상 답변의 마지막 `설명 끝`까지 표시했고, Builder transcript에서 raw option/diff marker가 사라진 대신 native diff control을 확인했다. 두 실제 Decision을 선택·적용했으며 generated WebRTC project의 TypeScript typecheck와 Vitest 4 files·19 tests가 통과했다. `execute_bash`는 generated workspace와 exact allowlist 안에서만 허용되고 pipe 명령은 실제로 거절됐다.
- 장기 Agent turn을 같은 composer에서 중지하는 Builder/Helper control을 추가했다. stop 요청은 exact Vibe Helper slot에만 허용되며 transcript의 transport JSON은 `Agent 실행이 중지되었습니다.`로 정규화된다. Core Completion Report는 target Task revision 3을 `COMPLETED`로 전이했고 task별 report는 정확히 1개, SQLite `quick_check=ok`다.
- Node.js 24.19.0·pnpm 11.12.0 최종 `pnpm check`에서 format/lint 153 files, typecheck, Drizzle check, unit 2개, package/app integration 200개, eval 17개, build, smoke 6개와 Chromium E2E 11개가 모두 통과했다. app 0.2.1을 data-preserving update한 뒤 desktop과 390×844 Builder/Helper tab, 실제 Helper stop을 Chrome에서 검토했으며 설치 package 28개 hash가 source와 전부 일치했다. 기존 58 project·59 Discovery Session·25 Learning Spec과 SQLite 무결성이 유지됐다.
- 2026-09-05 Builder/Helper pane을 viewport 기반 bounded flex layout으로 바꾸고 transcript만 내부 스크롤되게 했다. 긴 native transcript의 `scrollHeight > clientHeight`, pane 760px 이하와 composer 고정을 Chromium E2E로 검증했으며 app 0.2.2 설치 UI/backend hash가 source와 일치했다.
- 2026-09-05 사용자 재검토에서 light mode native chat의 고정 dark 배경, confirmed Spec을 사용자 권한의 상한으로 해석한 Helper 답변, composer보다 큰 Decision/button UI를 확인해 T16을 다시 열었다. Spec을 변경 가능한 초기 합의로 재정의하고 Builder·Helper prompt regression, theme token, composer 위 compact 추천 답장과 pending Decision 자유 입력 Resolution을 함께 수정한다.
- app 0.2.3·UI protocol v7에서 native chat surface를 light/dark theme token으로 통일하고 Builder/Helper transcript의 bounded 내부 스크롤과 composer 고정을 유지했다. pending Decision은 compact context와 composer 바로 위 추천 답장으로 줄였으며, 사용자가 Builder 입력창에 보낸 자연어는 별도 form 없이 `CUSTOM` Resolution과 visible follow-up으로 연결된다. Helper는 `설명 전용`으로 표시하고 추천 질문을 입력창 바로 위에 둔다. legacy Decision 결과의 literal `\\uXXXX`는 durable 원문을 바꾸지 않고 화면에서만 안전하게 복원한다.
- Helper prompt v1.1.0과 Builder prompt v1.2.0은 confirmed Spec을 변경 가능한 초기 합의로 정의한다. `AGENT_SUPPORT`·`EXCLUDED`·현재 focused Decision은 사용자 질문과 학습 범위의 상한이 아니며, 최신 명시적 사용자 요청은 안전 경계 안에서 Spec revision 또는 실제 tradeoff Decision으로 반영된다. PostgreSQL→SQLite 실제 사례와 unseen revision fixture가 모두 통과했다.
- session policy 변경을 Builder v7·Helper v2 slot로 격리하고 모든 이전 revision의 redacted structured history를 current transcript 앞에 병합했다. 최신 실제 project에서 새 Helper에 PostgreSQL→SQLite 질문을 보낸 결과 1회 context read 뒤 41초·0.45 credits에 “바꿀 수 있어”, 두 DB의 project-specific tradeoff, 전환 비용과 Builder 전달 문장까지 끝까지 표시됐으며 Helper 종료 뒤 composer가 다시 활성화됐다. 기존의 잘못된 과거 답변은 provenance를 위해 수정하지 않는다.
- 최종 검증에서 format/lint 153 files, typecheck, Drizzle check, unit 2개, package/app integration 201개, eval 20개, build, smoke 6개와 Chromium E2E 12개가 통과했다. Chrome 실설치본에서 light theme의 밝은 transcript/어두운 글자, pane 내부 스크롤, 추천 답장·질문→composer 순서, legacy Unicode 표시 복원을 확인했다. app 0.2.3 data-preserving update 전후 60 project·61 Discovery Session·26 Learning Spec·5 Task·2 Completion Report와 SQLite `quick_check=ok`가 유지됐고 UI/backend/Builder/Helper hash가 source package와 일치한다.

> 2026-09-05 승인된 capability gate: Crew는 browser App API의
> `POST /api/chat/slots/{slot}/project`로만 기존 slot의 project directory를 바꾸며,
> app backend에는 같은 작업을 위임할 gateway callback credential/endpoint를 제공하지 않는다.
> 사용자가 승인한 대로 Core가 canonicalize한 절대 workspace를 UI memory에 일회성 전달해
> 즉시 binding하고 DOM·URL·log·durable storage에는 남기지 않는다. binding 성공 전에는
> Builder native tool을 활성화하거나 첫 message를 보내지 않는다.

**범위**

- 왼쪽 Builder stream, 오른쪽 Helper를 동시에 보는 Agent 중심 surface를 구현한다.
- Builder의 실제 대화, tool call, file change, test와 error correction을 보여주고 Live Progress를 보조로 둔다.
- Decision card와 Helper handoff, 추천대로 진행과 자유 응답을 자연스럽게 연결한다.

**선행 조건**

- T10~T14 flow가 있어야 한다.

**산출물**

- split layout과 responsive fallback
- stream virtualization 또는 점진 rendering
- Helper quick cards/free input, Decision pending/resolved UI

**완료 조건**

- Builder 작업 중 Helper를 사용해도 두 대화와 Context가 섞이지 않는다.
- 사용자는 실제 Decision에서 판단 책임을 유지하고 Builder 추천과 Helper 설명을 함께 볼 수 있다.
- 완료 화면은 학습 점수보다 실행 가능한 결과물을 먼저 보여준다.

### [x] T17. Evidence Trace와 다음 대화 개인화

**승인 기록**

- 2026-09-06 사용자가 UI-safe Evidence Trace, Core-owned immutable personalization provenance, bounded cross-project Ledger retrieval, Helper/Discovery prompt revision, 비점수형 UI, A/B fixture와 실제 Kiro data-preserving 검증 계획을 승인했다.
- Personalization Trace는 Agent가 Evidence를 실제로 사용했다고 단정하지 않고 해당 turn에 Core가 제공한 근거를 기록한다. 실제 결과 차이는 evidence 있음/없음 A/B 평가로 별도 검증한다.
- 2026-09-06 사용자가 추상적·주관적인 개인화 경계를 여러 상황에서 추가 검증하도록 요청했다. 실제 Kiro 다중 turn과 결정론적 경계 fixture를 함께 확장한다.

**검증 기록**

- UI-safe Project Evidence Trace, additive SQLite `personalization_traces`, 최대 5개 accepted Evidence retrieval, 명시적 no-evidence fallback, Helper v1.2.0과 Discovery v1.3.0, 비점수형 접이식 UI를 구현했다. 일반 session restore는 trace를 만들지 않고 실제 Discovery dispatch 직전 prepare command만 immutable trace를 남긴다.
- 결정론적 A/B fixture는 같은 질문에서 `NO_RELEVANT_EVIDENCE`가 과거 경험을 추측하지 않고 `EVIDENCE_AWARE`가 source Project·Episode·Evidence를 연결하는 차이를 고정했다. 실제 Kiro Helper 두 turn도 각각 34초·0.40 credits와 35초·0.53 credits에 같은 경계를 지켰고 `OBSERVED`를 숙달로 과장하지 않았다.
- 실제 첫 검토에서 같은 Helper conversation의 두 번째 요청 correlation이 Episode scope와 충돌하는 결함과 이미 열린 Evidence 패널의 빈 결과 cache를 발견했다. Episode는 최초 correlation을 유지하고 요청·personalization trace는 turn correlation을 유지하도록 분리했으며, Helper 기록 뒤와 패널 재개방 때 read model을 갱신한다. 4-event 연속 대화 integration regression을 추가했다.
- 추가 실제 Kiro stress turn 5개에서 무관한 경험 비추측, 단일 근거, 서로 다른 출처의 복수 근거, 약한 비유 경계와 `TRANSFERRED` 과장 거절을 확인했다. 모두 기대한 Core mode/basis와 일치했고 한 Helper Episode가 revision 10·event 10으로 이어졌으며 Project Evidence UI와 SQLite `quick_check=ok`를 확인했다. target 데이터에 없는 `DEMONSTRATED`+open issue와 최대 5개 경계는 fixture·prompt/contract 회귀로 보강했다. 최신 native turn이 다음 turn 전까지 두 번 보이는 Kiro native-session 렌더링 현상은 Core 기록 중복이 아닌 별도 표시 이슈로 남겼다.
- 추가 회귀 후 Node.js 24.19.0·pnpm 11.12.0에서 format, lint, typecheck, migration, unit 2, package/app integration 203, prompt eval 21, build와 smoke 6을 통과했다. sandbox 안 Chromium은 macOS Mach port 권한 때문에 test 시작 전에 종료됐고 같은 E2E를 허용된 브라우저 환경에서 재실행해 12/12 통과했다.
- target Kiro Crew 설치본을 app 0.3.2로 data-preserving update했다. source/설치 UI·backend·Discovery·Helper hash가 일치하고 `/health`가 `ok`, SQLite `quick_check=ok`이며 update 전후 Project 61, Discovery Session 62, Learning Spec 27, Task 6, accepted Evidence 13, Concept Ledger 13, Completion Report 2가 보존됐다. 초기 pre-fix restore probe가 만든 correlation 불일치 Discovery Trace 1개는 immutable 기록이라 삭제하지 않고 UI query에서 제외했으며 이후 restore로 수가 증가하지 않음을 확인했다.
- Node.js 24.19.0과 pnpm 11.12.0에서 format, lint, typecheck, migration check, unit, package/app integration, prompt eval, build, smoke와 Chromium E2E를 검증했다. standalone `pnpm test:eval:live-helper`는 Kiro CLI 2.21.1의 ACP `new_session` 종료로 Agent 호출 전에 두 번 실패했으며 mock 성공으로 대체하지 않았다. 실제 제품 경로 A/B는 target Crew에서 별도로 성공했다.

**범위**

- Concept별 current state, 근거가 된 Episode, 보류·거절 이유와 open misconception을 조회 가능하게 한다.
- Helper의 설명 출발점과 연결, 다음 Discovery ranking에 Ledger를 제한적으로 반영한다.
- State나 confidence를 과도한 성적표처럼 전면 노출하지 않는다.

**선행 조건**

- T13 Evidence flow와 T15~T16 UI가 있어야 한다.

**산출물**

- Evidence Trace UI/query
- Helper/Discovery personalization adapter
- personalization provenance와 no-evidence fallback

**완료 조건**

- AC-MVP-010이 통과하며 어떤 과거 Evidence가 결과에 영향을 줬는지 추적 가능하다.
- Discovery에서 흥미·실용성이 Ledger보다 우선한다.
- 동일 사용자라도 근거가 없을 때 state를 추측하거나 자신감 퍼센트를 만들어내지 않는다.

### [x] T18. Campus Drop TypeScript Golden Path

**승인 기록**

- 2026-09-06 사용자가 T17 변경을 별도 커밋한 뒤 T18 계획 전체를 승인했다. 제품 경로에는 hidden no-tool Evidence Analyst worker, loopback-only 실제 결과 실행, 사용자가 선택하는 optional `FINAL_UPGRADE`를 연결한다.

**범위**

- Campus Drop을 end-to-end 회귀 fixture로 구현해 Discovery부터 실제 실행까지 연결한다.
- 현재 단계에 부적합한 인프라 복잡성은 AGENT_SUPPORT 또는 EXCLUDED로 두고 TypeScript 학습 범위를 지킨다.
- 최소 하나의 실제 Decision, Helper 질문, Evidence proposal과 다음 개인화를 포함한다.

**선행 조건**

- T08~T17의 수직 흐름이 연결되어야 한다.

**산출물**

- 재현 가능한 Campus Drop seed/session
- 생성 결과물의 build/run/test script
- 예상 state가 아닌 허용 Evidence 범위를 정의한 E2E fixture

**완료 조건**

- AC-MVP-004, 006, 011이 한 session에서 통과한다.
- 결과물을 실제로 실행하거나 열 수 있고 Builder 완료 보고와 test 결과가 일치한다.
- fixture 전용 hard-coded 후보, 답변 또는 Evidence가 없다.

**검증 기록**

- Campus Drop fixture가 Discovery 후보·세 범위의 Learning Spec·1회 consume 대 재사용 Decision·Helper 대화·사용자 설명·Builder 완료·Evidence-aware Helper·사용자가 쓴 개선 목표·sequence 2 Final Upgrade를 한 browser session에서 통과했다. 최종 Evidence는 Builder 코드·test에 `OBSERVED`, 사용자 자기 설명에 최대 `EXPLAINED`를 허용하고 같은 흐름에서 `TRANSFERRED`를 금지한다. 제품 reducer와 prompt에는 Campus Drop 전용 분기가 없다.
- `tests/campus-drop-generated`는 strict TypeScript로 SQLite metadata와 blob file을 분리하고 SHA-256 token digest, TTL, atomic consume-once를 구현한다. build 뒤 실제 loopback HTTP process를 띄워 upload, 1회 download, 재사용 `410`, 잘못된 base64를 검증했다. 제품 결과 실행기는 strict manifest, compiled relative JavaScript, containment·symlink 검사, 최소 환경, 동적 loopback port, health/open path 분리, process reuse·종료를 integration test에서 실제 child process로 검증했다.
- Node.js 24.19.0·pnpm 11.12.0에서 format/lint/typecheck/Drizzle check, unit 2개, integration 212개, eval 22개, Campus Drop 3개, build, smoke 6개와 Chromium E2E 12개가 통과했다.
- target Kiro Crew 설치본을 data-preserving update endpoint로 app 0.4.1에 갱신했다. 설치 UI·backend·Builder·hidden no-tool Evidence Analyst hash가 source package와 일치하고 backend `/health`가 `ok`이며 실제 History UI가 기존 Project를 복원했다. 첫 target worker 검증에서 실제 Agent가 설명 뒤 single fenced JSON을 반환해 whole-message parser가 legacy 대기 Job 6개를 최대 재시도 뒤 거절하는 회귀를 발견했다. parser를 정확히 하나의 fenced JSON block만 허용하고 복수 block은 거절하도록 고친 versioned 0.4.1 UI에서 같은 no-evidence 형태의 실제 Job 2개가 13.8초·17.8초에 `SUCCEEDED`가 됐다. SQLite `quick_check=ok`이고 Project 61, Discovery Session 62, Learning Spec 27, Task 6, accepted Evidence 13, Concept Ledger 13, Completion Report 2가 유지됐으며, 실패·성공 Job revision도 provenance 때문에 삭제하지 않았다. 새 Campus Drop Agent run은 추가 durable fixture data를 만들지 않고 deterministic full E2E와 실제 result runtime integration으로 대체했다.

### [~] T19. 자체 Kiro IDE 패널과 프론트 실제 연동

#### [x] T19-F19. 완료 뒤 지속적인 Builder·Helper 대화와 도구 거부 표시 수정

- **승인:** 2026-09-30 사용자가 권한 오류 표시와 MVP 완료 뒤 대화 차단 수정을 요청하고 새 VSIX·Kiro 재시작 적용·버전 갱신·저장소 push를 승인했다.
- **선행 조건:** T19-F17/F18의 0.0.17 코드·배포본과 실제 완료 화면, 최신 양쪽 main.
- **산출물:** 완료 후 반복 후속 Task/Core 계약과 입력 허용, 명확한 도구 거부 표시, 새 kit·VSIX·다운로드 링크와 설치 결과.
- **완료 조건:** contract/domain/storage/runtime/frontend/실제 소비 검증, 전체 check, 기존 완료·프로젝트·Evidence 보존, 패키지 hash, Kiro 종료·업데이트·재시작 화면 확인과 GitHub 게시.
- **로컬 결과:** Core 전체 check·CJS 171·프론트 57파일/807테스트·실제 HTTP/SSE/SQLite 연결과 연속 Builder 3회/Helper 3회 PASS. kit 2026.09.30.1·VSIX 0.0.18 생성, 설치 파일 hash와 Kiro 정상 재시작 후 두 입력/전송 활성 확인. core `8ce42db`, program `a61d408`로 기존 main에 push했고 원격 SHA 일치와 GitHub VSIX 재다운로드 hash·가이드 링크를 확인했다. 작업 중 추가된 upstream Hello Vibe README·소개 영상 변경도 보존했다. [검증 기록](CONTINUOUS_BUILDER_20260930.md).

#### [x] T19-F18. Windows 0.0.17 VSIX 게시와 다운로드 가이드 연결

- **승인:** 2026-09-30 사용자가 이 환경에서 만든 VSIX를 저장소에 추가해 GitHub에 올리고 최신 다운로드 가이드에 링크하도록 요청했다.
- **선행 조건:** 0.0.17 VSIX와 SHA-256 검증 receipt, 최신 `origin/main`의 다운로드 가이드.
- **산출물:** `releases/windows/0.0.17/`의 동일 VSIX·receipt, Windows 설치 안내, README와 다운로드 가이드 링크.
- **완료 조건:** 기존 로컬 변경 보존, VSIX 원본/게시본 hash 일치, 문서 링크·패키지 검사, 정상 commit/push와 원격 다운로드 확인.
- **승인 이력:** 최신 main pull, VSIX 원본/게시 후보 SHA-256·71개 패키지 항목과 문서 상대 링크 40개 검증 PASS. 게시 대상 5개 파일만 staging했다. 최초 자동 승인 검토가 AGENTS.md의 게시 계정 방식 선택 미확인을 이유로 commit/push를 차단하여 현재 로그인된 `@HURDOO`로 기존 `Hello-KU-tty/core/main`에 게시할지 사용자 확인을 요청했다.
- **재개 승인:** 2026-09-30 사용자가 위 `@HURDOO` 계정·기존 `Hello-KU-tty/core/main` 게시 확인에 “푸시하셈”으로 승인했다.
- **결과:** `0e4f881`을 `core/main`에 push했다. 원격 main 일치와 GitHub에서 다시 받은 VSIX의 SHA-256 `b4634b3ef9c899a7295b5317b25293ad002545bb09126fe64f0afa8c5344bcd3`, 원격 다운로드 가이드·README의 링크를 확인했다. 기존 Core·프론트 소스 수정은 보존했다.

#### [x] T19-F17. 재시작 후 생성 앱 도구 재사용과 Helper 중복 요약 제거

- **승인:** 2026-09-29 사용자가 Node/PATH 변경 시 재발 방지와 도우미 답변 요약 개선 또는 제거를 요청했다.
- **선행 조건:** T19-F16 설치본과 kit 2026.09.29.3. 기존 프로젝트 descriptor·launcher와 실제 실패 원인을 확인했다.
- **산출물:** 기록된 Node/pnpm 재검증·우선 재사용, 변조/누락 실패 안내, 실제 답변을 유지하는 중복 요약 표시 제거, 새 kit와 VSIX.
- **완료 조건:** PATH 유무·다른 후보·재시작·확장 업그레이드·변조/누락 회귀, Helper 실제 응답 보존 UI 회귀, 전체 check와 frontend 검증, packaged 도구 재현 및 파일 hash 확인. 실제 모델·다른 PC 검증과 구분한다.
- **결과:** Core `pnpm check`·확장 CJS 169·프론트 57파일/800테스트·타입·build·실제 HTTP/SSE/SQLite 소비 PASS. 배포 runtime의 기존/관리 도구 모두 개발 PATH 없는 새 프로세스에서 재사용·frozen install·build·test·HTTP 실행 PASS. kit 2026.09.29.4의 118개 관리 파일과 0.0.17 VSIX 71개 파일 hash 확인. 설치 후 native 모델 실행·다른 PC는 미검증이며 commit/push하지 않았다. [검증과 설치본](FRONTEND_TOOLCHAIN_REUSE_20260929.md).

#### [x] T19-F16. 명시적 결정 선택과 Builder 계속 실행 연결

- **근거:** 사용자가 결정을 저장했지만 다음 작업이 실행되지 않는 실제 UX를 보고했다. 기존 resolve-only 동작과 별도 resume 버튼이 분리되어 있다.
- **범위:** 선택 버튼을 명시적 ‘정하고 계속하기’ 동작으로 연결한다. resolve-only 계약, History/Helper의 자동 실행 금지, 동일 Project/Task·저장 성공·미해결 결정 없음·중복 시작 방지를 유지한다. 현재 저장된 선택은 별도 재제출 없이 명시적으로 재개한다.
- **완료 조건:** 성공1회/실패0/중복/화면전환/여러 결정/실행 중 회귀, 최신 frontend 전체 검사·실제 Core 소비·현재 Builder 재개 관찰과 인계.
- **결과:** 최신 frontend 인계와 kit3을 보존한0.0.16, 타입·57파일/794테스트·build·실제 Core 소비 PASS. 기존 선택의 native 재개와 적용을 확인했으며 이후 budget timeout은 별도로 기록했다. program `e1cffdd`로 push했고 새 확장 CLI 설치를 확인했다. [상세 검증과 제한](FRONTEND_DECISION_CONTINUE_FIX_20260929.md). 앱 완성·전체 수직 흐름 판정은 아니다.

#### [~] T19-F15. 채팅 스트림 표시와 Helper 창 준비 상태 복구

- **근거:** 사용자 실측에서 TEXT 조각마다 문단이 생기고 Markdown이 그대로 보인다. Helper RECORDED 뒤에도 로컬 worker의 HELPER_WINDOW_OPENING이 남는다.
- **범위:** 기존 Core-redacted 스트림을 연속된 대화로 표시하고 안전한 서식을 적용한다. Helper 실행 이벤트·종료 기준으로 준비 표시를 해제한다. Windows 별도 H 권한 격리는 유지하며 한 창 제약과 남은 UX 한계를 기록한다.
- **완료 조건:** 조각·Markdown·HTML 안전성·스크롤·별도 host 진행/종료 회귀, frontend 검사, 설치 후 실제 화면 확인. 사용자 데이터와 모델 실행을 보존한다.
- **즉시 인계:** 사용자 요청으로 프론트 개발자가 바로 착수할 수 있게 원격 기존 변경을 병합해0.0.14 `950f83f`를 program/main에 push했다. 최종780 tests/typecheck/build PASS. 0.0.13 설치는 확인했으며 실제 새 화면 검증은 남아 있어 이 항목은 진행 중이다. [현재 인계](FRONTEND_CHAT_FIX_20260929.md).

#### [x] T19-F14. 명시적 스펙 시작과 Builder 최초 실행 연결

- **근거:** 사용자 실측에서 `이걸로 시작` 후 CONFIRMED Spec/PENDING Task만 저장되고 Builder run은0이다. 화면에는 학습 목표를 작업 제목으로, 이전 DISCOVERY 종료를 현재 작업 상태처럼 표시한다.
- **범위:** 명시적 스펙 시작 버튼이 준비 완료된 같은 Project/Task의 Builder를 한 번 실행하도록 연결한다. History/재시작/Decision 해결에는 자동 실행을 추가하지 않는다. 이미 준비된 작업은 명시적 시작으로 재개 가능하게 하고 프로젝트 제목·대기/탐색 종료 안내를 정확히 표시한다.
- **완료 조건:** 실제 provider/Core 소비에서 준비→시작1회 및 실패·중복·화면전환·복원0 회귀, frontend 전체 검사, 설치·기존 PENDING 작업의 실제 시작 확인. 생성 workspace/권한/완료 gate를 유지한다.
- **검증:**0.0.12 설치, frontend767/typecheck/build와 실제 Core 소비 PASS. 업데이트 전후 저장hash 동일·복원 새run0. 실제 버튼1회→Builder RUNNING→native 작업 시작 성공, 기존 Task ACTIVE/revision2 확인. [수정·설치·실측 범위](FRONTEND_BUILDER_START_FIX_20260929.md). 앱 완성·후속 Decision과 전체 수직 흐름은 별도다.

#### [x] T19-F13. 새 Discovery 라운드의 저장된 후보 상세 표시 복구

- **근거:** 사용자 실측에서 MERGE는 SUCCEEDED, 새 후보 상세도 Core에 저장되어 있지만 화면은 후보 ID/로딩 안내에 머문다. feedback 성공 콜백이 round 참조만 반영하고 candidate 상세를 갱신하지 않는다.
- **범위:** 피드백 성공 뒤 이미 저장된 라운드/상세를 모델 재실행 없이 화면에 반영한다. 입력·바구니·현재 Project와 늦은 응답 경계를 유지한다. 실제 사용자 데이터·prompt·Core 저장 계약은 변경하지 않는다.
- **완료 조건:** 합치기/새 방향 등 후속 라운드의 상세 표시와 실패/화면 전환 회귀, frontend 전체 검사, 실제 Core 소비 검증, 새 VSIX로 기존 저장 후보 복원 확인. 모델 재호출로 우회하지 않는다.
- **검증:**0.0.11 설치·기존 후보 복원, frontend758/typecheck/build, 실제 Core HTTP/SSE/SQLite→renderer의 MERGE/REGENERATE 표시와 추가 enrichment0 PASS. 재시작 전후 저장hash 동일·새 모델run0. [원인·수정·설치 파일](FRONTEND_FEEDBACK_DISPLAY_FIX_20260929.md).

#### [x] T19-F12. 실측 예정 인계·승인된 commit/push와 직접 사용 환경 준비

- **승인:** 2026-09-29 사용자가 이쪽에서 프론트 실측 예정 문구 추가, commit/push, 제출 후보 확장 제작·Kiro 실행·설치·Workspace Trust와 직접 사용 준비를 요청했다. push는 `hurdoo` 계정으로 기존 `Hello-KU-tty/core`, `Hello-KU-tty/program`에 수행한다.
- **권한 대기 해소:** F15 즉시 인계에서 HURDOO의 program push 권한을 API로 확인하고 원격 변경을 보존한0.0.14 `950f83f`를 main에 push·원격 SHA 대조했다. 아래 권한 대기 기록은 이전 시점이다. 설치/Trust/직접 사용 준비는 F12 및 후속 F14 실측으로 확인했고, 전체 제품 실측은 F11/F15에 남긴다.
- **산출물:** 양쪽 인계/검증 변경 commit, 원격 HEAD 확인, 현재 VSIX와 hash, 실제 설치물의 Core 연결·Trust·로그인·화면 준비 기록.
- **완료 조건:** 사용자용 Kiro 창이 현재 확장으로 실제 Core에 연결되고 직접 입력 가능한 상태다. 모델 실측은 최신 사용량/Overages를 확인하고 기존 누적900·신규중단880 제한 안에서 별도로 판정한다. 사람의 사용을 합성 fixture로 완료 처리하지 않는다.
- **준비·실측 완료:**0.0.10 재빌드/118관리hash/VSIX 설치, 전용 workspace Trust, 실제 PREVIEW1회/10후보/32.812초, 정상 재시작·History 복원/저장hash불변/새run0. 사용량835.96→836.18/2000, Overages Disabled. 사용자용 빈 입력 화면을 열어 두었다. [실측 기록](FRONTEND_LIVE_READY_20260929.md).
- **외부 대기:** core `bc8570b` push 완료. program `deef685` commit 완료, HURDOO의 해당 repository `permissions.push=false`로 Write 권한 요청 중이다. 권한 부여 전 program push를 재시도하지 않는다.

#### [x] T19-F9. 최신 프론트 인계의 제출 전 업그레이드·kit 회귀

- **착수 근거:** 2026-09-29 사용자 요청과 프론트 `82f55ff`의 `NEXT_STEPS_20260929.md`. backend `8265e9d`는 `e3532b7`을 이미 포함한다.
- **범위:** 기존/관리 pnpm의 공유 shim·프로젝트 descriptor·launcher 업그레이드 경계, 직전 적용 kit hash를 기준으로 한 재현 가능한 kit 생성, 실제 frontend 적용·검사·VSIX 후보 준비. Node24.19.0/pnpm11.13.1과 기존 데이터·UI를 보존한다.
- **완료 조건:** 변경 경계의 실패/복구 회귀, backend `pnpm check`, frontend typecheck/test/build, kit hash 검증과 VSIX 후보 receipt. 실제 Kiro 실측·사람 pilot·baseline·외부 제출은 독립 gate이며 자동 검사로 완료 처리하지 않는다.
- **다음 판단:** Discovery 복귀 요구 불일치와 durable 실패/abandon 요청을 현재 계약과 대조한다. 데이터 삭제·권한 확대·공개/commit/push는 이 작업에 포함하지 않는다.
- **검증:** Node24.19.0/pnpm11.13.1 전체 check(unit178+skip1/integration391+skip1/eval42/Campus3/smoke6/E2E12), CJS169 PASS. kit2026.09.29.2 실제 program 적용/118 hashes/753 tests/typecheck/build 및 0.0.10 VSIX 조립·Kiro CLI 설치 확인. 현재 profile에 이전0.0.9가 없어 설치 성공을 업그레이드 실측으로 확대하지 않는다. [최신 제출 대조](SUBMISSION_READINESS_20260929.md).

#### [x] T19-F10. Spec에서 이전 후보로 읽기 전용 복귀

- **근거:** 최신 프론트 인계와 BRIEF §8/FR-DIS-013. 현재 돌아가기 버튼이 새 Session을 만들고 Spec을 SUPERSEDED로 바꿔 기존 후보를 지운다.
- **범위:** 돌아가기는 저장된 후보·입력·현재 Spec을 보존하는 화면 이동으로 만든다. 기존 선택의 Spec은 모델 호출 없이 다시 열며, 명시적 새 후보 요청 때만 기존 `UI_RETURN_TO_DISCOVERY`를 호출한다. 선택 완료 Session을 재개하거나 새 Core API를 만들지 않는다.
- **완료 조건:** 돌아가기·Spec 재열기에서 mutation/모델 0, 명시적 재생성에서 현재 Project의 새 Session과 1회 실행, 실패·중복 클릭·History 전환 회귀 및 실제 frontend 검사. 기존 디자인을 유지한다.
- **검증:** frontend753개·타입·build PASS. 실제 provider/controller→인증 HTTP/SSE→SQLite 소비에서 저장 상태 불변/모델0 복귀·Spec 재열기와 명시적 새 Session/preview1회를 확인했다. 실패 시 이전 후보/Spec 유지, 입력 변경 전달, 중복 요청과 화면 이탈 후 늦은 응답 회귀 PASS. 현재 선택 완료 후보는 읽기 전용이며 다른 후보 재생성은 명시적 입력을 사용한다.

#### [-] T19-F11. 0.0.10 실제 Kiro Agent·기존 프로젝트 업그레이드 실측

- **외부 조건:** 기존0.0.9 프로젝트 업그레이드 표본과 사용자의 Builder/Helper 이후 직접 실측을 기다린다. T19-F12에서 최신 usage/Overages·로그인·제품 workspace Trust, PREVIEW1회와 재시작 History는 확인했지만 전체 gate를 완료하지 않았다. 누적900/신규880 제한을 유지한다.
- **준비 완료:** 0.0.10 VSIX 생성·설치, kit/프론트/Core 자동 검증과 native 회귀. B6 다중 창·B7 Helper catalog·B11 한국어·기존/신규 Builder·결과 실행·History/개인화·fallback 녹화는 실제 실행 receipt로 판정한다.

**2026-09-28 제출 준비 재개:** 사용자가 실제 프론트 checkout의 직접 기능·성능 수정과 Mac 연결 검증을 승인했다. Windows 전용 작업은 이번 실행에서 제외하며 아래 T19-F1부터 진행한다. 앞선 시간·프론트 수정 금지 기록은 당시 세션에 한정한다. 기존 상위 완료 gate는 검증 없이 닫지 않는다.

#### [x] T19-F8. 프론트 B7~B11 런타임·도구·언어 보완

- **승인/선행 조건:** 2026-09-29 사용자 검토 후 작업 승인. B10의 개발 pin 변경, 기존 collaborator 경로의 commit/push와 프론트 답변 갱신을 포함한다. 기존 사용자 실험 파일·Kiro 창·데이터는 보존한다.
- **범위:** 설치 가능한 pnpm 11.x exact pin/무결성과 개발·생성 앱 계약 동기화; B7 bridge 초기화 단계 진단과 실패 후 새 session 경계; B8 shell 입력/lockfile 거절 원인과 검증 미실행 보고; B9 안전한 표시용 tool 분류/파일 없음 코드; B11 사용자 언어와 내부 규칙 인용 방지 prompt·fixture.
- **산출물/완료 조건:** 경계별 회귀, frozen install, 전체 check 및 panel/client build, frontend 답변과 commit/push. 모델 없는 검증과 실제 Kiro/Windows 검증을 구분한다. MCP catalog·permission gate를 완화하거나 사용자 창을 자동 종료하지 않는다. 재현되지 않은 Kiro 내부 원인은 해결로 단정하지 않는다.
- **검증:** Node24.19.0/pnpm11.13.1 frozen install, 공식 archive891 files·실제 acquisition/offline 재사용·무스크립트 lock 생성 PASS. 전체 check의 E2E 이전 단계(unit171+skip3/integration375+skip8/eval42/Campus3/smoke6) PASS. sandbox Chromium 거절 뒤 허용된 실행 환경·4273 포트의 E2E12 PASS. panel/client build와 CJS/bridge169+skip2 PASS. 모델0. [프론트 답변과 잔여 실측 조건](FRONTEND_B7_B11_RESPONSE_20260929.md). B7의 Kiro 내부 원인/Windows 실제 재발과 B11 모델 언어 품질은 미확정이며 상위 T19 gate를 닫지 않는다.

#### [x] T19-F7. 같은 생성 폴더의 다중 Kiro 창 라우팅 복구

- **승인/선행 조건:** 2026-09-29 사용자 B6 보완·검증·commit 요청. 최신 backend `d02ef61`과 프론트 보고 `031ae154`를 대조했고 같은 폴더의 서로 다른 endpoint 두 개가 `NATIVE_ENDPOINT_AMBIGUOUS`로 거절됨을 재현했다.
- **범위:** 확장 host가 제공한 현재 창 identity와 canonical workspace를 함께 검증해 endpoint를 선택한다. 폴더 전환 전 기존 대상 창을 확인하며, 식별 불가·모순·중복은 명확한 코드로 거절한다. 기존 run 오류 전파와 명시적 PREVIEW 재시도를 유지한다.
- **산출물/완료 조건:** source/capability 근거, 창 선택·라우팅·worker→Core 오류 회귀, `pnpm check`와 panel build, B6 프론트 인계 문서 및 검증 후 commit. 모델 호출·다른 사용자 창 조작 없이 검증한다. Windows 실제 두 창/새 kit 검증과 B3 durable 실패 History는 별도 잔여 조건이며 이번 완료로 대체하지 않는다.
- **검증:** Node 24.19.0/pnpm 11.12.0의 전체 check 중 E2E 이전 단계(unit156+skip3/integration365+skip8/eval41/Campus3/smoke6) PASS. 기존 서버의 4173 포트 충돌과 sandbox Chromium 실행 권한 문제는 환경 원인으로 분리했고 사용자 서버를 보존한 4273 포트/허용된 브라우저 실행에서 E2E12 PASS. panel build와 CJS167+skip2, 새 번들의 저장소 밖 activation/라우팅5 PASS. [B6 답변·source 근거·Windows 후속](FRONTEND_LIVE_TEST_RESPONSE_20260929.md). 새 모델 호출0이며 상위T19/T19-N·Windows 출하 gate는 유지한다.

#### [x] T19-F1. 실제 프론트 PREVIEW 재시도와 실패 복구 안내

- **선행 조건:** 백엔드 `5af5eb0`, frontend `0858811`, 양쪽 인계/명세 확인 및 사용자 직접 수정 승인.
- **산출물:** 같은 Project/Session의 명시적 PREVIEW 재시도, durable 결과/active run 우선 복구, 중복 클릭·응답 유실·재로드·취소 회귀, 안전한 quota/auth/access/model/rate/service/Trust/update 안내.
- **완료 조건:** frontend adapter/controller 회귀와 실제 Core HTTP/SSE/SQLite consumer 검사, frontend typecheck/test/build 통과. History 조회만으로 모델 호출 0, native 실패를 성공으로 표시하지 않음, 새 key는 명시적 새 시도에만 발급.
- **후속:** 실제 UI 및 Mac native 연결, 제출 준비 검증표·실행 자료. Windows 검사와 durable 실패 History/삭제 API는 이 작업에 포함하지 않는다.
- **검증:** 기존 frontend 540 tests PASS; 실패 재현 6건 후 561 tests·typecheck·build PASS. 실제 frontend controller/port + 인증 HTTP/SSE + SQLite consumer PASS(모델 0). 원래 실패 run 캐시, 동시 재시도, 같은 Project/Session 유지와 안전한 quota 안내를 재검증했다. 결과 기록은 진행 중이며 실제 native 모델 성공과 구분한다.

#### [x] T19-F2. 실제 프론트 단계 연결·재시작 복원과 Mac 화면 검증

- **근거:** 실제 wiring은 새 Discovery Project ID를 Builder의 `bhlr.lastProjectId`에 전달하지 않으며, 기존 integration test는 ID를 미리 seed한다. History 행도 조회 결과를 화면에 적용하지 않아 이어서 보기 동작을 검증하지 못했다.
- **범위:** 기존 화면/버튼을 유지하고 durable Core snapshot으로 Discovery·Spec·Build 상태를 복원한다. 새 Agent 호출은 명시적 사용자 action에만 허용한다. 실제 provider wiring과 신규·재로드·프로젝트 전환·실패 회귀를 추가한다.
- **Mac:** exact Mac source gate를 유지한 개발 검증용 실행부에 동일 frontend 소스/웹뷰를 연결한다. Windows portable·VSIX 지원을 변경하지 않는다.
- **모델 예산:** 사용자가 이번 세션에도 계정 누적 900 상한을 승인했다. 신규 호출 중단선 880과 15분 이내 usage 재확인을 유지한다. 자동 overage·계정 변경은 하지 않는다.
- **완료 조건:** ID를 seed하지 않은 Discovery→Spec→Builder/Helper wiring, 저장 복원 시 새 Agent 0, 실제 화면 확인 및 가능하면 새 native 수직 흐름 근거. 불가능한 구간은 구체적인 호환성/외부 조건으로 보고한다.
- **재개 승인:** 2026-09-28 사용자가 현재 backend `kiro-native-recovery` 폴더만의 Workspace Trust 승인을 명시하고 계속 진행하도록 요청했다. 상위 `.local-experiments` 신뢰, 계정/overage 변경은 승인 범위가 아니다. 이후 필요한 사용자 승인은 알림이 가는 입력 요청으로 받는다.
- **현재 검증:** frontend712 tests/typecheck/build, actual provider+HTTP/SSE+SQLite consumer, backend 전체 check/E2E12 PASS. 진행 중 Discovery 복원12건·Spec 미준비 버튼3건·Helper 분석 상태4건에 이어 Decision/native 초안4건·완료/Decision 복원5건·결과/폴더 버튼2건·업그레이드 연결2건을 보완했다. 실제 Mac에서 새 PREVIEW/JIT/SPEC→Decision 선택→기본 Task COMPLETED→Chrome 결과 실행→Evidence-aware Helper(basis5)→sequence2 Task COMPLETED→Chrome의 브라우저 실행까지 연결했다. 후속 앱의 fresh 복사본 frozen install/typecheck/build/17 tests/smoke PASS. 원래 서버 실행 불일치를 후속 목표로 교정했으며 Helper의 동률 순서 설명 오류는 한계로 보존한다. 전체 backendcheck는 unit137+3SKIP/integration330+8SKIP/eval41/Campus3/smoke6/E2E12 PASS다. [현재 작업 기록](FRONTEND_MAC_PROGRESS_20260928.md).
- **완료 판정 17:38:** 실제 frontend의 저장 복원·명시적 선택·동시 Helper·Evidence→다음 개인화·결과 실행을 합성 입력/native receipt/Chrome으로 확인했다. 사용자 이해 근거는0이며 Agent 코드·설명·클릭을 이해로 올리지 않았다. 구서버 재사용 결함2개를 재현하고 bounded compiled-content 검사8 tests로 보완했으며, idle 검증 Core만 재시작해 최신 앱을 다시 실행했다. F2 범위 완료이며 Windows/general-install/상위T19-N·사람 pilot·최종 제출 완료는 아니다. 모든 MVP surface/data path의 이 검증 경로가 연결됐으므로 다음은 T20 감사다.
- **실화면 후속:** 해결된 Decision 선택 버튼 차단, stream hydrate 입력 DOM 보존, 완료 상태 복원, 기존 명령의 누락된 결과/폴더 버튼 연결과 Final Upgrade 참조/새 Task 갱신을 기존 F2 범위에서 보완했다. 디자인·탐색 구조·Decision 권한·모델 자동 호출 정책은 유지한다.
- **16:19 환경 문제 및 재개:** Mac IDE 셸은 Node26.4.0을 사용하고 생성 앱의 pnpm이 상위 backend workspace14개를 탐색했다. 생성 앱 자체 lock/node_modules가 없어 독립 앱 검사로 인정하지 않는다. active Run0/Task BLOCKED(실제 Decision 대기)는 보존했다. 별도 프로필·재로그인이 필수라는 근거는 없어 처음 제안을 철회하고, 사용자가 기존 프로필 유지·최소 환경 수정을 승인했다. 저장소 밖의 검증 전용 Core와 생성 폴더에 한정한 Node24 터미널 설정을 모델0으로 먼저 검증한다. 새 폴더 Trust는 정확한 경로로 별도 확인한다. 기본 native 경로의 상위 package 설정 상속은7건 FAIL 후 실행 전에 거절하도록 보강했고 Windows launcher는 바꾸지 않았다. 상위 gate와 T20 이후는 아직 완료하지 않는다.

#### [x] T19-F3. 프론트 메시지 입력 경계 검증과 제출 준비 대조

- **선행 조건:** F1 완료, 실제 frontend 소비 경로와 F2 모델0 검사. native/Trust 승인은 이 정적·회귀 작업의 선행 조건이 아니다.
- **근거:** flow message parser는 type만 확인하고 payload를 그대로 controller로 전달한다. 누락·잘못된 타입·과대 입력이 예외나 불필요한 요청을 만드는지 검사해야 한다.
- **범위:** 현행 input/ref/message 계약과 UI를 유지하면서 malformed payload를 실패 차단한다. read-only History와 정상 입력은 보존한다. 공식 대회 공개 요건과 실제 검증 근거를 대조하되 별도 제출 형식·참가자 결과를 가정하지 않는다.
- **산출물·완료 조건:** 실패 재현·경계/회귀 검사, 실제 provider에서 잘못된 메시지의 Core 호출0, frontend typecheck/test/build 및 actual consumer PASS; 확인 가능한 제출 요건과 외부 확인 필요 항목을 분리한 문서. T20/T21/최종 제출 완료로 대체하지 않는다.
- **검증:** parser32건과 혼합 protocol wiring1건의 FAIL 재현 후 수정. 배열 빈 슬롯/상한을 포함한 frontend52files/622tests·typecheck·build PASS, actual consumer에서 malformed10종의 Core 요청0과 정상 메시지/History PASS. Mac 개발 번들도 재빌드했다(모델0). [제출 준비 대조](SUBMISSION_READINESS_20260928.md)에 공식 공개 요건과 아직 필요한 참가자 안내·native·pilot·baseline 근거를 구분했다.

#### [x] T19-F4. 프로젝트 전환 중 남은 Agent 동작 경합

- **선행 조건:** F2의 프로젝트 바인딩/History 복원과 F3 입력 경계 완료. native 실행 승인은 모델0 race 검사의 선행 조건이 아니다.
- **근거:** Builder/Helper stream은 바인딩 버전을 검사하지만 Decision/native 답변, workspace/result 열기, Evidence/Final Upgrade에는 await 이후 같은 검사가 없다. History 전환 뒤 이전 응답이 새 화면을 덮거나 이전 workspace를 열 수 있다.
- **범위:** 기존 명시적 action의 바인딩만 유지하며 전환/폐기 뒤 늦은 콜백·후속 요청을 무효화한다. 이미 Core에 수락된 요청은 자동 취소/재실행하지 않는다. UI 디자인·프로토콜·도메인 정책은 바꾸지 않는다.
- **완료 조건:** 지연된 읽기/명령 응답의 회귀를 FAIL로 재현 후 수정, 정상 Decision/Helper/Evidence/Final Upgrade 회귀 유지, frontend 전체 검사와 actual consumer PASS. 상위 제출 gate를 대체하지 않는다.
- **검증:** 전환/원래 Project 복귀/폐기 race24건과 이전 Evidence·초안 잔존1건 FAIL 재현 후 수정. 후속 await 단계·폐기 후 무동작·dispatcher 마지막 전송 검사까지 포함해 frontend52files/656tests·typecheck·build PASS. 실제 인증 HTTP Evidence 응답을 지연시킨 상태에서 History를 전환해 옛 응답을 보내지 않음을 actual consumer로 확인했다. 최신 Mac 번들 reload·한글 초안/History/Trust 차단 재확인, 모델0. F2 native는 Trust 승인 대기다.

#### [x] T19-F5. Mac 개발 검증 실행부의 모델 요청 예산 회귀

- **선행 조건:** F1/F3/F4 모델0 검사. 유료 native/Trust 승인은 이 독립 회귀의 선행 조건이 아니다.
- **근거:** 새 개발 host의 credit guard는 startDiscovery/startRun만 감싸며 UI_RETRY_ANALYSIS는 직접 execute된다. 관측당2회 제한도 host별 Promise queue와 log 읽기/append여서 서로 다른 host가 겹칠 때 원자성이 증명되지 않았다. 아직 이 경로의 전용 테스트가 없다.
- **범위:** 개발 harness에만 적용한다. fresh observation·누적900/중단880·overage 금지 조건과 read-only 허용을 유지하며, 명시적 Analysis 재시도와 중복 host admission 경계를 회귀로 검증한다. 자동 후속 Analyst를 포함한 실제 사용량은 운영자가 별도 관찰해야 하며 billing hard cap으로 주장하지 않는다. 제품 quota/프롬프트/DB/지원 버전은 변경하지 않는다.
- **완료 조건:** 누락/오염/오래됨/미승인/한도 초과 관측·동시/재로드·실패 후 재시도의 fail-closed 검사, 가짜 모델 dispatch0 및 정상 read-only 검사, 개발 번들 빌드·기존 consumer PASS. 실제 승인 파일 생성이나 모델 호출은 하지 않는다.
- **검증:** 분석 재시도 무관측 통과와 동시6host의6회 허용을 FAIL로 재현한 뒤 수정했다. 실제 개발 entry와 fake Core/native 경계·별도 Node6프로세스의34검사 PASS, frontend657·typecheck·build, actual consumer PASS. 최신 전체 backendcheck는 unit130+3SKIP/integration325+8SKIP/eval41/Campus3/smoke6/E2E12, 별도 native161+2SKIP PASS. 소유 개발 stage의 승인 관측/허용 기록0, Project0/active run0; 최신 번들 실제 제한 모드 reload와 usage815.91 갱신 확인. 실제 모델0.
- **다음 외부 조건:** F2 재개에는 해당 backend 폴더만의 Workspace Trust 명시적 승인이 필요하다. 자동 Goal 계속 신호나 크레딧900 승인으로 Trust 승인을 대신하지 않는다. 별도 제출 양식·pilot/baseline 사람 근거도 아직 제공/검증되지 않았다. 후속 task 선행 조건을 건너뛰거나 이 작업으로 최종 제출 완료를 선언하지 않는다.

#### [x] T19-F6. 분석 재시도 화면 갱신과 입력 검증 피드백

- **선행 조건:** F3~F5 완료, 현행 Core/프론트 계약 유지. native 모델/Trust 없이 회귀 가능한 기능 수정이다.
- **근거:** retryAnalysis는 새 Evidence view를 읽고 버리며 dispatcher는 갱신 view를 보내지 않는다. 선택 입력은4000자 상한을 UI에서 안내하지 않아 F3의 엄격한 parser에서 조용히 거절될 수 있다. 합치기 UI/validator도 Core의 targets 최대8개를 반영하지 않는다.
- **범위:** 기존 Evidence 영역을 성공한 명시적 retry 뒤 갱신하고 F4 stale-binding 보호를 유지한다. 기존 입력 오류 안내와 composer 안내에 현행 계약 상한을 반영해 요청 전 설명하고 초안을 보존한다. 화면/탐색·도메인 상한·Evidence 판정·자동 모델 실행 정책은 바꾸지 않는다.
- **완료 조건:** stale view/과대 입력을 FAIL로 재현 후 수정, 정상 경계값과 오류 후 재입력·중복 요청·프로젝트 전환 회귀, frontend 전체 검사 및 actual consumer PASS. 실제 native와 제출 완료는 별도다.
- **검증:** 프론트13건과 실제 버튼→Core의 revision0 거절을 FAIL로 재현했다. 버튼의 sentinel0은 기존 UI_READ_ANALYSIS_JOBS로 현재 실패 job revision을 조회해 해결하며, 성공한 retry의 새 Evidence view를 dispatcher가 보낸다. 동일 job의 중복 클릭은 한 mutation이고 실패·read 오류 후 자동 retry는 없다. frontend54files/680tests·typecheck·build PASS, 실제 bootstrap/client/renderer(메모리 DOM)→인증 HTTP→SQLite consumer에서 실패→WAITING·재시도 버튼 제거 PASS. 최신 전체 backendcheck(E2E12 포함)도 PASS. Mac 실제 화면에서4001자 안내·History 후 초안 유지·4000자 교정 시 안내 제거를 확인했다. 디자인·프롬프트·Evidence 정책·Windows kit 변경과 유료 모델 호출은 없다.
- **당시 대기 및 갱신:** F6 완료 당시 F2는 Trust 답변을 기다렸다. 이후 정확한 폴더 승인을 받아 위 F2 native 흐름과 복원을 검증했다. 과거 대기를 현재 차단 사유로 재사용하지 않는다. Windows 및 참가자 검증은 여전히 별도이며 임의 완료하지 않는다.

**2026-09-28 08:50 사용자 연장:** 마감은 같은 날 **10:00 KST**로 변경했다. 최신 프론트 main0858811의 실측 인계 B2(Core 설치 경로 재사용)·B1(RPC 오류 사유) 등을 백엔드에서 수정·검증하는 데 우선 집중한다. [대조 기록](spikes/T19_FRONTEND_LATE_LIVE_TRIAGE_20260928.md). 계정누적900 상한과 프론트수정/commit/push/배포 금지, 공유Core/사용자창 보존은 유지한다. 아래08:43 종료는 1차 Mac 성능작업 기록이며 현재T19/Goal은 계속진행중이다.

**09:20 후속:** B2는 설치/runtime identity 비교·불일치 lease 갱신 금지·45초 정상 owner 종료 대기·명시적 재시도 검증으로 수정했다. B1은 bounded structured 오류의 고정 코드 분류·worker/run 전파를 구현했다.09:08 시작 fullcheck unit128/integration325/eval41/E2E12 PASS이며 이후 lifecycle 재시도 guard3개·worker 오류7개·Trust1개와 실제 program 오류4종/같은 Project 명시적 retry 검증을 추가했다. B3 frontend의 옛 run 캐시 갱신 필요, durable 실패/abandon 미구현, B5 Windows 프로세스/정책 영향 미확정은 [항목별 인계](spikes/T19_FRONTEND_LATE_LIVE_TRIAGE_20260928.md)에 구분한다. Windows 신규 실측/새 kit/상위T19 완료는 아니다. 추가 모델0.

**09:43 최종 수정 고정:** 느린lease중첩/종료경합2개FAIL재현 뒤 maintenance직렬화·종료전drain·stop뒤갱신금지를보강했다. lifecycle17회귀PASS, 최신fullcheckunit130+3skip/integration325+8skip/eval41/Campus3/smoke6/E2E12, 별도CJS161+2skip/panelbuild/actualprogramconsumer PASS. 메모리안portablehost/runtimebundle2회귀와실패즉시Coregrant회수도포함한다. 최종1,000Concept의restore/Evidence/lifecycle재측정은전체응답·상태동등/기존성능개선유지·모델0이었다. [프론트 답변](FRONTEND_LIVE_TEST_RESPONSE_20260928.md)에오류표시/Core업데이트대기/명시적retry/100runretention/Windows남은평가를정리했다.

**09:50경 사용자 승인 종료:** Mac 개선·프론트 인계 수정과 최종 검증을 마쳐 예정10:00까지 추가보고를 기다리지 않고 마무리한다.09:50:11 종료감사는 소유Core정지·SQLite50테이블불변·무결성PASS였다. 연장구간모델0, 데이터/임시파일보존, commit/push/새VSIX없음. Windows 재평가 및 상위T19/T19-N은 미완료로 유지한다.

**2026-09-28 08:43 Mac 개선 인계 완료:** 최종 `pnpm check` unit123+3SKIP/integration323+8SKIP/eval41/Campus3/smoke6/E2E12, panel123+2SKIP, 별도34검사, panel build와 actualprogram consumer PASS. 실제 Core15분·9,374조회는 전체 응답/50테이블 불변·새 run0·무결성 PASS. 최종 누적 계정815.91(08:33 관측),07:27 이후 모델0. 승인 실험 개발 창과 소유 Core만 유휴 정상 종료했고 DB/원본을 보존했다. [최종 인계](spikes/T19_MAC_PERFORMANCE_HANDOFF_20260928.md)·[정제 근거](spikes/T19_MAC_PERFORMANCE_RECEIPTS_20260928.json)에 한정 성능 개선, 기각 실험, 남은 의미 품질/생성 앱 결함, Windows 재평가 절차를 남겼다. 미커밋·push/프론트 수정/배포 없음. **이번 시간 제한 Mac 작업의 종료이며 T19/T19-N과 제출 전 Windows gate는 완료 처리하지 않는다.**

**07:49 lifecycle 채택/인계 초안:** Analysis 상태전환5곳의 미사용 Ledger/proposal 읽기를 제거했다. 두 독립DB의 정상/실패/idempotent 응답과 전체테이블 매회동등성, 반복측정, 대상46검사·actualprogram소비·전체check(integration321+8SKIP/E2E12)·실제16Project/77view Core재시작전후동등성 PASS. 1000개이력의retry6.834→0.286ms 등 Core계산비용을 줄였고 Analystcontext/증거판정/FinalUpgrade정책은 그대로다. 실제 native취소직후재요청도07:27새runner PASS이며 원본FAIL기록을 보존한다. [Windows 제출 전 인계](spikes/T19_MAC_PERFORMANCE_HANDOFF_20260928.md)에 채택/기각·재현명령·남은품질/Windows gate를 정리했다. 미커밋이며 commit/push/새kit배포는 하지 않았다.09:00까지후속검토중,T19/T19-N미완료유지.

**2026-09-28 성능 개선 착수:** 사용자가 현재 맥에서 Goal 기반 반복 개선을 09:00 KST까지 진행하도록 승인했다. 프론트 `main`의 실제 소비 흐름과 계약을 기준으로 baseline → 작은 변경 → 반복 측정/회귀 → Windows 재평가 인계를 수행한다. 진행 중 T19의 후속 범위이며 T20/T21/T27을 완료 또는 선행 조건 충족으로 바꾸지 않는다. 크레딧·마감·실험별 판정은 [실험 기록](spikes/T19_MAC_PERFORMANCE_20260928.md)에 남긴다.

**07:15 Analyst 한정 판정:** source-first 동일8개에서원본3/8→후보1.0.8의6/8두회,별도두코퍼스는5/8·4/8동률이다. 출력schema준수개선만채택하고지연/일반의미품질/사용자학습향상으로표시하지않는다. 인용·DIRECTLY_LED상승은기존Core가거절하지만미래계획APPLICATION같은의미오류는수락될수있음을offline순수정책대조로확인했다. 원문·전체실패·동일inputSHA·최대8회평가기록을보존한다. 최종전체회귀·인계정리와Windows실측은별도이며T19/T19-N은계속진행중이다.

**06:41 중간 검증:** Evidence 조회의 요청내중복·단일Concept전체이력읽기·미사용Ledger hydration을 제거했다. 독립SQLite 전체응답동등성/반복·대상22검사·actualprogram Evidence projector·전체check(integration319+8SKIP/E2E12) PASS. 실제16Project/77filtered view가 새Core 전후 동일했다. 1000이력 단일Concept128.435→1.514ms, 개념별Episode100개 전체116.076→16.012ms 관측으로 채택한다. actualnative 취소/즉시재요청도 owned terminal뒤실행을 확인하고 원본계측FAIL/후속감사를 구분했다. Analyst후보판정·최종인계·Windows실측은 아직남아 있으며 상위T19는진행중이다.

**05:30 중간 검증:** Helper 대화 복원에서 사용하지 않는 Evidence/Ledger hydration을 제거했다. 실제 SQLite 응답 전체 동등성·반복 측정, 전체 `pnpm check`와 actual program HTTP/SSE 소비 검증 PASS. 1,000 Concept/20대화의 delivered 복원 중앙값148.543→9.683ms 관측이며 Windows/모델 응답속도 증명은 아니다. 프롬프트 퇴행 후보는 archive/복귀했고 Goal·상위 T19는 계속 진행 중이다.

**05:58 중간 검증:** Helper context의 closed Episode 요약도 별도 history reader로 바꾸고 응답전체동등성·반복측정·전체check(integration316)/actualprogram소비 PASS로 유지한다. 1,000Concept/20Helper대화 계산146.714→7.548ms, 재구성반복134.061→7.342ms. Helper1.2.1 후보는 의미 품질 근거 부족으로 archive하고1.2.0복귀; 기본버전의 제한도 보존한다. 실제 Windows 평가·최종채택표·Analyst후보판정은 남아 있다.

**2026-09-27 프론트 후속 요청 반영:** 프론트의 적용 결과·요청서(`program` `main` `048bce3`)를 검토했다. 이전 기준 `73d0eb5`는 프론트 main의 merge commit이며 clean checkout gate는 READY였다. main clean clone은 typecheck·228 tests·build를 통과하지만 `portable/node_modules/` 28개 미추적과 CRLF 때문에 VSIX 조립이 실패함을 확인했다. Final Upgrade가 기록된 Helper 답변의 trace만 허용하도록 Core를 고치고, Builder/Helper/Decision/Evidence/Final Upgrade/worker 상태의 SDK helper와 host 타입을 추가했다. UI를 patch하지 않는 update kit `frontend-handoff-20260927`(추적 규칙 포함)을 만들고 새 clone 검증·VSIX 조립·consumer·HTTP 계약 test·`pnpm check`·CJS 110을 통과했다. [답변·계약](FRONTEND_HANDOFF_20260927.md), [검증 기록](spikes/T19_FRONTEND_HANDOFF_UPDATE_20260927.json). 이번 변경 뒤 모델 native 재실측과 다른 기기 검증은 하지 않았으며 Builder/Helper 제품 화면 연결과 T19/T19-N 전체 완료는 별도다.

**2026-09-26 구현 착수:** 사용자 지시로 계획 이후 실제 인계 kit 구현에 착수한다. UI 독립 host·SDK·portable 자산과 검토된 `program` 적용 패치를 제공하고 현재 Windows 환경에서 소비·Core·확장 회귀를 검증한다. 다른 기기·외부 환경 검증은 이번 인계 범위에서 제외하며 전체 T19의 의미 품질 완료로 대체하지 않는다.

**2026-09-26 현재 PC 연결 구현:** UI 독립 host와 program 11개 파일 패치를 구현했다. 실제 frontend TS/CJS build·228 tests, 실제 Core 소비 검사, 설치된 frontend VSIX의 native 4회(후보 10개→JIT/선택→Spec 1/수정 2→확정/Task READY→History 무재실행), host CJS 110개와 backend 회귀/Edge E2E 12개를 통과했다. [적용 가이드](FRONTEND_WINDOWS_QUICKSTART.md), [인계 결과](FRONTEND_HANDOFF_RESULTS_20260926.md). 사용자 요청에 따라 같은 Windows branch에 소스와 적용 ZIP·receipt를 전달하며 경로는 `releases/frontend-handoff/20260926/`다. 성능·Analyst 품질은 병행 backlog이며 Builder/Helper 등 후속 화면 연결과 T19/T19-N 전체 완료는 별도다.

**2026-09-26 인계 계획 당시 기록:** 사용자 요청으로 [프론트 인계 계획·요청서 답변](FRONTEND_HANDOFF_PLAN_20260926.md)을 작성했다. W5 완료로 과거 Windows 환경 대기 사유는 해소됐다. 당시 다음 범위로 선정한 host 연결부 분리·SDK/설치물 고정·소비/최소 IDE 연결은 위 현재 PC 구현 결과로 갱신한다. 성능·Analyst 의미 품질·개인화 효과 개선은 frontend 연결과 병행하되 상위 완료 조건은 유지한다. 아래 macOS-only 대기 기록은 과거 근거로 보존한다.

**승인 기록**

- 2026-09-07 사용자가 자체 IDE 패널을 개발하는 프론트 담당자와 협업하도록 기존 내장 Agent 선택기 중심 범위를 수정하는 데 동의했다. mock으로 개발 중인 Discovery·Spec의 실제 연결 준비도 포함한다.
- 최초 범위 검토는 계획 갱신이었으며 아래 상세 승인 이후 실제 구현·실측에 착수했다.
- 상세 인계 기준: [FRONTEND_INTEGRATION.md](FRONTEND_INTEGRATION.md). 기존 T01의 자체 extension/Webview 제외 결정은 2026-09-07 결정으로 대체한다.
- 2026-09-07 사용자가 push된 backend를 frontend 개발자가 자신의 컴퓨터에서 실행해 실제 Kiro IDE의 Discovery·Spec·Builder·History 화면을 모두 구현할 수 있어야 한다고 완료 기준을 명확히 했다. [구체적인 구현 계획](T19_IMPLEMENTATION_PLAN.md)은 아래 기록처럼 push 제외 승인됐다.
- 이후 사용자가 상세 계획에서 push를 제외하고 승인하고 착수를 지시했다. T19를 진행 중으로 전환한다. frontend 대상 OS는 Windows이며 native 설치·PowerShell·경로·process lifecycle과 실제 Kiro IDE 검증을 인계 기준으로 둔다. 현재 macOS의 실측을 Windows 검증으로 대체하지 않는다. push는 실행 전 별도 승인을 받는다.

**진행 기록**

- 2026-09-07 local backend, bounded workflow/Analyst worker, ACP identity/role/run scope, HTTP/SSE 인증, 외부 ESM/CJS SDK/Program adapter와 최소 IDE 예제를 구현했다. 실제 no-Personal-Need 및 Personal-Need 입력의 preview→JIT→refinement→Spec 수정/확정→Task/History를 확인했다.
- 실제 Builder Decision→Helper read-only→사용자 선택→완료, 별도 폴더의 생성 코드 frozen install/build/test와 loopback 결과를 확인했다. 먼저 실패한 Builder 1.3.0의 허위 검증 보고는 보존하고 1.3.1 prompt/fixture에 실행 증거·guard recovery를 추가했다. 정상 Analyst job과 명시적 invalid-result 실패를 각각 확인했다.
- 외부 npm/TS 5.4.5/CJS/esbuild 0.21.5 SDK 소비·실제 Core 조회와 macOS Kiro 1.0.337 extension-host 활성화·패널 명령·네 화면 데이터 접근을 확인했다. host test만으로 시각적 클릭 검증을 주장하지 않는다. 새 별도 source checkout의 frozen install/build/SQLite init/doctor를 통과했다.
- Windows OS 버전/architecture·CLI 2.21.1/v2 native 제공 여부·ACL/native dependency·실제 Kiro 네 화면/중지/재시작 gate는 미검증이다. Windows 증거 없이 [x]로 바꾸지 않는다. 최신 검증과 알려진 실패는 [capability 기록](spikes/T19_LOCAL_RUNTIME_RESULTS.md), 실제 실행 방법은 [프론트 개발 안내](FRONTEND_INTEGRATION.md)를 따른다. push는 여전히 별도 승인 대상이다.
- 로컬 구현 commit `5ce2632`를 새로 clone해 frozen install/build/SDK·panel packaging/SQLite init/doctor live/backend 시작/외부 consumer 실제 조회와 `pnpm check` 전체를 다시 통과했다. 현재 접근 가능한 실행 환경은 macOS뿐이므로 Windows 버전/CLI 제공 여부와 실제 테스트 환경을 확인할 때까지 `[-]`로 대기한다. 검증용 backend는 정상 종료했고 합성 data는 보존했다. T20에 임의 착수하거나 T19를 완료로 표시하지 않는다.

**범위**

- 프론트 담당자의 [program](https://github.com/Hello-KU-tty/program) IDE 확장/Webview에 Discovery·Spec·Builder(Helper 포함)·History를 실제 Core와 Kiro Agent로 연결할 계약·client·runtime adapter와 실행 안내를 제공한다.
- UI 상태 조회·사용자 command와 모델 실행을 분리하고, 현재 Crew UI의 Discovery phase 진행·재시도·durable 결과 관찰을 재사용 가능한 연결부로 정리한다.
- 새 Learning Goal→10개 preview→background/JIT enrichment→후보 refinement·명시적 SELECT→Spec 생성·수정·확정→Core 발급 workspace·Task→Builder/Helper·실제 Decision 적용을 하나의 project lineage로 연결한다.
- Crew App과 동일한 Project, Discovery Session, Spec, Task, Context, Decision과 Ledger를 사용한다. IDE의 현재 폴더를 임의 기존 project로 import하지 않는다.
- History는 기존 Project 목록·권장 진입 단계·현재/완료 Task와 snapshot을 제공한다. backend 재시작 뒤 Discovery·Spec·Build·완료 단계의 저장 결과를 복원하고, History 조회만으로 Agent를 실행하지 않는다.
- Builder checkpoint와 Helper exchange를 기존 Event/Episode·AnalysisJob·개인화에 연결하고 Analyst worker의 실행 소유자와 수명을 정한다.
- Agent 중심과 Code 중심을 숙련 단계가 아닌 사용자 취향으로 표현한다.
- 설치 시점의 Kiro engine·Agent identity·model·역할별 MCP·stream·중지·process lifecycle을 다시 검증한다. CLI 2 config를 다른 engine의 기본 Agent로 묵시적으로 fallback시키지 않는다.
- mock과 실제 연결은 같은 계약을 사용하되 모드를 명시한다. `/api/test/agent`를 제품 runtime API로 열거나 실제 실패를 mock 성공으로 바꾸지 않는다.

**선행 조건**

- T14~T18 공통 Core와 Crew flow가 동작하고 위 범위 변경이 승인돼 있어야 한다.
- T01은 기존 capability 근거로만 사용한다. 자체 패널 transport 선택은 아래 첫 단계의 새 spike 결과로 결정한다.

**구현·인계 순서**

1. 공통 DTO와 mock 교체 경계, frontend/backend 역할을 정하고 local Core·실제 Kiro transport의 최소 spike를 수행한다. Agent 실행과 Core 상태 반영이 각각 가능한지 확인한 뒤 endpoint/IPC·인증·version·process·worker 소유자를 결정 기록에 남긴다.
2. 프론트가 먼저 사용할 versioned 요청·응답·오류 계약과 schema-valid 개발 fixture를 인계한다. loading·부분 완료·실패·stale revision도 fixture에 포함하며 이 단계는 실제 연결 완료가 아니다.
3. Discovery·Spec부터 실제 연결한다. preview identity 유지, background 중 선택·조정, 누락 enrichment 재시도, Spec 수정·뒤로가기·명시적 확정과 Builder Task 준비를 검증한다.
4. 같은 Project/Task에 Builder·Helper session을 각각 묶고 실제 stream·Context·Decision·중지·권한·Event/Episode/Analyst 연결을 검증한다.
5. 실제 Kiro IDE의 최소 연동 예제에서 새 입력부터 History 재진입까지 한 흐름을 재현하고, Crew와 IDE 재진입의 저장 상태 일치·중복 적용 거절·오류 복구를 확인한다. 독립 소비 프로젝트의 SDK 설치와 push할 revision의 clean checkout 실행을 검증하고, frontend 제품 화면에서 같은 연결부를 사용할 안내를 인계한다.

**산출물**

- versioned 프론트 요청·응답·오류/진행 계약, mock fixture와 실제 adapter 교체 예제
- canonical prompt에서 파생한 host별 Discovery·Builder·Helper config, 역할별 MCP·Core client와 실제 runtime 연결부
- local Core/Agent 실행·종료·인증·endpoint 전달·workspace 연결·지원 버전과 frontend repository 소비 방법을 담은 개발 안내
- 외부 repository에 설치 가능한 client package, 네 화면의 기능을 검증하는 최소 실제 IDE 연동 예제, 새 컴퓨터/clean checkout 기준 설치·실행·History 복원 기록
- Discovery·Spec부터 Builder/Helper까지 contract·integration·IDE 연결 검증 기록, Crew 회귀와 same-state continuity test
- Analyst worker 실행 경계, 미구현 mode parity와 후속 UI polish·packaging 목록

**완료 조건**

- 갱신한 AC-MVP-012가 실제 Kiro IDE의 최소 연동 예제와 Core 저장 결과로 통과한다. push된 backend와 지침만으로 frontend 개발자가 자신의 로컬 환경에서 Discovery·Spec·Builder·History 화면을 실제 연결로 구현할 수 있다. backend 인계 완료는 frontend 제품 화면의 최종 디자인 완료와 구분한다.
- 새 Learning Goal과 Personal Need 유무를 검증하고, 10개 preview identity·refinement lineage·선택·Spec 초안/수정 revision·명시적 확정·Core workspace/Task 생성이 이어진다. Spec 뒤로가기의 Agent 호출은 0회다.
- partial enrichment 실패·선택 이후 늦은 제출·Spec no-tool 응답·protocol/revision mismatch·Agent 연결 종료에서 기존 결과를 보존하고 중복 없이 복구한다. Agent turn 종료만으로 Candidate/Spec/Task 저장 성공을 표시하지 않는다.
- Builder·Helper가 실제로 다른 Agent 권한과 session을 사용하고 같은 Task/Context/Decision을 읽는다. Helper write/shell·Decision 확정, Builder workspace 밖 작업은 실행 경계에서 거절되며 stream은 저장·표시 전 redaction된다.
- 같은 Decision을 Crew와 IDE에서 중복 해결·적용하지 않는다. Core 재진입 시 저장된 Session·Spec·Task·Context·Ledger가 일치하고 raw chat session이나 실행 중 stream 재연결은 완료 요건으로 추가하지 않는다.
- History의 빈 목록·진행 중·완료 Project와 backend 재시작 뒤 동일 Project/revision·권장 화면 복원을 검증한다. 이전 설치의 dist·DB·secret·개인 절대 경로 없이 새 checkout에서 설치·실행·SDK 소비와 실제 대상 OS의 Kiro IDE 연동이 재현돼야 한다.
- IDE Helper exchange와 Builder checkpoint의 provenance가 보존되고, 종료 Episode의 Analyst job이 실제 worker에서 처리되거나 명시적 실패·재시도 상태로 보인다. 정상 job 처리도 실제 실행으로 검증한다.
- Code 중심 사용자를 상위 단계, Agent 중심 사용자를 초보 단계로 표시하지 않는다.
- 변경에 맞는 contract·integration·Agent eval·IDE smoke와 `pnpm check`를 통과하고 지원 버전·알려진 제한을 기록한다. 화면 mock이나 기본 Agent fallback만 통과하면 완료 처리하지 않는다.

### [~] T19-N. Kiro IDE 내장 Agent와 Core의 선택적 실험 연결

**승인·범위**

- 2026-09-12 사용자가 별도 worktree에서 실제 구현과 합성 Core 수직 흐름 검증을 승인했다. T19는 Windows 외부 gate로 `[-]`를 유지하고, 이 실험은 CLI/Crew 기본 경로를 교체하거나 출시 완료로 간주하지 않는다.
- 같은 날 사용자가 Discovery부터 다음 개인화까지 native 전체 수직 흐름을 별도 합성 DB/workspace에서 실제 Core receipt로 검증하도록 추가 승인했다. 사람의 선택·발언은 출처가 명시된 합성 UI 입력으로 대체하고 fixture seed·Agent 실행·Core 수락을 구분한다.
- IDE trust/custom Agent/역할별 MCP attach를 먼저 실측한다. 내장 Agent 호출은 설치 버전과 private command capability로 격리하고 공개 API라고 주장하지 않는다.
- 기존 ApplicationService·SQLite·role-bound MCP로 Builder Task/Decision과 Helper Context를 연결한다. 결정적 사용자 command, Episode·Analyst·다음 개인화는 각 실제 상태와 provenance로 검증한다.
- stream/end/cancel이 부족하면 조용한 모의 성공 대신 명시적 미지원·복구 경로를 제공한다.

**선행 조건**

- T19 local Core/client와 검증한 Kiro IDE 1.0.337/1.0.437이 있어야 한다. 기존 사용자 데이터가 아닌 별도 합성 DB와 생성 workspace만 사용한다.

**산출물·완료 조건**

- version/capability-gated native adapter, 역할·MCP 권한 테스트, 별도 합성 Core/IDE 검증 기록과 재현 방법.
- 실제 내장 Builder의 파일·Core Decision side effect와 별도 Helper 및 Analyst 가능한 범위가 durable Core revision으로 확인돼야 한다. 미검증 capability와 장애를 분리 기록하고 변경 범위 test 및 `pnpm check`를 실행한다.

**2026-09-12 중간 산출물과 남은 gate**

- 설치 IDE 1.0.337 / Kiro extension 1.0.653의 private, version-pinned local observer IPC로 별도 합성 custom Agent의 정확한 mode 선택, 무도구 prompt text chunk, `end_turn`, 취소 후 `cancelled` 종료를 실측했다. Adapter는 원시 chunk를 외부에 내보내지 않고 turn 종료 후 redaction된 텍스트를 전달한다(`textDelivery=AFTER_TURN`); UI live stream parity는 아직 없다.
- CLI 검사를 하지 않는 `core-only` backend, disk SQLite의 합성 Task seed, Task·correlation에 묶인 기존 Core MCP handler와 canonical Builder/Helper IDE config 생성 경로를 구현했다. 실제 Core MCP contract test는 Task read, 다른 scope 거절과 revoke를 확인했다. 기본 CLI handler의 늦은 등록 map도 보존했다.
- 후속 설치 IDE 1.0.437 / extension 1.0.794에서 초기 `configureMCP=Disabled`·`getCanEnableMCP=false`여도 전용 workspace MCP config의 서버가 실제 시작해 `initialize`·`tools/list`를 받았고, 별도 exact-mode 합성 stdio Agent는 `tools/call`과 handler 실행까지 확인했다. 이전 자체 `mcpReady` 선차단은 실제 MCP 실패가 아닌 오판이므로 제거했다. 새 extension에는 옛 custom Agent 목록 명령이 없지만 ACP mode option·선택 응답이 역할을 증명했다.
- 실제 Task-bound HTTP Core는 MCP `server/discover`에 2026-07-28/tools capability를 응답한 뒤 Kiro에서 `tools/list`·`tools/call`이 없었고 Core `executeAgent` receipt도 0이었다. 이 직접 연결의 미해결 상태는 [초기 실측](spikes/T19_NATIVE_IDE_EXPERIMENT.md)에 남긴다. 기존 T19와 CLI/Crew 경로는 유지한다.
- **후속 실측:** backend 단독 Core 소유권을 유지하는 fixed-target stdio MCP→기존 run-bound HTTP handler bridge에서 native `get_builder_task`/`get_discovery_context`/제출/Decision 도구의 실제 Core receipt가 성공했다. 새 Discovery lineage에서 Candidate·Spec→Core-issued Task→native Builder start와 guided 파일·Decision 적용까지 확인했다. 별도 fixture-seeded lineage에서 read-only Helper·UI 원문 Episode→native Analyst SUCCEEDED·accepted Evidence→새 correlation의 Evidence-aware Helper 답변을 확인했다. 두 lineage를 합친 단일 native 완주, native 초기 `TASK_STARTED` Context, Browser 결과 생성·test/build/`complete_task`, live stream, Windows는 아직 **미검증**이다. [단계별 결과와 재현](spikes/T19_NATIVE_FULL_FLOW_RESULTS.md)을 따른다.
- 2026-09-13 사용자 요청으로 기존 자체 패널 `/api/runs`에 Kiro IDE extension-host relay를 격리 구현했다. role-bound binding·exact-workspace claim·cancel/Core 보존은 integration으로 통과했지만 첫 fresh Discovery PREVIEW는 전용 IDE worker 미접속 300초 후 명시 실패했다. 단일 native lineage의 10 preview/JIT→Spec→Builder 완료·result health→Evidence/다음 개인화는 아직 검증 중이며 T19-N을 완료로 바꾸지 않는다.
- 같은 새 Core lineage의 이후 native Preview 10·선택 JIT 1·Spec 제출/확정·Task 발급과 제품 패널 History→native Builder `get_builder_task`/`start_task`를 실측해 Task ACTIVE rev2가 보존됐다. Kiro private observer의 일반 permission 응답은 설치 mux가 버리는 사실을 발견해 전용 `_kiro/permission/respond` ACK 경로로 고쳤고 Builder 디렉터리 search 완료를 재현했다. `update_build_context`는 아직 실패해 Context 없음; 첫 원인 추정을 결과로 세지 않고 다음 turn에서 safe field/code bridge receipt를 수집한다. Builder UI Stop의 native cancel은 확인됐지만 Builder 중 Helper를 별도 claim한 turn은 240초 뒤 cancel 미확인으로 실패했다. write/shell·Decision·complete/result·Evidence/후속 개인화와 실제 병행 Helper 응답은 계속 미검증이다. [현재 단일 계보 결과](spikes/T19_NATIVE_FULL_FLOW_RESULTS.md)를 따른다.
- 2026-09-13 같은 단일 합성 Project의 추가 native 실측에서 선택한 Candidate의 revised Round, 확정 Spec, Core-issued Task, Builder Context v4·Decision 적용·파일 생성, read-only Helper, Decision Episode Analyst의 accepted Evidence 2건(EXPLAINED), 그 Evidence 2건을 basis로 쓴 다음 Helper 답변까지 확인했다. 반면 Builder의 `pnpm` 검증·결과 health·`complete_task`는 실패 또는 미실행이고 Task는 ACTIVE/Completion null이다. 초기 `activeDecisionIds` 빈 배열에 한정한 transport 보정이 필요했으며 이후 Context v4에서 같은 필드 누락이 반복됐다. Analyst도 Helper Episode의 잘못된 직접 USER reference를 Core가 기각하고 30초 timeout이 나타났다. 제품 채널의 USER 입력은 합성 검증이므로 실제 사용자 이해 증거가 아니다. [최종 단일 계보·단계별 PASS/PARTIAL/BLOCKED](spikes/T19_NATIVE_LIVE_RUN_20260913.md)에 따라 T19-N은 `[~]` 유지; private Kiro API, 일반 설치 IDE/Windows, OS-level shell confinement은 추가 검증이 필요하다.
- 변경 범위 검증에서 format/lint/typecheck, unit/integration/eval, build/smoke가 통과했다. 제한된 shell의 `pnpm check`는 Chromium 시작 전 MachPort 권한 오류로 E2E 단계에서 종료했고, 같은 코드의 E2E 12개는 GUI 권한 재실행에서 통과했다. `pnpm check` 단일 명령 exit 0이나 clean install·Windows 검증으로 표현하지 않는다.
- 2026-09-14 사용자 승인 10시간 bounded 결정 실험에서 격리된 macOS IDE 1.0.437 / Agent extension 1.0.794의 실제 native Agent로 A/B/C 서로 다른 합성 목표의 Discovery→Spec→Builder Core 완료·검증·실행→Helper/Analyst→다음 개인화와 sequence-2 개선을 연결했다. 실제 Chrome 동작, 여러 합성 USER Evidence 출처, 하나의 외부-workspace write 거절 및 ACK, 취소/복구, 빈 JSON container 전달을 구분 검증했다. 하지만 동일 Host에서 Builder 중 Helper session을 열면 Kiro custom-agent queue가 `AGENT_QUEUED_HELPER_BEHIND_BUILDER`를 냈고 공유 MCP pool 재조정 뒤 Builder Core mutation ToolCall이 두 번 실제 `Tool is not available`로 실패했다. 다른 역할이 끝난 뒤 단독 Builder 재개로 해당 Task를 Core 완료했다. 따라서 **순차 IDE-only 수직 흐름은 가능하지만 현재 단일 Host 역할 동시성은 기존 CLI 행동과 동등하지 않다.** 공식 제어 계약·세션별 MCP/권한 격리, 일반 설치/Windows와 성능·반복성은 남아 있으므로 CLI 기본 경로를 유지하고 T19-N `[~]`를 유지한다. [시각별 근거·최종 판정](spikes/T19_NATIVE_10H_REPLACEMENT_DECISION_20260913.md)을 따른다. 새 queue 계측 변경의 전체 check는 E2E 전 단계가 통과하고 sandbox Chromium Mach-port에서 중단됐으며, 동일 코드 E2E 12/12는 기존 승인된 GUI 환경에서 별도로 통과했다. 실험 원본 main은 변경하지 않았다.

- 2026-09-14 후속 T19-N source/contract spike에서 설치본의 built-in ChatAgent 별도 queue는 확인했으나 custom Helper의 prompt·tool policy를 상속하지 않고 단일 MCP pool의 Builder 서버까지 볼 수 있어 안전한 단일 Host 대체 경로로 채택하지 않았다. 격리 worktree에 Project별 별도 IDE host H를 준비해 Helper와 모든 자동 Analyst를 H로, Builder를 실제 W로 라우팅하고 H의 read-only/tool-less catalog, 단일 H claim, W/H 경로 redaction 및 endpoint `windowId` 계측을 집중 테스트 28개로 검증했다. Node 24.19.0의 format/lint/typecheck/db, unit 55, integration 253, eval 26, Campus Drop 3, build, smoke 6은 통과했다. `pnpm check`는 sandbox Chromium Mach-port 권한에서 E2E launch 전에 중단됐고 동일 코드 `pnpm test:e2e` 12개는 허용된 GUI 권한에서 통과했다. 당시 CUA가 IDE 창에 연결되지 않아 새 native Agent turn·Core receipt·두 `windowId` 차이는 실측 전이었다. Helper의 W native file-read parity도 이번 Core context-only 범위에 포함되지 않는다. [source 판별·live gate](spikes/T19_NATIVE_PARALLEL_HELPER_SOURCE_ASSESSMENT_20260914.md)를 따른다. T19-N은 `[~]` 유지한다.
- 2026-09-14 이어진 실제 Kiro UI Project D 두 창 실측에서 Builder W `windowId=4`, Helper/Analyst H `windowId=6`을 확인했다. 첫 sequence 1은 Helper Core context·답변이 Builder terminal 전에 끝난 뒤 Builder Core `update_build_context`/`complete_task`와 Task COMPLETED 및 결과 앱 브라우저 검증까지 이어졌다. 패널을 run별 출력/Helper transient SSE 재생으로 보정한 뒤 두 번째 sequence 2에서 Builder RUNNING과 Helper RUNNING→SUCCEEDED 답변이 같은 화면에 보였고, Helper 뒤 Analyst H 성공·Builder의 Core 완료·Task COMPLETED까지 확인했다. 실제 Chrome에서 `  ALP  `가 Alpha만 찾고, 안 읽음 필터와의 결합·공백 검색·제목순/등록순 전환이 5건의 테스트 책에서 의도대로 동작했다. Builder는 초기 scope mismatch 2회와 `complete_task` JSON envelope reject 5회 후 UI 질문에 검증된 형식 오류를 한 번 알려 복구했다. Post-build Analyst도 unknown permission deny 뒤 한 차례 30초 취소·자동 재시도로 성공했다. 최종 Project D의 두 Task는 COMPLETED, Analyst 5건 SUCCEEDED, active run 0, native binding 80개 모두 REVOKED였다. 이는 **같은 앱의 별도 Dev Host 두 창**에서 Core context-only Helper 병렬 경로의 bounded 보조 복구 성공이며 단일 Host/CLI 동등성, 일반 profile/Windows, 장기 안정성, W native file-read parity까지 확대하지 않는다. [실측·잔여 한계](spikes/T19_NATIVE_PARALLEL_HELPER_SOURCE_ASSESSMENT_20260914.md)에 따라 T19-N은 `[~]` 유지한다.
- 2026-09-15 마지막 8시간의 한 창 실측은 위 **당시** 단일 Host 불가 판정을 좁게 갱신한다. macOS Kiro IDE 1.0.437 / Agent extension 1.0.794의 한 Extension Development Host `windowId=4`에서 protected built-in H Helper가 W Builder의 실제 파일 변경 중 뒤늦은 질문에 답했고, G 앱은 같은 Core Task의 세 Builder turn 끝에 완료·브라우저 실행됐다. 외부 Agent CLI가 **이 동시성에 기술적으로 필수**라는 명제는 기각한다. 다만 private observer·핀한 permission/catalog/hook/cloud gate, 생성 코드의 간접 OS 쓰기 격리 미증명, Node 26 native shell 대 Node 24 지정, malformed envelope·긴 Builder 수명, 의미상 과수락 Evidence, 다음 개인화의 근거 선택·답변 효과, G geometry/frozen install 결함, 일반 VSIX/Windows·CLI latency/cost 동등성 미검증으로 **IDE-only 전체 MVP와 기본 경로 교체는 보류**한다. E Decision 실제 자동 승인 거절, F Decision 선택 미시도, G 후속 Task 준비 자동 승인 거절은 우회하지 않았다. Core/Backend의 결정적 계약·Evidence 정책과 IDE host adapter의 세션·권한·stream·취소 계약을 구분해 [bounded 판정과 재현 근거](spikes/T19_NATIVE_IDE_ONLY_LAST_8H_20260915.md)를 남긴다. T19-N은 `[~]` 유지한다.
- 2026-09-15 P1/P2 source 후속에서 pin한 native panel을 package-local bridge·canonical prompt·asset digest와 무재생 reconnect를 가진 독립 VSIX로 만들고, `JUSTIFIED_DECISION`을 cited USER_DECISION→같은 Episode의 DECISION_RESOLVED→stored same-scope DecisionResolution→user rationale/custom proposal exact quote로만 수락하도록 좁혔다. request-only·미래 계획·자기 설명·이유 있는 선택·자연어 수행 보고와 unseen cache domain을 분리한 Analyst v1.0.6 fixture, exact clean `REPHRASE/EXPLAINED` in-memory Application 수락, curated Ledger × recent Episodes 2×2 및 unseen Discovery pair를 기록했다. 기존 독립적 `PREDICTION`과 자연어 수행 보고 `APPLICATION` 정책은 유지하며 Core가 일반 문장 의미를 regex로 판단하지 않는다. `pnpm check`는 Node 24.19.0에서 format/lint/typecheck/db, unit 87/87, integration 268/268, eval 33/33, Campus Drop 3/3, build, smoke 6/6와 GUI E2E 12/12를 포함해 exit 0이었다. 이는 source·합성 fixture 검증이며 일반 Kiro profile 설치/activation, backend 재연결 live 회귀, 새 clean native Analyst·2×2 Helper·unseen Discovery 효과, 실제 사람 학습, Windows와 CLI cutover는 완료하지 않았다. 과거 G 오수락 DB는 수정·삭제하거나 성공 근거로 재사용하지 않았고 T19-N은 `[~]`를 유지한다. 최신 경계는 [P1 패키징·재연결](spikes/T19_NATIVE_P1_PACKAGING_RECONNECT_20260915.md), [P2 Evidence 의미](spikes/T19_NATIVE_P2_CLEAN_EVIDENCE_20260915.md)와 [continuation 인계](spikes/T19_NATIVE_P1_P2_CONTINUATION_20260915.md)를 따른다.
- 2026-09-15 후속 live baseline에서 0.1.2 VSIX의 일반 Kiro 설치·activation, 같은 열린 panel의 idle backend rotation/read-only durable restore와 bounded synthetic command를 실측했다. Exact catalog-confirmed `claude-sonnet-4.5`, config `NOT_EXPOSED`, 같은 `windowId=2`에서 Analyst 7 + Helper 4 + Discovery 2의 13/13 cell이 retry 0·runtime Core mutation 0·final idle `true`로 종료됐지만 overall deterministic 결과는 `FAILED`였다. Analyst strict oracle은 request-only와 directly-led repeat만 통과했다. 미래 계획의 약한 `APPLICATION`, 일반 조건 정의·사후 관찰의 강한 `PREDICTION/DEMONSTRATED`, `USER_DECISION` 없는 cache 규칙의 `JUSTIFIED_DECISION`은 실제 회귀다. 다만 exact one-Proposal expectation이 canonical claim 분리와 충돌하고 reasoned-choice full Agent context가 사용자 이유를 미리 제공해 2/7을 일반 정확도나 clean positive 결과로 해석하지 않는다. Helper/Discovery contract 6/6은 통과했지만 Helper의 행동상 개인화 이득과 Discovery의 명시적 근거 연결·실용 우위·인과 효과는 입증하지 못했고 Need-absent/truly-held-out도 남았다. runtime DB 집계는 불변이고 기존 오수락 Evidence나 fixture/metadata를 retcon하지 않는다. 다음 우선은 전체 Agent context hint 감사, claim-granularity oracle과 정의·사후 관찰·실제 예측 회귀 정리 후 같은 bounded 재평가다. P3/P4/Windows/CLI cutover는 완료가 아니며 T19-N은 `[~]`다. [P2 live 결과](spikes/T19_NATIVE_P2_LIVE_CLEAN_EVAL_20260915.md)와 [최신 continuation](spikes/T19_NATIVE_P1_P2_CONTINUATION_20260915.md)을 따른다.
- 2026-09-15 사용자는 09:58~13:58 UTC의 마지막 4시간을 새 가능성 탐색 대신 득실 중심 최소 실측과 IDE-only frontend 전환 판단에 쓰도록 승인했다. 한 창 protected H의 Builder + late Helper 세 번, 확인된 H cancel 뒤 재사용, 새 실제 Decision의 사용자 이유·해결·Builder 적용을 우선하고, P2의 좁은 clean Analyst 재평가와 합쳐 개발 착수 범위만 결정한다. 기존 CLI source를 즉시 삭제하지 않으며 Windows·장기 안정성·정밀 CLI 비교와 진행 중 reconnect race는 완료로 세지 않는다. 안전/동작 실패는 그대로 blocker로 기록한다. [4시간 계획](spikes/T19_NATIVE_IDE_ONLY_4H_CUTOVER_PLAN_20260915.md)을 따르며 T19-N은 `[~]` 유지한다.
- 2026-09-16 승인 재개 뒤 일반 Kiro 0.1.3의 parser/install/reload/activation, 같은 `windowId=2`에서 W read와 late protected H의 3/3 overlap, confirmed H cancel/reuse, 실제 Core Decision request→합성 UI resolution→same-scope application→Builder resume, G Task `COMPLETED`와 Node 24 fresh app-only frozen install/33 tests/typecheck/build/smoke·실제 geometry/Undo/Redo/reload를 bounded 검증했다. 최종 active run/Analysis 0, Analysis 51 `SUCCEEDED`, binding 115 전부 `REVOKED`/0600, SQLite `quick_check=ok`였다. 반면 Analyst v1.0.7은 7/7 operational 완료에도 deterministic quality 3/7 `FAILED`이고, active-operation reconnect, Windows, private API 일반 지원, OS sandbox와 CLI 동등 비교는 미검증이다. 따라서 **pin한 macOS experimental IDE flow와 frontend 인계는 GO**, Evidence production/Windows/CLI 교체는 **NO-GO**이며 T19-N과 MVP는 완료가 아니다. 원래 09:58~13:58 UTC deadline은 action-time 승인 대기 중 지났으므로 wall-clock 4시간 성공으로 기록하지 않는다. [최종 cutover 판정](spikes/T19_NATIVE_IDE_CUTOVER_VERDICT_20260916.md)을 따른다.

### [x] T19-W0. Windows 제품 요구와 다음 세션 인계

**승인·범위**

- 2026-09-23 사용자가 Windows 중심 실사용, 확장 설치 후 backend 자동 실행, 기존 runtime 재사용 방향을 승인하고 문서 반영·적절한 branch 선택·commit을 요청했다.
- `21674e8` native recovery HEAD에서 `codex/windows-extension-runtime-20260923`을 분기한다. 현재 `main`에는 native 구현 baseline이 없으며 기존 recovery는 Mac 회귀 기준으로 보존한다.

**산출물·완료 조건**

- BRIEF/SPEC/ARCHITECTURE/DECISIONS/TASKS와 frontend entry 문서를 정합하게 갱신하고 [Windows 인계](WINDOWS_EXTENSION_HANDOFF_20260923.md)에 사례·설치물·조건부 다운로드·현재 결함·후속 검증을 기록한다.
- 문서 상대 링크·요구사항 추적·다음 task 하나·diff whitespace를 검증하고 요청 범위의 문서만 commit한다. Windows 실행 성공이나 기존 미완료 task 완료로 표시하지 않는다. push는 이번 요청에 없다.

**검증 기록**

- 2026-09-23 문서 10개의 상대 링크 115개가 존재함을 확인했고 `git diff --check`를 통과했다. AC-MVP-015의 SPEC/TASKS 추적과 W1 단일 다음 착수 표시를 확인한다. source·의존성·runtime 변경은 없으므로 app test/Windows 실측은 이 문서 작업의 검증으로 주장하지 않는다.

### [x] T19-W1. Windows runtime와 native Agent capability 실측

**실행 계획:** [Windows W1 실측 계획](T19_W1_WINDOWS_CAPABILITY_PLAN.md) — 2026-09-24 사용자가 실행을 승인하여 착수했다. 개발 도구 준비·최소 Windows adapter 수정·합성 native 실행·회귀 검증을 수행한다.

**2026-09-24 결과:** [Windows W1 실측 결과](spikes/T19_W1_WINDOWS_CAPABILITY_RESULTS_20260924.md). Kiro 1.1.14 / Agent 1.1.28 / API 1.131.0 / host Node 24.18.0에서 SQLite·Core·stdio MCP와 실제 Discovery 10 preview, Builder 파일 2개·test exit 0·Context v2, read-only Helper, 두 역할 취소·새 실행·revoke를 확인했다. native 8회 한도를 지켰다. 단일 창 custom Helper는 직렬 처리되므로 병행 FAIL, 현재 built-in artifact gate는 미지원; **분리된 두 창에서만 병행 PASS**다. 마지막 진단의 TAP reporter 오판은 원본 FAIL을 보존하고 동일 hash 생성물 9 tests 및 DB/ACL/revoke 후속 감사 PASS로 해결했다. 전체 `pnpm check`와 관련 panel CJS 18 tests PASS. W1 bounded capability만 완료하며 제품의 두 창 UX/설치·전체 수직 흐름 완료로 확대하지 않는다.

**선행 조건**

- T19-W0 인계와 Windows 일반 사용자 환경, Kiro IDE·본인 로그인이 준비돼야 한다. 개발 checkout의 Node/pnpm pin은 별도로 충족하며 제품 사용자에게 요구하지 않는다.

**범위·산출물**

- Windows x64 우선으로 OS/architecture, Kiro/Agent/API/host runtime version과 지원표를 기록한다. ARM64는 별도 검증 전 미지원이다.
- Kiro child runtime → 기존 Node → managed Node 후보 순서의 capability를 확인한다. SQLite Node-API 10/load/transaction/reopen, MCP bridge와 native Discovery 제출·Builder 작은 write/test·Helper read-only·stream/cancel/revoke를 합성 scope에서 검증한다.
- exact Mac pin·Homebrew path 의존 지점을 좁은 spike로 분리하되 source/role/permission 검증을 삭제하지 않는다. `core:doctor --live`의 CLI 검사를 native PASS로 쓰지 않는다.

**완료 조건**

- 재현 가능한 source/command/test와 sanitized Windows receipt가 있으며 runtime 재사용/불가·native 역할별 성공/실패를 구분한다. 전체 기능 미통과를 완료로 덮지 않고 막힌 gate를 기록한다. Windows가 없으면 `[-]`와 이유를 남긴다.

### [x] T19-W2. Core·bridge portable package와 runtime 준비

**2026-09-24 착수:** 사용자 `T19 w2` 요청으로 W1 실측을 기반으로 portable Core/bridge, runtime 선택·획득과 win32-x64 VSIX를 구현·검증한다. 기존 작업 변경을 보존하며 W3 lifecycle/프론트 통합과 추가 native 모델 실험은 포함하지 않는다.

**2026-09-24 결과:** [W2 실측 결과](spikes/T19_W2_PORTABLE_CORE_RESULTS_20260924.md), [package/API 인계](T19_W2_PORTABLE_CORE_HANDOFF.md). Kiro Node 24.18.0, 기존/managed Node 24.19.0에서 repository 밖 한글·공백 경로의 packaged Core/SQLite migration·SDK·stdio MCP·scope/권한/revoke·재시작 PASS. 공식 다운로드·offline cache·손상/중단/취소·lock 복구와 ACL/junction/hardlink 검사 PASS. VSIX **1,875,725 bytes**, 설치 **5,482,884 bytes**, 조건부 Node **92,825,416 bytes**를 실측했다. `pnpm check`, panel build, 관련 CJS 19 tests와 최종 native-client/runtime 44 tests PASS. 모델 호출·IDE 설치·commit/push는 0회이며 W3~W5 완료로 확대하지 않는다.

**선행 조건:** T19-W1에서 Core/runtime와 native 연결을 진행할 근거가 확보돼야 한다.

**산출물·완료 조건**

- 검증된 runtime descriptor, packaged resource root, platform SQLite·migration/prompt/guard를 source checkout 없이 실행한다. 제품 호환 범위를 기록하고 개발 pin과 분리한다.
- Kiro/기존 Node/검증된 cache 재사용 및 필요한 경우의 private runtime acquisition을 구현·검증한다. 다운로드 중단/손상/offline·재시도·출처 검증, Windows 경로/ACL을 포함한다.
- OS별 VSIX 구성과 누출 검사를 마련하고 dev source·다른 플랫폼 binary·DB/token을 제외한다. 총 VSIX/설치/추가 다운로드 크기는 실제 artifact로 측정한다.

### [x] T19-W3. 확장 자동 기동·연결·복구와 frontend 통합

**2026-09-24 착수:** 사용자 `T19 W3` 요청. W2 portable package와 SDK를 재사용해 자동 lifecycle·Windows native source gate·제품 패널을 통합하고, 합성 데이터의 다중 창/종료/crash/rotation/update 및 실제 설치 경로를 검증한다. [W3 계획](T19_W3_LIFECYCLE_PLAN.md). 기존 변경과 T19/T19-N 한계를 보존한다.

**2026-09-24 결과:** [W3 실측 결과](spikes/T19_W3_LIFECYCLE_RESULTS_20260924.md), [lifecycle 인계](T19_W3_LIFECYCLE_HANDOFF.md). 통합 VSIX 0.2.0의 일반 Kiro 합성 profile 설치·자동 Core·History·실제 Discovery preview 10·Helper 응답 저장 PASS. 사용자 승인한 Helper 보조 창 자동 열기, 두 windowId의 같은 Core 사용, owner 창 종료 후 35초 유지와 마지막 창 종료 후 Core process 종료를 확인했다. packaged startup/reload/crash·credential rotation/update·migration backup·downgrade 7그룹, 관련 CJS 22 tests와 최종 `pnpm check`(unit 92, integration 274 + skip 1, eval 34, Campus Drop 3, smoke 6, E2E 12) PASS. 초기 endpoint 준비·drive case·owner 종료 실패와 E2E fixture 경쟁을 고치고 원인·범위를 기록했다. W4/W5와 상위 T19/T19-N gate는 유지한다.

**선행 조건:** T19-W2.

**산출물·완료 조건**

- extension lifecycle manager가 private data 초기화, Core owned process, native worker, 연결 정보와 SDK generation을 관리한다. 사용자 수동 server/connection 경로 입력을 제거한다.
- 다중 창·DB lock·정상 종료·crash·credential rotation·확장 업데이트·migration backup을 검증하고 기존 데이터와 no-auto-replay를 유지한다.
- frontend는 runtime 준비/Core 연결/native 준비/실제 결과 저장과 오류를 구분하며 하나의 제품 확장으로 설치된다. private API 재작성·Mock 성공 대체 없이 UI 책임과 adapter 책임을 분리한다.

### [x] T19-W4. 생성 TypeScript 앱의 도구 자동 준비

**2026-09-24 착수:** 사용자 `T19 W4` 요청. 기존 변경을 보존하고 생성 앱 전용 Node/pnpm 선택·private 준비, native shell 전달과 result launcher를 구현한다. 기존/미설치 도구, frozen install/build/test/HTTP와 실패·복구를 검증하며 W5 전체 수직 흐름과 구분한다. [W4 계획](T19_W4_TOOLCHAIN_PLAN.md).

**2026-09-24 완료:** VSIX 0.3.0에서 기존 Node/pnpm 재사용과 PATH 도구 부재의 private 자동 준비를 검증했다. 두 환경의 실제 native Builder에서 lock/frozen install/build/test/HTTP smoke가 모두 exit 0이었고 별도 packaged result supervisor도 선택된 일반 Node로 HTTP 응답을 반환했다. 미설치 환경 검증기의 중간 상태 조회 오류는 동일 Core/run을 읽기 전용으로 재관측하여 확인했으며 Agent 요청은 재전송하지 않았다. 최종 `pnpm check`(unit 93, integration 280+1 skip, eval 35, Campus Drop 3, smoke 6, E2E 12), 확장 CJS 89, portable 11개 gate와 도구 실패·복구 검증 PASS. [결과](spikes/T19_W4_TOOLCHAIN_RESULTS_20260924.md), [receipt](spikes/T19_W4_TOOLCHAIN_RECEIPTS_20260924.json), [인계](T19_W4_TOOLCHAIN_HANDOFF.md). clean machine·전체 수직 흐름·초기 workspace 전환 host crash와 조회 안정성은 W5에서 검증한다. 상위 T19/T19-N은 완료 처리하지 않는다.

**선행 조건:** T19-W3.

**산출물·완료 조건**

- 기존 Node/pnpm 우선, 필요 시 private 도구 준비. native Agent shell과 result launcher가 선택한 runtime을 실제로 사용하게 하고 `process.execPath`·env 가정을 수정한다.
- 도구 설치 유무 두 환경에서 frozen install/build/test/실제 result HTTP smoke를 수행한다. generated workspace·lifecycle allowlist를 지키고 전역 PATH/사용자 설치를 변경하지 않는다.

### [x] T19-W5. clean Windows 확장 설치와 수직 흐름 출하 검증

**2026-09-25 완료:** 일반 설치 VSIX 0.3.15 / 정확한 Kiro 1.1.70 source에서 새 Personal Need 유무 프로젝트의 Discovery·Spec·실제 Decision·Builder/Helper·테스트·HTTP 결과·분석/다음 context·History를 검증했다. Need 없음은 9회 완주, Need 있음은 마지막 Helper catalog 사전 실패를 보존하고 보조 창 재개·새 read-only 요청 1회로 복구한 10회 완주다. 각각 실제 13/14 tests, 분석 4건 성공, USER_UNDERSTANDING 0, 명시적 취소 9ms, Core crash 후 약 5.1초 자동 복구·credential 회전·durable 상태 동일·새 run 0을 확인했다. 최종 전체 check(unit 113·integration 298+skip 1·eval 35·Campus 3·smoke 6·Edge E2E 12), CJS 106, driver 12, lifecycle 8, portable 11 PASS. [최종 일반 모드 결과·지원표·복구 한계](spikes/T19_W5_KIRO_1170_GENERAL_MODE_RESULTS_20260925.md), [정제 receipt](spikes/T19_W5_KIRO_1170_ADAPTATION_RECEIPTS_20260925.json). 현재 PC의 초기 clean 상태는 사용자 확인, 제품 PATH 격리·도구 자동 준비는 실제 receipt에 근거한다. 상위 T19/T19-N의 품질 gate는 유지한다. 아래 후보/승인 대기는 과거 기록이다.

**2026-09-25 일반 설치 후보:** 0.3.14는 정확한 1.1.70 source pin, 내장 Agent manifest 의존성, pre-model Cloud 양성 증명과 복원되는 logging scope, 생성 Project만의 nonpersistent terminal 환경을 사용한다. 외부 진단 실행 옵션 없이 새 양쪽 흐름을 검증 중이다. 전체 check(unit 111·integration 298+skip 1·eval 35·Campus 3·smoke 6·Edge E2E 12), CJS 106개와 packaged lifecycle 8개 PASS. 개발/일반 확장 호스트 차이와 과거 startup 로그 혼입을 각각 재현해 보완했고 원본 실패를 보존했다. [일반 모드 기록](spikes/T19_W5_KIRO_1170_GENERAL_MODE_RESULTS_20260925.md)을 최신 판정으로 보며 아래 진단 전용·승인 대기는 당시 기록이다.

**2026-09-25 원본 복구 PASS:** 프로세스 범위 RemoteSigned에서 실제 terminal 출력과 성공/실패 이벤트를 확인했다. 15번째 Builder가 원본 frozen install/build/typecheck/17 tests/HTTP smoke를 통과하고 Core Task를 완료했다. 16번째 후속 Helper·분석 3건·HTTP 200·History 무재실행도 PASS다. 영구 정책은 전후 불변이다. [실측](spikes/T19_W5_WINDOWS_PROCESS_SHELL_RESULTS_20260925.md)을 기록하고 새 Personal Need 흐름을 검증 중이다. 기존 도구 재사용 profile에 미설치 조건을 섞은 시도는 도구 변경 보호 검사에서 차단되어 보존하고, 새 profile에서 설치부터 검증한다.

**2026-09-25 진행 재개:** 기존 W5 완료 요청과 사용자의 “왜 멈춤?”에 따라 불필요한 추가 승인 대기를 해제했다. 합성 Kiro 자식 프로세스에만 RemoteSigned를 전달하고 영구 정책 불변을 검증한다. 모델 0회 terminal 확인 뒤 새 한정 native 요청으로 진행한다. 아래 답변 대기는 이전 판단 기록이다.

**2026-09-25 환경 정정:** 사용자가 현재 PC는 Kiro부터 새로 설치한 clean Windows라고 확인했다. 이전 기기의 환경 부재를 잘못 적용한 별도 PC/VM 요청과 gate 분리 질문은 철회한다. 초기 상태와 이후 임시 검증 도구 준비를 구분하며, 현재 환경에서 나머지 검증을 진행한다. 완료 기준 완화나 전체 흐름 PASS를 뜻하지 않는다. 실행 정책 변경 질문은 별개로 아직 답변 대기다.

**2026-09-25 현재 버전 추가 실측·조건 대기:** 0.3.11 실제 업데이트 뒤 13번째 Builder가 원본 앱의 타입·test glob·종료 오류를 수정했다. 그 코드의 변경 없는 복사본은 frozen install/build/typecheck/17 tests/HTTP smoke·결과 감독기까지 PASS다. 실제 native 응답 후 취소, 최신 packaged lifecycle 8개·portable 11개도 PASS다. 하지만 기본 PowerShell과 합성 Command Prompt의 native 실행은 출력/종료값 누락으로 13·14번째 모두 원본 Task ACTIVE를 유지했다. 모델 0회 재현에서 Windows PowerShell `Restricted`가 Kiro의 `shellIntegration.ps1`을 `PSSecurityException/UnauthorizedAccess`로 차단함을 확인했다. `scripts/probe-windows-shell.mjs`로 재현 가능하다. 영구 정책은 변경하지 않았으며 검증 터미널 프로세스에만 RemoteSigned를 적용할지 사용자 응답을 기다린다. clean Windows 환경은 현재 PC로 확보되어 별도 환경 제공·gate 분리는 요구하지 않는다. 일반 1.1.70의 debug Cloud 증거 의존과 양쪽 fresh 완주 조건은 해결된 것으로 표시하지 않는다.

**2026-09-25 현재 버전 완료 요청으로 재개:** 사용자 “지금 버전으로 w5 완료해”에 따라 Kiro 1.1.70과 VSIX 0.3.11부터 실제 완주·회귀·지원 경계 검증을 진행한다. 앞선 12회 시도의 기록은 보존하고 이번 명시적 요청에 따른 후속 실행을 별도 계보로 기록한다. 완료 조건을 통과한 결과만 완료로 처리한다.

**2026-09-25 대기 해소·재개:** 사용자가 보안 알림을 닫고 검증 Kiro 창을 앞으로 가져왔다. 화면에서 승인 대상이 개발 도구에 포함된 `PSReadLine.format.ps1xml`임을 확인했다. 모델 0회 비교에서 상속된 PowerShell 7 모듈 경로는 실패하고, 자식 process의 `PSModulePath`를 제외한 Windows 기본 모듈은 정책 Restricted 그대로 import에 성공했다. 검증 host의 환경 격리를 보완하고, 원본 실패와 continuation 계보를 보존하는 별도 1회 복구를 준비한다. 정책·TrustedPublisher·방화벽·제품 adapter는 변경하지 않으며 누적 요청 12회와 W5 완료 gate를 유지한다.

**2026-09-25 후속 판단 대기:** 누적 명시적 요청 12/12회가 끝났다. 검증기 옵션 실수로 11번째는 도구 변경 gate에서 모델 전 실패했고, 동일 도구를 복원한 12번째는 승인 입력 없이 실행기에 도달했지만 CP949의 한글 경로 해석 오류로 끝났다. 이를 고친 VSIX 0.3.11과 전체 check(unit 105, integration 298 + 기존 skip 1, eval 35, Campus Drop 3, smoke 6, Edge E2E 12), CJS 105개는 PASS다. 모델 없는 원본 생성 앱 복사본 검증은 설치 PASS 후 TS2345로 실패했다. 타입 guard와 test 파일 glob을 별도 복사본에서 보완하자 build/typecheck/test 17개와 제품 결과 감독기의 HTTP 200·종료는 통과했다. 생성 smoke 자체는 HTTP 확인 후 Node/libuv 종료 assertion으로 실패했다. 원본 Task는 ACTIVE이며 이 수동 보완을 native 완주로 집계하지 않는다. 일반 1.1.70 지원 전환은 보류를 권장하고, 새로운 한정 native 완주 검증 범위에 대한 사용자 판단을 기다린다. 검증 Kiro/Core는 종료됐고 원본 기록은 보존했다.

**2026-09-25 새 기기 재개:** 사용자가 Kiro 설치·작업용 Workspace Trust 위임과 호환성 보완 후 진행을 승인했다. IDE 1.1.70 / Agent 1.1.158의 [호환성 spike](spikes/T19_W5_KIRO_1170_COMPATIBILITY_20260925.md)에서 기존 cloud receipt 생략을 확인하고, exact source·fresh 세션·debug 양성 증거를 요구하는 진단 전용 adapter를 추가했다. 실제 Helper 1회, Discovery 5단계와 확정 Spec, Builder Decision·별도 Helper 설명·선택 적용을 확인했다. Cloud 조회 경쟁과 Windows 절대 경로·shell 설명 필드 차이를 보완한 0.3.10은 실제 파일 작성까지 통과했다. 다만 terminal의 PowerShell 실행 승인 입력 때문에 생성 앱 install/build/test는 실행되지 않아 미완료다. 누적 명시적 요청 10/12회, 조회 실패 0회이며 원본 실패와 복구 계보를 보존한다. 최종 `pnpm check`는 unit 105, integration 296 + 기존 skip 1, eval 35, Campus Drop 3, smoke 6, 설치된 Edge E2E 12를 통과했고 CJS 104개와 0.3.9 packaged lifecycle 8개도 PASS다. 일반 제품 source gate와 W5/상위 완료 조건은 유지한다.

**2026-09-24 기기 간 개발 인계:** 사용자가 commit/push 및 collaborator 권한이 있는 기존 `Hello-KU-tty/core` remote의 같은 branch를 확인했다. [재개 인계](CROSS_DEVICE_HANDOFF_20260924.md)에 개발 환경·검증 근거·남은 조사와 새 합성 환경 절차를 정리한다. W5 `[~]`, T19 `[-]`, T19-N `[~]` 상태와 clean Windows 미검증은 유지한다.

**2026-09-24 착수:** 사용자 `T19 W5` 요청 및 별도 clean Windows 환경 없이 현재 PC에서 가능한 검증부터 진행하라는 응답. 기존 W1~W4 변경을 보존한다. 격리 profile의 packaged 수직 흐름과 재현 가능한 검증물을 준비하되 실제 도구 미설치 machine gate는 별도 미검증으로 둔다. [W5 계획](T19_W5_RELEASE_VALIDATION_PLAN.md).

**2026-09-24 중단 인계:** 사용자 physical Escape의 Computer Use 중단 신호로 작업을 멈췄다. 첫 격리 VSIX 0.3.0 실행은 실제 preview 10개·JIT 상세화·후보 수정/선택을 저장했으나 SPEC에서 `NATIVE_ROLE_CATALOG_UNVERIFIED` 실패했다. 세션 생성 응답 전 catalog 알림의 bounded 보존/소유권 확인, 안전한 catalog 진단과 생성 workspace 패널 재열기를 보완한 VSIX 0.3.1을 빌드했다. native-client 44 tests, 패널/검증 driver 5 tests와 typecheck/package 검증 PASS. 수정 설치물의 두 번째 live 실행은 Workspace Trust 대기 중 중단되어 원인 해결을 실측 확정하지 않았다. 이번 변경의 최종 `pnpm check`, Builder 이후 수직 흐름, Personal Need 양쪽 완주, clean Windows 및 상위 gate는 아직 미검증이다. 재현과 산출물은 W5 계획의 중단 인계를 따른다.

**2026-09-24 재개:** 사용자 `resume`으로 재개했다. 정상 DACL 검사도 5초를 넘는 것을 재현해 권한 조건을 유지한 채 검사 불가/UNSAFE를 구분하고 VSIX 0.3.2를 빌드했다. 실제 설치물은 Core 연결과 새 Project 생성 후 첫 native 요청에서 `NATIVE_CONNECT_TIMEOUT`으로 실패했고 조회 실패는 0이었다. E2E의 서버 기동·브라우저 cache·응답 대기 실패를 구분해 보존하며 최종 전체 check와 단독 native 재검증을 진행한다. [실측 기록](spikes/T19_W5_WINDOWS_RELEASE_RESULTS_20260924.md), [sanitized receipt](spikes/T19_W5_WINDOWS_RELEASE_RECEIPTS_20260924.json), [설치/지원 범위 인계](T19_W5_RELEASE_VALIDATION_HANDOFF.md). W5 및 상위 T19/T19-N 완료 판정은 보류한다.

**2026-09-24 후속 실측:** VSIX 0.3.6에서 같은 Personal Need Project의 복구 흐름이 Task COMPLETED·결과 HTTP 200·Helper 2개·분석 4개 성공·History 무재실행까지 통과했다. USER_UNDERSTANDING Evidence는 0으로 선택만으로 이해도가 오르지 않았다. 설치 경로 변경/PID 재사용/승인 설정 lock 갱신 경계를 보완했고 Evidence 설명 길이 문제를 수정한 0.3.7의 최종 pnpm check는 unit 97, integration 296+skip 1, eval 35, Campus Drop 3, build, smoke 6, E2E 12를 통과했고 CJS 102개도 PASS다. 새 no-Personal-Need 시도는 Spec 질문 무응답에 따른 native 종료 확인 실패로 중단됐으며, 취소 보조 검사와 host 재시작 후 새 Project는 catalog 검증에서 모델 prompt 전에 실패했다. 최신 portable 11개와 packaged lifecycle 8개는 재실행에서 PASS했지만 최초 CORE_START_TIMEOUT과 최대 약 45.6초 연결 관측을 보존한다. Core/native 초기화 안정성·양쪽 fresh 완주·실행 중 취소는 미해결이다. 상세 회귀와 추가 실제 관측은 W5 실측 기록에 남긴다. clean Windows·전체 GUI·Agent 의미 품질 및 상위 완료 gate는 유지한다.

**선행 조건:** T19-W1~W4와 통합 frontend artifact.

**산출물·완료 조건**

- 개발 source/Node/pnpm 없는 일반 사용자 Windows에서 VSIX 설치만으로 Core·native Agent를 준비한다. 기존 도구 재사용·미설치 자동 준비, 한글/공백 경로·다중 창·취소·재시작·업데이트를 검증한다.
- 새 학습 목표/Personal Need 유무의 Discovery·선택·Spec→Builder/Helper·실제 Decision→테스트/결과 실행→durable History를 확인한다. Evidence 출처·분석 실패/복구·다음 context 전달은 실제 결과와 품질 한계를 분리한다.
- 변경 범위별 unit/contract/storage/Agent eval/IDE 검증과 `pnpm check`, packaged clean install receipt·용량/RSS·지원표를 남긴다. `AC-MVP-015`와 기존 T19/T19-N 완료 기준이 모두 충족됐을 때만 상위 task 완료 여부를 재판정한다.

### [~] T20. 보안·개인정보·접근성·복구 hardening

#### [x] T20-F1. 최신 제출 소스 후보와 Windows 재현 자료 고정

- **선행 조건:** T19-F9/F10 자동 검증 완료. 이전 Mac 전용 source 선택기를 Windows에서도 실행하고 새 kit 구성 모듈·회귀 파일을 빠뜨리지 않는다.
- **완료 조건:** source selector/privacy 회귀, allowlist 소스 사본·파일별 SHA manifest, 압축 후 hash 확인과 제출 문서 갱신. Native·사람 pilot·baseline·외부 제출은 별도 gate로 남긴다.
- **검증:** source781개/ZIP783개를 고정하고 별도 압축 해제본에서 frozen install→backend 전체check→frontend753/typecheck/build→panel build/native169+selector6→actual consumer PASS. 검사 후 source781개 hash 일치. 첫 panel build 누락 실패를 보존했으며 재현 명령에 선행 빌드를 명시한다. [소스 재현 보고서](SOURCE_REPRODUCIBILITY_20260929.md). 실제 모델0, 외부 공개/제출0이다.

- 19:01 후속: 후보 선택 시 DOM 교체로 keyboard focus가 사라지는 결함을 수정했다. 실제 Chrome과 frontend719 회귀 PASS; OS 홈 기반의 legacy Mac 경로·receipt 철자 경계도 보완했다. private source 압축 해제본의 backend 전체/프론트 검사는 통과했지만 native fixture prompt2개 누락을 발견하여 선택기를 수정하고 재검증 중이다. source 재현이나 모델0 GUI 결과를 사람 pilot·baseline 또는 일반 제품 설치 완료로 확대하지 않는다.
- 19:06 수정 source 후보752개의 압축 해제본에서 frozen install→backend 전체(E2E12)→frontend719→native/개발 host/receipt/source 선택기210+2SKIP→actual consumer→Mac host build를 통과했고 검사 후 hash가 일치했다. 첫 prompt 누락 후보는 보존하고 전달 대상에서 제외했다. [source 재현 보고서](SOURCE_REPRODUCIBILITY_20260928.md)와 별도 검증 receipt를 남겼으며 사용자 제출 범위 판단은 아직 대기다.

- 2026-09-28 착수: T19-F2의 Mac 실제 frontend 수직 흐름 검증 후, 연결된 surface의 수집 안내·접근성·redaction·복구 회귀를 점검한다. Windows 전용 검증과 일반 설치 제품화는 이번 사용자 지정 범위에서 제외하되 미검증 한계로 유지한다.
- 18:27 결과: 첫 안내/한국어/스크롤 영역 label과 focus, 저장 전 구조화 redaction·민감 경로 거절·분할 TEXT 마스킹을 보완했다. frontend715, backend integration365/E2E12, native161+2SKIP·개발 환경41, actual consumer, 양쪽 의존성 audit0 PASS. 실제 Kiro 재로드에서 완료 Task·Helper/Evidence 복원과 Chrome 결과 재실행을 확인했다. [NFR별 감사·제한](T20_AUDIT_20260928.md)을 남기며, 일반 설치 OPS와 모든 보조공학 검증을 완료로 확대하지 않아 상위 T20은 열린다. T21과 SPEC10.2의 사람 pilot/baseline 제한 승인도 아직 대기다.

**범위**

- Activity 기본 활성화 안내, local 저장 경로, 수집 범위와 redaction을 첫 사용에 알린다.
- token, credential, 민감 경로와 terminal output을 저장·표시 전에 redaction한다.
- keyboard, focus, label, 읽기 순서, 색상 비의존 상태와 오류 복구를 검증한다.

**선행 조건**

- 모든 MVP surface와 data path가 연결되어야 한다.

**산출물**

- redaction/path/permission test suite
- privacy notice와 local data reset/export 범위 결정
- accessibility audit와 고친 항목 기록
- Agent/tool/storage 장애별 recovery test

**완료 조건**

- AC-MVP-013과 NFR-SEC/A11Y/OPS 항목이 대응 test를 가진다.
- secret fixture가 DB, log, Evidence Trace와 UI snapshot에 남지 않는다.
- Agent 분석 실패, stale context와 연결 끊김에서 사용자가 안전하게 재개할 수 있다.

### [ ] T21. MVP 통합 검증과 범위 동결

**범위**

- Golden Path와 unseen input으로 전체 flow를 반복 검증한다.
- unit, contract, integration, Agent fixture, E2E와 manual review 결과를 acceptance criterion에 연결한다.
- 알려진 제한, 재현 절차와 대회 제출 전 강화 backlog를 확정한다.
- clean Kiro session에서 8개 안팎 Candidate round를 중단 없이 저장하고, 연결 종료 시 중복 round 없이 재시도되는지 검증한다.

**선행 조건**

- T00~T20이 완료되어야 한다.

**산출물**

- AC-MVP-001~014 traceability report
- 자동 test/eval 결과와 manual review 기록
- MVP release note, 알려진 제한과 대회 제출 전 backlog

**완료 조건**

- AC-MVP-001~014가 모두 통과하거나, 사용자가 승인한 제한으로 결정 기록에 남아 있다.
- clean environment에서 전체 flow가 재현된다.
- MVP 이후에는 계약 변경 없이 기준 결과와 비교할 수 있도록 fixture와 prompt version을 고정한다.
- T08에서 관측한 CLI 2 stdio lifecycle 결함은 target host에서 해결되거나 사용자 승인 제한과 재시도 UX로 남아야 한다.

## 3. MVP 이후: 대회 제출 전 경쟁력 강화

### [ ] T22. 평가 protocol과 telemetry 동결

**범위**

- 후보 다양성, Decision 품질, Context 최신성, Evidence 정밀도, false mastery, 완주율과 결과물 실행 성공의 측정 정의를 고정한다.
- token, latency와 Agent 호출 수를 Episode·Agent별로 비교할 수 있게 한다.

**선행 조건**

- T21 MVP 기준선이 있어야 한다.

**산출물**

- metric dictionary, eval protocol, prompt/model/config version manifest
- 개인정보를 제외한 local telemetry summary

**완료 조건**

- 같은 fixture 실행끼리 비교 가능하고 metric 변경 이력이 남는다.
- 교육 지표 하나만으로 제품 성공을 주장하지 않으며 build success와 사용자 증언을 함께 본다.

### [ ] T23. 초보 사용자 pilot와 Evidence annotation

**범위**

- 실제 초보자가 자기에게 필요한 TypeScript project를 고르고 만드는 session을 관찰한다.
- 사용성, Helper 첫 사용 계기, Decision 부담, Evidence 오판과 결과물의 개인적 실용성을 기록한다.
- 동의받은 최소 데이터만 익명화해 reviewer annotation에 사용한다.

**선행 조건**

- T20 privacy 원칙과 T22 protocol이 승인되어야 한다.

**산출물**

- 익명화된 pilot session summary
- Evidence proposal reviewer agreement와 오류 taxonomy
- high-impact usability issue 목록과 사용자 증언

**완료 조건**

- 팀 내부 fixture만이 아닌 실제 초보 사용자에서 전체 flow를 최소 한 번 완주한다.
- Agent의 판정과 human review 차이를 사례별로 설명할 수 있다.
- 민감 원문은 제출 자료나 repository에 포함되지 않는다.

### [ ] T24. Baseline·ablation 비교

**범위**

- 일반 Kiro 대화, 단순 conversation memory, 전체 Evidence engine의 결과를 같은 과제로 비교한다.
- Discovery 개인화, Helper context, deterministic reducer 각각을 껐을 때의 변화를 살핀다.

**선행 조건**

- T22 protocol과 T23 pilot data가 있어야 한다.

**산출물**

- baseline/ablation result와 해석
- Crew memory 위에 별도 제품 layer가 필요한 근거

**완료 조건**

- 비교 조건, sample limitation과 측정 오차가 함께 보고된다.
- 단순 데모 인상만이 아니라 최소 하나의 정량 지표와 사용자 사례에서 차이를 설명한다.

### [ ] T25. Prompt, reducer와 Context 정책 조정

**범위**

- pilot/eval에서 확인한 candidate mode collapse, 과잉 Decision, stale context, false Evidence를 우선 고친다.
- prompt와 reducer 변경을 분리하고 모든 변경을 versioning한다.

**선행 조건**

- T23~T24의 구체적인 실패 사례가 있어야 한다.

**산출물**

- 개선 prompt/policy version
- 변경 전후 regression 및 unseen eval 비교
- 남은 오판의 fallback

**완료 조건**

- 고정 fixture를 희생해 pilot 사례만 맞추는 regression이 없다.
- Evidence threshold나 State 정책 변경은 결정 기록과 test를 동반한다.

### [ ] T26. UI mode 선호와 Helper 유도 검증

**범위**

- Agent 중심과 Code 중심을 취향 가설로 비교한다.
- placeholder, quick card, 실제 Decision handoff와 항상 접근 가능한 Helper 중 무엇이 첫 질문과 후속 질문을 자연스럽게 만드는지 검증한다.

**선행 조건**

- T19 두 surface와 T23 참여자가 있어야 한다.

**산출물**

- mode preference/usability 결과
- Helper 유도 장치별 관찰과 채택 결정
- 두 surface의 유지·축소 범위

**완료 조건**

- 숙련도 상승이 Code 중심 전환을 뜻한다는 결론을 미리 가정하지 않는다.
- build-first를 해치거나 강제 퀴즈처럼 느껴지는 장치는 제거한다.

### [ ] T27. 성능, quota와 신뢰성 강화

**범위**

- Agent 호출, stream rendering, SQLite contention과 context assembly 병목을 측정한다.
- Episode batch, retry/backoff, queue, idempotency와 offline/reconnect 복구를 강화한다.

**선행 조건**

- T22 telemetry와 실제 pilot workload가 있어야 한다.

**산출물**

- latency/call-count profile
- quota exhaustion, duplicate event와 partial failure test
- 비용·성능 tradeoff 기록

**완료 조건**

- event마다 추론하지 않는 설계가 실제 호출 로그에서 확인된다.
- 실패를 숨기지 않고 code 결과와 state consistency를 유지하며 재시도할 수 있다.

### [ ] T28. 실행·배포 경로 확정과 packaging

**범위**

- Windows 제품 확장·Core 자동 기동은 T19-W의 선행 MVP 요구다. 이 작업으로 미루지 않고, 여기서는 검증된 설치물의 공개 채널·심사자 배포·제출 archive 운영을 정한다.
- 대회 심사 방식과 T00 결정에 따라 local 실행만 유지할지, 제한된 hosted surface를 추가할지 확정한다.
- 재현 가능한 설치, Kiro App/MCP 등록, sample project 초기화와 rollback을 문서화한다.

**선행 조건**

- T21 MVP와 실제 대회 제출 요건 확인이 있어야 한다.

**산출물**

- 하나의 공식 실행 경로와 필요 시 fallback recording
- 환경 변수 이름만 담은 `.env.example`
- install/run/rollback 검증 기록

**완료 조건**

- 새 환경에서 secret을 repository에 넣지 않고 심사자가 제품 흐름을 재현할 수 있다.
- hosted 배포를 선택하면 local-only privacy 주장과 달라진 데이터 경계를 명시한다.

### [ ] T29. 온보딩, demo와 제출 자료

**범위**

- 제품 가치, Build-first 철학, Agent 역할, 실제 Decision과 Evidence의 차이를 짧은 onboarding과 README에 담는다.
- Campus Drop과 unseen personalized project를 사용해 문제→작동→검증→AWS/Kiro 적합성을 보여주는 demo를 준비한다.
- live failure에 대비한 검증된 recording과 recovery path를 만든다.

**선행 조건**

- T23~T28의 증거와 공식 실행 경로가 있어야 한다.

**산출물**

- 심사용 demo script와 backup recording
- architecture/evaluation 요약, 사용자 증언과 한계
- submission checklist

**완료 조건**

- 기능 나열보다 사용자 한 명의 전체 변화와 실제 결과물 실행이 먼저 보인다.
- 검증하지 않은 우월성, 학습 효과나 호환성을 주장하지 않는다.
- 제출 요건, 공개 링크, 권한과 secret 노출을 별도 점검한다.

### [ ] T30. 대회 제출 후보 검증

**범위**

- 제품, 문서, demo, test, eval과 설치 절차를 release candidate로 고정한다.
- 심사 환경과 유사한 clean environment에서 반복 실행하고 알려진 제한을 최종 확인한다.

**선행 조건**

- T22~T29가 완료되어야 한다.

**산출물**

- immutable version/tag 후보와 artifact manifest
- 최종 acceptance/eval report
- rollback 가능한 직전 안정 버전

**완료 조건**

- `docs/SPEC.md` 10.2의 제출 준비 조건이 모두 검증됐다.
- demo 시작부터 결과물 실행, Evidence Trace와 다음 개인화까지 끊김 없이 재현된다.
- 제출물에 token, 개인 대화 원문과 local database가 포함되지 않는다.

## 4. 대회 이후: 범용 제품으로 확장

### [ ] T31. Claude Code와 Codex host adapter

**범위**

- Core/MCP contract를 유지한 채 host별 event, tool, session과 permission 차이를 adapter로 흡수한다.

**선행 조건**

- Kiro 기반 MVP와 contract가 안정되어야 한다.

**산출물**

- host capability matrix와 adapter interface
- host별 contract/integration test

**완료 조건**

- Core reducer와 Evidence model을 fork하지 않고 새 host를 연결한다.
- 기능이 없는 host에서는 조용히 흉내 내지 않고 명시적 제한과 fallback을 제공한다.

### [ ] T32. 기존 project import와 언어 확장

**범위**

- 신규 project 전용 MVP를 넘어 기존 repository의 최소 구조와 concept을 import한다.
- TypeScript 외 언어는 language profile과 안전한 실행 경계가 준비된 순서로 추가한다.

**선행 조건**

- T31 또는 안정된 host abstraction과 별도 threat model이 있어야 한다.

**산출물**

- import scanner, consent/redaction flow와 language profile
- repository size, generated files, secret과 unsupported stack test

**완료 조건**

- 전체 코드를 무조건 LLM에 보내지 않고 metadata, diff와 필요한 snippet부터 단계적으로 사용한다.
- import 실패가 원본 repository를 수정하지 않는다.

### [ ] T33. 장기 memory, 동기화와 다중 기기

**범위**

- local-only Ledger를 사용자의 명시적 동의 아래 기기 간 동기화할 수 있는 모델을 설계한다.
- retention, delete/export, conflict와 encryption 경계를 정의한다.

**선행 조건**

- 실제 장기 사용 수요와 개인정보 영향 평가가 있어야 한다.

**산출물**

- sync threat model, data contract와 conflict policy
- opt-in migration 및 삭제 검증

**완료 조건**

- local-only 사용은 계속 가능하고 cloud 동기화가 기본 활성화되지 않는다.
- 사용자 삭제가 projection뿐 아니라 source event와 backup 정책까지 일관되게 처리된다.

### [ ] T34. 장기 학습 검증과 제품화

**범위**

- 여러 project에 걸친 transfer, 잘못된 state 누적, 관심 변화와 실제 서비스 완성의 관계를 검증한다.
- 개인 사용자 외 교육기관·커뮤니티 확장은 별도 사용자와 권한 모델로 평가한다.

**선행 조건**

- 반복 사용자가 충분하고 연구·제품 동의가 구분되어야 한다.

**산출물**

- longitudinal evaluation, product health metric와 governance 제안
- 유지할 기능, 제거할 기능과 새 Golden Path 결정

**완료 조건**

- 장기 학습 효과를 단기 proxy로 과장하지 않는다.
- 결과를 근거로 scope와 business/operation 모델을 새 결정 기록으로 승인한다.

## 5. Acceptance criterion 추적표

| 기준 | 주 구현 작업 | 최종 검증 작업 |
| --- | --- | --- |
| AC-MVP-001~002 | T08 | T21 |
| AC-MVP-003 | T09, T15 | T21 |
| AC-MVP-004 | T10, T18 | T21 |
| AC-MVP-005 | T10, T12, T16 | T21 |
| AC-MVP-006 | T11, T16, T18 | T21 |
| AC-MVP-007~009 | T04, T13, T17 | T21 |
| AC-MVP-010 | T17 | T21 |
| AC-MVP-011 | T18 | T21 |
| AC-MVP-012 | T19 | T21 |
| AC-MVP-013 | T06, T20 | T21 |
| AC-MVP-014 | T07, T18 | T21 |
| AC-MVP-015 | T19-W1~W4 | T19-W5, T21 |
