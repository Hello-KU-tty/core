/**
 * Discovery_Port / Spec_Port invocation boundary for the Discovery -> Spec flow.
 *
 * This module defines the transport-agnostic contract the Extension_Host uses
 * to drive Discovery and Spec operations. The concrete implementation (the
 * `MockDiscoveryPort` today, a future crew-backend HTTP+HMAC adapter later) is
 * chosen behind these interfaces via `createFlowPorts`, so the FlowController
 * and webview never bind to a specific transport.
 *
 * Every operation is async (returns a `Promise`), takes a typed request plus a
 * {@link RequestEnvelope}, and resolves to a {@link PortResult} that is either
 * `ok(value)` or `err(PortError)` -- ports never throw. The signatures mirror
 * the `core` UI command contracts (UI_START_DISCOVERY,
 * UI_RECORD_DISCOVERY_FEEDBACK, UI_UPDATE_LEARNING_SPEC,
 * UI_CONFIRM_LEARNING_SPEC, UI_PREPARE_BUILDER_TASK) so a future HTTP adapter
 * maps 1:1.
 *
 * These are type/interface declarations only; concrete implementations
 * (e.g. `MockDiscoveryPort`) live elsewhere.
 *
 * See design.md "Components and Interfaces > Port boundary" for the
 * authoritative definitions. Requirements: 1.1, 1.2, 1.6.
 */

import type {
  CandidateRevisionReference,
  CandidateRound,
  DiscoveryFeedback,
  DiscoveryInput,
  DiscoverySession,
  LearningSpecRevision,
  PreparedBuilderTask,
  PreviewRound,
  Project,
  ProjectCandidateRevision,
} from "../../core/flow/flow-types";
import type {
  ProjectHistoryView,
  RestoredProjectView,
} from "../../core/flow/history-types";
import type { RuntimeErrorCode } from "../../core/runtime-errors";

/** Metadata every port call carries so a backend swap is seamless (Req 1.6). */
export interface RequestEnvelope {
  /** Correlates a request/response pair across the boundary (`corr_<uuid>`). */
  correlationId: string;
  /** Dedupe key so a retried call is idempotent (`idem_<uuid>`). */
  idempotencyKey: string;
  /**
   * Optimistic-concurrency guard: the revision the caller believes is current
   * for the entity this op targets (session or spec). Nonnegative int.
   * Mirrors core's `expectedSessionRevision` / `expectedSpecRevision`.
   */
  expectedRevision: number;
}

/** Normalized, transport-agnostic port failure (mirrors AdapterError). */
export interface PortError {
  code: RuntimeErrorCode | "timeout" | "revision_conflict" | "unavailable" | "invalid" | "unknown";
  message: string;
}

/** A port operation resolves to ok(value) or err(PortError); it never throws. */
export type PortResult<T> =
  | { ok: true; value: T }
  | { ok: false; error: PortError };

/** A round plus already persisted details; absent on legacy/mock ports. */
export interface DiscoveryFeedbackResult extends CandidateRound {
  candidateDetails?: ProjectCandidateRevision[];
}

/**
 * The Discovery half of the port boundary: open a session, generate preview
 * rounds, enrich candidates, and submit learner feedback (Req 1.1).
 */
export interface DiscoveryPort {
  /** Open a Discovery_Session from a Discovery_Input (Req 1.1, 4.4). */
  startDiscovery(
    req: { projectId: string; input: DiscoveryInput },
    env: RequestEnvelope,
  ): Promise<PortResult<DiscoverySession>>;

  /** Read/watch a preview. Only a user's explicit retry may start a new run. */
  generatePreviewRound(
    req: { discoverySessionId: string; retry?: boolean },
    env: RequestEnvelope,
  ): Promise<PortResult<PreviewRound>>;

  /** Enrich one Candidate_Preview into a Project_Candidate_Revision (Req 1.1). */
  enrichCandidate(
    req: { discoverySessionId: string; target: CandidateRevisionReference },
    env: RequestEnvelope,
  ): Promise<PortResult<ProjectCandidateRevision>>;

  /** Apply Discovery_Feedback and produce the resulting Candidate_Round (Req 1.1, 7.9). */
  submitFeedback(
    req: { discoverySessionId: string; feedback: DiscoveryFeedback },
    env: RequestEnvelope,
  ): Promise<PortResult<DiscoveryFeedbackResult>>;
}

/**
 * The Spec half of the port boundary: draft, refine, confirm a Learning Spec,
 * and prepare the Builder handoff task (Req 1.2).
 */
export interface SpecPort {
  /** Generate a Learning_Spec_Revision draft for a selected candidate (Req 1.2, 8.4). */
  generateSpecDraft(
    req: { projectId: string; selectedCandidate: CandidateRevisionReference },
    env: RequestEnvelope,
  ): Promise<PortResult<LearningSpecRevision>>;

  /** Refine the current draft into a new DRAFT revision (Req 1.2, 10.2). */
  refineSpec(
    req: { projectId: string; learningSpecId: string; message: string },
    env: RequestEnvelope,
  ): Promise<PortResult<LearningSpecRevision>>;

  /** Confirm the current revision (-> CONFIRMED) (Req 1.2, 11.2). */
  confirmSpec(
    req: { projectId: string; learningSpecId: string },
    env: RequestEnvelope,
  ): Promise<PortResult<LearningSpecRevision>>;

  /** Prepare the Builder handoff task once BUILDING (Req 1.2, 11.4). */
  prepareBuilderTask(
    req: { projectId: string; learningSpecId: string },
    env: RequestEnvelope,
  ): Promise<PortResult<PreparedBuilderTask>>;

  /**
   * Leave Spec review for a fresh Discovery session on the same project
   * after an explicit new-candidate request. Navigation alone does not call
   * this mutation. It supersedes the draft; the controller owns the next run.
   * Optional: ports without it make the controller show a notice instead.
   */
  returnToDiscovery?(
    req: { projectId: string; discoverySessionId: string; input?: DiscoveryInput },
    env: RequestEnvelope,
  ): Promise<PortResult<RestoredFlow>>;
}

/**
 * The read-only History half of the port boundary (guide §6 History row, §10-2):
 * list previously-created durable projects and restore one project's durable
 * snapshot for display. It is a SEPARATE, read-only concern from the
 * Discovery -> Spec state machine — these ops NEVER start a run, mutate
 * anything, or auto-trigger discovery ("read-only, 모델 호출 0",
 * "run 자동 시작 없음").
 *
 * SECURITY (guide §9): the methods return only the program-local SAFE view
 * types ({@link ProjectHistoryView} / {@link RestoredProjectView}), which carry
 * only non-sensitive scalars — never the connection, token, or absolute paths.
 * Non-throwing like the other ports: each resolves to a {@link PortResult}.
 */
export interface HistoryPort {
  /** List up to `limit` durable projects as safe view rows (read-only). */
  listProjects(
    limit: number,
    env: RequestEnvelope,
  ): Promise<PortResult<ProjectHistoryView>>;

  /** Restore one project's durable snapshot as a safe summary (read-only). */
  restoreProject(
    projectId: string,
    env: RequestEnvelope,
  ): Promise<PortResult<RestoredProjectView>>;
}

/** The pair the factory returns and the controller consumes. */
export interface FlowPorts {
  discovery: DiscoveryPort;
  spec: SpecPort;
  /**
   * The optional read-only History port (guide §6/§10-2). Optional so existing
   * constructions/tests that build `{ discovery, spec }` still typecheck; when
   * present the controller can populate the read-only History list.
   */
  history?: HistoryPort;
  /** Read-only projection for restoring an existing screen. Never starts a run. */
  restore?: {
    restoreFlow(projectId: string, env: RequestEnvelope): Promise<PortResult<RestoredFlow>>;
    /** Reattach to an already accepted run. Never starts, retries, or cancels it. */
    watchDiscovery?(projectId: string, runId: string, signal: AbortSignal): Promise<PortResult<RestoredFlow>>;
  };
}

/** Explicit allow-list: no Core connection, workspace paths, or raw snapshot. */
export interface RestoredFlow {
  /** Host-only read-watch hint; deliberately omitted from FlowSnapshot. */
  pendingDiscovery?: { runId: string; phase: string };
  project: Project;
  session: DiscoverySession | null;
  previewRound: PreviewRound | null;
  rounds: CandidateRound[];
  candidates: ProjectCandidateRevision[];
  selectedCandidate: CandidateRevisionReference | null;
  spec: LearningSpecRevision | null;
}
